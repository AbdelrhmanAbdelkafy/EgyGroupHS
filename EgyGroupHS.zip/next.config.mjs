/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  images: {
    formats: ['image/avif', 'image/webp'],
  },
  // Redirect bare root to default locale
  async redirects() {
    return [
      { source: '/', destination: '/ar', permanent: false },
    ];
  },
};

export default nextConfig;
