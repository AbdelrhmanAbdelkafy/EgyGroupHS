// ============================================================================
// Where a product photo comes from.
//
// The library used to live entirely on Cloudinary. That worked, but it made the
// catalogue's contents depend on someone else's free tier: exceed the quota or
// let the account lapse, and every photo on the site disappears at once. The
// photos are the business's own work; they belong on the business's own box.
//
// So they were copied down, resized to three widths and stored under .data —
// which survives deploys. This function decides which copy to serve.
//
// NEXT_PUBLIC_LOCAL_PHOTOS=1 flips the whole site from Cloudinary to local. It
// stays a switch rather than a hard cut so the migration can be reversed in one
// line if a photo turns out to be missing, and so the site works either way.
// ============================================================================

const LOCAL = process.env.NEXT_PUBLIC_LOCAL_PHOTOS === '1';

/** The three widths that were generated. Anything asked for snaps up to one. */
const WIDTHS = [400, 800, 1600] as const;

const snap = (w: number) => WIDTHS.find((x) => x >= w) ?? 1600;

/**
 * The stable id for a Cloudinary photo: its path with the version segment and
 * extension removed. The same photo keeps the same id across every size, which
 * is what lets a local file be found from a Cloudinary URL.
 */
export function photoId(url: string): string | null {
  const i = url.indexOf('/upload/');
  if (i < 0) return null;
  let tail = url.slice(i + 8);
  const parts = tail.split('/');
  if (parts.length > 1 && /^v\d+$/.test(parts[0])) tail = parts.slice(1).join('/');
  return tail.replace(/\.[^./]+$/, '').replace(/\//g, '_');
}

/**
 * The URL to actually render.
 * - our own uploads and shipped assets pass straight through
 * - a library photo goes local when the switch is on, Cloudinary otherwise
 */
export function photoSrc(src: string, w: number, h?: number): string {
  if (!src) return src;
  if (src.startsWith('/api/img/') || src.startsWith('/assets/') || src.startsWith('/api/photo/')) return src;

  if (src.includes('res.cloudinary.com')) {
    if (LOCAL) {
      const id = photoId(src);
      if (id) return `/api/photo/${snap(w)}/${encodeURIComponent(id)}.jpg`;
    }
    // Cloudinary crops to exactly w×h; locally, CSS object-cover does that job
    return h
      ? src.replace('/upload/', `/upload/w_${w},h_${h},c_fill,q_auto,f_auto/`)
      : src.replace('/upload/', `/upload/w_${w},q_auto,f_auto/`);
  }
  return src;
}
