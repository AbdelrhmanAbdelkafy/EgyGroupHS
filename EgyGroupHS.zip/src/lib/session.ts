import crypto from 'crypto';
import { cookies } from 'next/headers';

// ============================================================================
// Session = a signed cookie holding the user id. Stateless, so a server restart
// doesn't log everyone out, and there's no session store to keep in sync.
// ============================================================================

const SECRET = process.env.SESSION_SECRET || 'dev-only-secret-change-me';
const COOKIE = 'hs_session';
const MAX_AGE = 60 * 60 * 24 * 60; // 60 days

function sign(value: string) {
  return crypto.createHmac('sha256', SECRET).update(value).digest('hex');
}

export function makeToken(userId: string) {
  const payload = `${userId}.${Date.now()}`;
  return `${payload}.${sign(payload)}`;
}

export function readToken(token: string | undefined): string | null {
  if (!token) return null;
  const parts = token.split('.');
  if (parts.length !== 3) return null;
  const [userId, ts, sig] = parts;
  const payload = `${userId}.${ts}`;
  const expected = sign(payload);
  const a = Buffer.from(sig);
  const b = Buffer.from(expected);
  if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) return null;
  if (Date.now() - Number(ts) > MAX_AGE * 1000) return null;
  return userId;
}

export function setSessionCookie(userId: string) {
  cookies().set(COOKIE, makeToken(userId), {
    httpOnly: true,
    sameSite: 'lax',
    secure: process.env.NODE_ENV === 'production',
    path: '/',
    maxAge: MAX_AGE,
  });
}

export function clearSessionCookie() {
  cookies().set(COOKIE, '', { httpOnly: true, path: '/', maxAge: 0 });
}

export function currentUserId(): string | null {
  return readToken(cookies().get(COOKIE)?.value);
}
