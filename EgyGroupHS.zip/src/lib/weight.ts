// ============================================================================
// Weight engine.
//
// Two rules govern everything here:
//
//  1. Density is chosen, never assumed. A calculator that quietly uses 7.85 for
//     everything is wrong by 4% between 304 and 430 — forty kilos a tonne, which
//     is money. The grade picks the density; a free field overrides it when the
//     mill certificate says something else.
//
//  2. Every formula is shown to the person using it. Anyone buying steel checks
//     the arithmetic, and a number with no working behind it doesn't get trusted.
//
// Geometry is nominal: sharp corners on hollow sections, no corner radii, no
// mill tolerance. That is what the trade quotes on. Real delivered weight moves
// with the thickness tolerance of the plate, which is why the tolerance note
// travels with the result.
// ============================================================================

export type L = { ar: string; en: string };

/** g/cm³ — the widely published figures for these grades. */
export type Grade = { id: string; name: L; density: number; note?: L };

export const GRADES: Grade[] = [
  { id: '304', name: { ar: '304 / 304L', en: '304 / 304L' }, density: 8.0, note: { ar: 'الأوستنيتي الشائع', en: 'Common austenitic' } },
  { id: '316', name: { ar: '316 / 316L', en: '316 / 316L' }, density: 8.0, note: { ar: 'مقاوم للكلوريدات', en: 'Chloride resistant' } },
  { id: '321', name: { ar: '321', en: '321' }, density: 8.03, note: { ar: 'مثبّت بالتيتانيوم — حرارة عالية', en: 'Ti-stabilised — high temp' } },
  { id: '904L', name: { ar: '904L', en: '904L' }, density: 8.0, note: { ar: 'سبيكة عالية', en: 'High alloy' } },
  { id: '2205', name: { ar: 'دوبلكس 2205', en: 'Duplex 2205' }, density: 7.8, note: { ar: 'مقاومة أعلى', en: 'Higher strength' } },
  { id: '2507', name: { ar: 'سوبر دوبلكس 2507', en: 'Super duplex 2507' }, density: 7.8 },
  { id: '430', name: { ar: '430', en: '430' }, density: 7.7, note: { ar: 'فريتي — ممغنط', en: 'Ferritic — magnetic' } },
  { id: '410', name: { ar: '410', en: '410' }, density: 7.75, note: { ar: 'مارتنزيتي', en: 'Martensitic' } },
  { id: 'carbon', name: { ar: 'كربوني (ST37 / A36)', en: 'Carbon (ST37 / A36)' }, density: 7.85 },
  { id: 'alu', name: { ar: 'ألومنيوم', en: 'Aluminium' }, density: 2.7 },
  { id: 'copper', name: { ar: 'نحاس', en: 'Copper' }, density: 8.94 },
  { id: 'brass', name: { ar: 'نحاس أصفر', en: 'Brass' }, density: 8.5 },
];

// ── sections ────────────────────────────────────────────────────────────────
// Each returns cross-sectional area in mm². Length is applied separately, so
// a sheet and a bar go through exactly the same final multiply.

export type FieldDef = { key: string; label: L; unit: string; def?: number };

export type Section = {
  id: string;
  name: L;
  fields: FieldDef[];
  /** cross-section area, mm² */
  area: (v: Record<string, number>) => number;
  /** the working, rendered for the person reading the result */
  formula: L;
};

const mm = 'مم';

export const SECTIONS: Section[] = [
  {
    id: 'sheet',
    name: { ar: 'لوح / صاج', en: 'Sheet / plate' },
    fields: [
      { key: 'w', label: { ar: 'العرض', en: 'Width' }, unit: mm, def: 1250 },
      { key: 't', label: { ar: 'السمك', en: 'Thickness' }, unit: mm, def: 2 },
    ],
    area: (v) => v.w * v.t,
    formula: { ar: 'العرض × السمك × الطول × الكثافة', en: 'W × T × L × ρ' },
  },
  {
    id: 'circle',
    name: { ar: 'دائرة / قرص', en: 'Circle / disc' },
    fields: [
      { key: 'd', label: { ar: 'القطر', en: 'Diameter' }, unit: mm, def: 500 },
      { key: 't', label: { ar: 'السمك', en: 'Thickness' }, unit: mm, def: 3 },
    ],
    area: (v) => (Math.PI / 4) * v.d * v.d,
    formula: { ar: '(π ÷ 4) × القطر² × السمك × الكثافة', en: '(π/4) × D² × T × ρ' },
  },
  {
    id: 'pipe',
    name: { ar: 'ماسورة / أنبوبة', en: 'Pipe / tube' },
    fields: [
      { key: 'od', label: { ar: 'القطر الخارجي', en: 'Outside diameter' }, unit: mm, def: 60.3 },
      { key: 't', label: { ar: 'سمك الجدار', en: 'Wall thickness' }, unit: mm, def: 2 },
    ],
    // π/4 (OD² − ID²) reduces to π·t·(OD − t) — same thing, fewer roundings
    area: (v) => Math.PI * v.t * (v.od - v.t),
    formula: { ar: 'π × السمك × (القطر الخارجي − السمك) × الطول × الكثافة', en: 'π × T × (OD − T) × L × ρ' },
  },
  {
    id: 'round-bar',
    name: { ar: 'بار دائري (سيخ)', en: 'Round bar' },
    fields: [{ key: 'd', label: { ar: 'القطر', en: 'Diameter' }, unit: mm, def: 20 }],
    area: (v) => (Math.PI / 4) * v.d * v.d,
    formula: { ar: '(π ÷ 4) × القطر² × الطول × الكثافة', en: '(π/4) × D² × L × ρ' },
  },
  {
    id: 'square-bar',
    name: { ar: 'بار مربع', en: 'Square bar' },
    fields: [{ key: 'a', label: { ar: 'الضلع', en: 'Side' }, unit: mm, def: 20 }],
    area: (v) => v.a * v.a,
    formula: { ar: 'الضلع² × الطول × الكثافة', en: 'A² × L × ρ' },
  },
  {
    id: 'flat-bar',
    name: { ar: 'بار مسطّح (فلات)', en: 'Flat bar' },
    fields: [
      { key: 'w', label: { ar: 'العرض', en: 'Width' }, unit: mm, def: 40 },
      { key: 't', label: { ar: 'السمك', en: 'Thickness' }, unit: mm, def: 5 },
    ],
    area: (v) => v.w * v.t,
    formula: { ar: 'العرض × السمك × الطول × الكثافة', en: 'W × T × L × ρ' },
  },
  {
    id: 'hex-bar',
    name: { ar: 'بار سداسي', en: 'Hex bar' },
    fields: [{ key: 'af', label: { ar: 'بين الوجهين', en: 'Across flats' }, unit: mm, def: 17 }],
    area: (v) => (Math.sqrt(3) / 2) * v.af * v.af,
    formula: { ar: '0.866 × (بين الوجهين)² × الطول × الكثافة', en: '0.866 × AF² × L × ρ' },
  },
  {
    id: 'shs',
    name: { ar: 'مربع مجوف', en: 'Square hollow' },
    fields: [
      { key: 'a', label: { ar: 'الضلع', en: 'Side' }, unit: mm, def: 40 },
      { key: 't', label: { ar: 'السمك', en: 'Thickness' }, unit: mm, def: 2 },
    ],
    // a² − (a−2t)² = 4t(a−t)
    area: (v) => 4 * v.t * (v.a - v.t),
    formula: { ar: '4 × السمك × (الضلع − السمك) × الطول × الكثافة', en: '4 × T × (A − T) × L × ρ' },
  },
  {
    id: 'rhs',
    name: { ar: 'مستطيل مجوف', en: 'Rectangular hollow' },
    fields: [
      { key: 'a', label: { ar: 'الضلع الأول', en: 'Side A' }, unit: mm, def: 60 },
      { key: 'b', label: { ar: 'الضلع الثاني', en: 'Side B' }, unit: mm, def: 40 },
      { key: 't', label: { ar: 'السمك', en: 'Thickness' }, unit: mm, def: 2 },
    ],
    // ab − (a−2t)(b−2t) = 2t(a+b−2t)
    area: (v) => 2 * v.t * (v.a + v.b - 2 * v.t),
    formula: { ar: '2 × السمك × (أ + ب − 2×السمك) × الطول × الكثافة', en: '2 × T × (A + B − 2T) × L × ρ' },
  },
  {
    id: 'angle',
    name: { ar: 'زاوية', en: 'Angle' },
    fields: [
      { key: 'a', label: { ar: 'الجناح الأول', en: 'Leg A' }, unit: mm, def: 40 },
      { key: 'b', label: { ar: 'الجناح الثاني', en: 'Leg B' }, unit: mm, def: 40 },
      { key: 't', label: { ar: 'السمك', en: 'Thickness' }, unit: mm, def: 4 },
    ],
    area: (v) => v.t * (v.a + v.b - v.t),
    formula: { ar: 'السمك × (أ + ب − السمك) × الطول × الكثافة', en: 'T × (A + B − T) × L × ρ' },
  },
  {
    id: 'channel',
    name: { ar: 'قطاع U', en: 'Channel (U)' },
    fields: [
      { key: 'h', label: { ar: 'الارتفاع', en: 'Height' }, unit: mm, def: 50 },
      { key: 'b', label: { ar: 'عرض الجناح', en: 'Flange width' }, unit: mm, def: 25 },
      { key: 't', label: { ar: 'السمك', en: 'Thickness' }, unit: mm, def: 3 },
    ],
    area: (v) => v.t * (v.h + 2 * (v.b - v.t)),
    formula: { ar: 'السمك × (الارتفاع + 2×(عرض الجناح − السمك)) × الطول × الكثافة', en: 'T × (H + 2(B − T)) × L × ρ' },
  },
];

// ── the calculation ─────────────────────────────────────────────────────────

export type Result = {
  areaMm2: number;
  /** kg for one piece */
  perPiece: number;
  /** kg for the whole quantity */
  total: number;
  /** kg per metre — how sections are traded */
  perMetre: number;
};

/**
 * area(mm²) × length(mm) = mm³ → ÷1000 = cm³ → × ρ(g/cm³) = g → ÷1000 = kg
 * which collapses to: area × length × ρ ÷ 1e6
 */
export function calculate(section: Section, values: Record<string, number>, lengthMm: number, density: number, qty = 1): Result {
  const areaMm2 = Math.max(0, section.area(values));
  const perPiece = (areaMm2 * lengthMm * density) / 1e6;
  return {
    areaMm2,
    perPiece,
    total: perPiece * qty,
    perMetre: (areaMm2 * 1000 * density) / 1e6,
  };
}

// ── standard tables ─────────────────────────────────────────────────────────

/** ASME B36.19M — stainless process pipe. Wall thickness in mm by schedule. */
export const PIPE_SCHEDULE = {
  headers: ['DN', 'NPS', 'OD', '5S', '10S', '40S', '80S'],
  rows: [
    ['15', '½"', '21.3', '1.65', '2.11', '2.77', '3.73'],
    ['20', '¾"', '26.7', '1.65', '2.11', '2.87', '3.91'],
    ['25', '1"', '33.4', '1.65', '2.77', '3.38', '4.55'],
    ['32', '1¼"', '42.2', '1.65', '2.77', '3.56', '4.85'],
    ['40', '1½"', '48.3', '1.65', '2.77', '3.68', '5.08'],
    ['50', '2"', '60.3', '1.65', '2.77', '3.91', '5.54'],
    ['65', '2½"', '73.0', '2.11', '3.05', '5.16', '7.01'],
    ['80', '3"', '88.9', '2.11', '3.05', '5.49', '7.62'],
    ['100', '4"', '114.3', '2.11', '3.05', '6.02', '8.56'],
    ['125', '5"', '141.3', '2.77', '3.40', '6.55', '9.53'],
    ['150', '6"', '168.3', '2.77', '3.40', '7.11', '10.97'],
    ['200', '8"', '219.1', '2.77', '3.76', '8.18', '12.70'],
    ['250', '10"', '273.0', '3.40', '4.19', '9.27', '12.70'],
    ['300', '12"', '323.8', '3.96', '4.57', '9.53', '12.70'],
  ],
};

/** Hygienic tube — sized on OD, not NPS. This is what food and dairy lines run. */
export const SANITARY_TUBE = {
  headers: ['المقاس', 'OD', 'السمك', 'ID'],
  rows: [
    ['1"', '25.4', '1.65', '22.10'],
    ['1½"', '38.1', '1.65', '34.80'],
    ['2"', '50.8', '1.65', '47.50'],
    ['2½"', '63.5', '1.65', '60.20'],
    ['3"', '76.2', '1.65', '72.90'],
    ['4"', '101.6', '2.11', '97.38'],
    ['6"', '152.4', '2.77', '146.86'],
  ],
};

/** What the mills actually roll, and what we hold. */
export const SHEET_STOCK = {
  thicknesses: ['0.5', '0.6', '0.8', '1.0', '1.2', '1.5', '2.0', '2.5', '3.0', '4.0', '5.0', '6.0', '8.0', '10', '12', '15', '20', '25', '30'],
  sizes: ['1000 × 2000', '1250 × 2500', '1500 × 3000', '1500 × 6000', '2000 × 6000'],
};

/** EN 10088-2 / ASTM A480 thickness tolerance on cold-rolled sheet — why the
 *  delivered weight is never exactly the calculated one. */
export const THICKNESS_TOLERANCE = [
  { range: '0.5 – 1.0', tol: '± 0.05' },
  { range: '1.0 – 2.0', tol: '± 0.08' },
  { range: '2.0 – 3.0', tol: '± 0.11' },
  { range: '3.0 – 5.0', tol: '± 0.15' },
  { range: '5.0 – 8.0', tol: '± 0.20' },
];
