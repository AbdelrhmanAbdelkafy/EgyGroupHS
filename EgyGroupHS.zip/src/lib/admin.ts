import crypto from 'crypto';
import { cookies } from 'next/headers';

// ============================================================================
// Admin access — a single shared password, held in the environment.
//
// This guards content editing, not customer data, and there is one operator.
// A user table would be ceremony without benefit. The cookie is signed with the
// same secret as customer sessions but under a different name and payload, so
// the two can never be confused for one another.
// ============================================================================

const SECRET = process.env.SESSION_SECRET || 'dev-only-secret-change-me';
const PASSWORD = process.env.ADMIN_PASSWORD || '';
const COOKIE = 'hs_admin';
const MAX_AGE = 60 * 60 * 12; // 12h — an editing session, not a permanent key

function sign(v: string) {
  return crypto.createHmac('sha256', SECRET).update(`admin:${v}`).digest('hex');
}

export function adminConfigured() {
  return PASSWORD.length >= 8;
}

export function checkPassword(input: string) {
  if (!adminConfigured()) return false;
  const a = Buffer.from(crypto.createHash('sha256').update(input).digest('hex'));
  const b = Buffer.from(crypto.createHash('sha256').update(PASSWORD).digest('hex'));
  return a.length === b.length && crypto.timingSafeEqual(a, b);
}

export function setAdminCookie() {
  const ts = String(Date.now());
  cookies().set(COOKIE, `${ts}.${sign(ts)}`, {
    httpOnly: true,
    sameSite: 'strict',
    secure: process.env.NODE_ENV === 'production',
    path: '/',
    maxAge: MAX_AGE,
  });
}

export function clearAdminCookie() {
  cookies().set(COOKIE, '', { httpOnly: true, path: '/', maxAge: 0 });
}

export function isAdmin(): boolean {
  const raw = cookies().get(COOKIE)?.value;
  if (!raw) return false;
  const [ts, sig] = raw.split('.');
  if (!ts || !sig) return false;
  const expected = sign(ts);
  const a = Buffer.from(sig);
  const b = Buffer.from(expected);
  if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) return false;
  return Date.now() - Number(ts) < MAX_AGE * 1000;
}
