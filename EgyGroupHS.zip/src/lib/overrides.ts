import fs from 'fs';
import path from 'path';

// ============================================================================
// Image overrides.
//
// The catalogue's images live in src/content/catalog.ts — source code, which a
// deploy overwrites. So the content manager never touches it. It writes here
// instead, to .data, which the deploy copies across.
//
// Reading is a merge: an override replaces a product's image list entirely; a
// product with no override keeps whatever the source file says. Nothing is lost
// if this file is deleted — the site simply falls back to the original images.
// ============================================================================

export type Overrides = Record<string, string[]>;

const DATA_DIR = process.env.DATA_DIR || path.join(process.cwd(), '.data');
const FILE = path.join(DATA_DIR, 'image-overrides.json');

export function readOverrides(): Overrides {
  try {
    if (!fs.existsSync(FILE)) return {};
    return JSON.parse(fs.readFileSync(FILE, 'utf8')) as Overrides;
  } catch {
    // a corrupt override file must never take the catalogue down
    return {};
  }
}

export function writeOverrides(next: Overrides) {
  if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
  fs.writeFileSync(FILE, JSON.stringify(next, null, 2), 'utf8');
}

export function setImages(slug: string, images: string[]) {
  const all = readOverrides();
  if (images.length === 0) delete all[slug]; // empty = back to the source images
  else all[slug] = images;
  writeOverrides(all);
  return all;
}

/** The images a product should actually show. */
export function imagesFor(slug: string, fallback: string[]): string[] {
  const o = readOverrides()[slug];
  return o && o.length ? o : fallback;
}


/**
 * Services and products are separate lists that happen to share three slugs —
 * tanks, machining and heat-exchangers name both a product and a service. They
 * are stored under one overrides file, so a service's key is prefixed; without
 * it, re-photographing the tanks service would silently re-photograph the tanks
 * product too.
 */
export const serviceKey = (slug: string) => `service:${slug}`;
