import crypto from 'crypto';

// ============================================================================
// VTiger CRM client.
// Field names below are verified against the live instance (crm.stlixvalley.com):
//   Leads  → firstname, phone, leadsource, assigned_user_id are mandatory
//   Events → subject, assigned_user_id, date_start, time_start, due_date,
//            time_end, duration_hours, parent_id, eventstatus, activitytype
//            (activitytype has a "Visit" option — that's the engineer's site visit)
// ============================================================================

const VT_URL = process.env.VTIGER_URL || 'https://crm.stlixvalley.com';
const VT_USER = process.env.VTIGER_USERNAME || '';
const VT_KEY = process.env.VTIGER_ACCESS_KEY || '';

/** Call Center — verified user id. Overridable per-flow. */
export const ASSIGNEE_CALLCENTER = process.env.VTIGER_ASSIGNEE || '19x753';
/** Product sales — where site-visit requests should land. */
export const ASSIGNEE_SALES = process.env.VTIGER_SALES_ASSIGNEE || ASSIGNEE_CALLCENTER;

export function crmConfigured() {
  return Boolean(VT_USER && VT_KEY);
}

export async function vtLogin(): Promise<string | null> {
  try {
    const chRes = await fetch(`${VT_URL}/webservice.php?operation=getchallenge&username=${encodeURIComponent(VT_USER)}`, {
      cache: 'no-store',
    });
    const ch = await chRes.json();
    if (!ch?.success) return null;
    const accessKey = crypto.createHash('md5').update(ch.result.token + VT_KEY).digest('hex');
    const res = await fetch(`${VT_URL}/webservice.php`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({ operation: 'login', username: VT_USER, accessKey }),
      cache: 'no-store',
    });
    const lg = await res.json();
    return lg?.success ? (lg.result.sessionName as string) : null;
  } catch {
    return null;
  }
}

export async function vtCreate(sessionName: string, elementType: string, element: Record<string, unknown>) {
  const res = await fetch(`${VT_URL}/webservice.php`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams({
      operation: 'create',
      sessionName,
      elementType,
      element: JSON.stringify(element),
    }),
    cache: 'no-store',
  });
  const out = await res.json();
  if (!out?.success) {
    console.error(`[crm] create ${elementType} failed:`, JSON.stringify(out?.error));
    return null;
  }
  return out.result as Record<string, string>;
}

export type LeadInput = {
  name: string;
  company?: string;
  phone: string;
  email?: string;
  subject: string;
  description: string;
  assignee?: string;
};

export async function createLead(sessionName: string, input: LeadInput) {
  return vtCreate(sessionName, 'Leads', {
    firstname: input.name.trim(),
    lastname: input.company?.trim() || input.name.trim(),
    company: input.company?.trim() || 'غير محدّد',
    phone: input.phone.trim(),
    email: input.email?.trim() || '',
    leadsource: 'Website',
    industry: 'Manufacturing',
    assigned_user_id: input.assignee || ASSIGNEE_CALLCENTER,
    cf_2262: input.subject,
    description: input.description,
    cf_905: 'Egypt',
    cf_1963: 'Inbound',
  });
}

export type VisitInput = {
  subject: string;
  /** yyyy-mm-dd */
  date: string;
  /** HH:MM (24h) */
  time: string;
  /** minutes */
  durationMins?: number;
  description: string;
  parentId: string;
  assignee?: string;
};

function addMinutes(time: string, mins: number) {
  const [h, m] = time.split(':').map(Number);
  const total = h * 60 + m + mins;
  const hh = String(Math.floor((total % (24 * 60)) / 60)).padStart(2, '0');
  const mm = String(total % 60).padStart(2, '0');
  return `${hh}:${mm}`;
}

/** Books the engineer's site visit in the CRM calendar, linked to the lead. */
export async function createVisitEvent(sessionName: string, input: VisitInput) {
  const dur = input.durationMins ?? 60;
  return vtCreate(sessionName, 'Events', {
    subject: input.subject,
    assigned_user_id: input.assignee || ASSIGNEE_SALES,
    date_start: input.date,
    time_start: `${input.time}:00`,
    due_date: input.date,
    time_end: `${addMinutes(input.time, dur)}:00`,
    duration_hours: Math.max(1, Math.round(dur / 60)),
    duration_minutes: '00',
    parent_id: input.parentId,
    eventstatus: 'لم يتم بعد',
    activitytype: 'Visit',
    visibility: 'Public',
    cf_2274: input.description,
  });
}
