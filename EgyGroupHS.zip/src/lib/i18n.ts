export const locales = ['ar', 'en'] as const;
export type Locale = (typeof locales)[number];
export const defaultLocale: Locale = 'ar';

export const dir = (locale: Locale): 'rtl' | 'ltr' => (locale === 'ar' ? 'rtl' : 'ltr');

export function isLocale(x: string): x is Locale {
  return (locales as readonly string[]).includes(x);
}

// The opposite locale (for the language switcher)
export const other = (locale: Locale): Locale => (locale === 'ar' ? 'en' : 'ar');
