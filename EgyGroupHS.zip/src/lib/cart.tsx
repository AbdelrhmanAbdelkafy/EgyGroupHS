'use client';

// ============================================================================
// Cart — for products that are ready to sell, or whose spec the customer has
// already pinned down. It ends in a price request.
//
// It is NOT a brief for a site visit. Anything needing an engineer on site
// goes through /site-visit: a separate flow, its own form, its own CRM
// destination, and a booked appointment in the engineer's calendar.
//
// Persisted in localStorage so a half-filled basket survives a refresh.
// ============================================================================

import { createContext, useContext, useEffect, useState, ReactNode, useCallback } from 'react';

export type CartSpec = { label: string; value: string };

export type CartItem = {
  /** identity is the spec combination — same product at two specs = two lines */
  key: string;
  slug: string;
  name: string;
  image: string;
  specs: CartSpec[];
  qty: number;
};

type CartCtx = {
  items: CartItem[];
  count: number;
  add: (item: Omit<CartItem, 'key' | 'qty'>, qty?: number) => void;
  remove: (key: string) => void;
  setQty: (key: string, qty: number) => void;
  clear: () => void;
  ready: boolean;
};

const Ctx = createContext<CartCtx | null>(null);
const STORAGE = 'hs_cart_v2';

function makeKey(slug: string, specs: CartSpec[]) {
  return slug + '|' + specs.map((s) => `${s.label}=${s.value}`).join(';');
}

export function CartProvider({ children }: { children: ReactNode }) {
  const [items, setItems] = useState<CartItem[]>([]);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    try {
      const raw = localStorage.getItem(STORAGE);
      if (raw) setItems(JSON.parse(raw) as CartItem[]);
    } catch {
      /* a corrupted cart must not break the page */
    }
    setReady(true);
  }, []);

  useEffect(() => {
    if (!ready) return;
    try {
      localStorage.setItem(STORAGE, JSON.stringify(items));
    } catch {
      /* quota or private mode — the cart just won't persist */
    }
  }, [items, ready]);

  const add: CartCtx['add'] = useCallback((item, qty = 1) => {
    const key = makeKey(item.slug, item.specs);
    setItems((prev) => {
      const i = prev.findIndex((l) => l.key === key);
      if (i >= 0) {
        const next = [...prev];
        next[i] = { ...next[i], qty: next[i].qty + qty };
        return next;
      }
      return [...prev, { ...item, key, qty }];
    });
  }, []);

  const remove: CartCtx['remove'] = useCallback((key) => {
    setItems((prev) => prev.filter((l) => l.key !== key));
  }, []);

  const setQty: CartCtx['setQty'] = useCallback((key, qty) => {
    setItems((prev) => (qty <= 0 ? prev.filter((l) => l.key !== key) : prev.map((l) => (l.key === key ? { ...l, qty } : l))));
  }, []);

  const clear = useCallback(() => setItems([]), []);
  const count = items.reduce((n, l) => n + l.qty, 0);

  return <Ctx.Provider value={{ items, count, add, remove, setQty, clear, ready }}>{children}</Ctx.Provider>;
}

export function useCart() {
  const c = useContext(Ctx);
  if (!c) throw new Error('useCart must be used inside <CartProvider>');
  return c;
}
