// ============================================================================
// Reading uploaded files out of a FormData, without depending on `File`.
//
// `File` only became a Node global in v20. On Node 18 — which is what this
// server runs — `x instanceof File` throws ReferenceError, so an upload route
// written that way dies before it writes anything, and the failure looks like
// "nothing happened" rather than an error.
//
// The shape is what matters, not the constructor: anything carrying a name, a
// type, a size and arrayBuffer() can be read. That holds on every Node version
// and under every runtime Next might use.
// ============================================================================

export type FormFile = {
  name: string;
  type: string;
  size: number;
  arrayBuffer(): Promise<ArrayBuffer>;
};

export function isFormFile(v: unknown): v is FormFile {
  if (typeof v !== 'object' || v === null) return false;
  const o = v as Record<string, unknown>;
  return (
    typeof o.arrayBuffer === 'function' &&
    typeof o.type === 'string' &&
    typeof o.size === 'number' &&
    typeof o.name === 'string'
  );
}

/** Every file-like entry under a field name. */
export function filesFrom(form: FormData, field: string): FormFile[] {
  const out: FormFile[] = [];
  for (const v of form.getAll(field) as unknown[]) if (isFormFile(v)) out.push(v);
  return out;
}

/** The first file-like entry, or null. */
export function fileFrom(form: FormData, field: string): FormFile | null {
  const v = form.get(field) as unknown;
  return isFormFile(v) ? v : null;
}
