import fs from 'fs';
import path from 'path';
import crypto from 'crypto';

// ============================================================================
// Customer accounts — a small JSON store on disk.
// Deliberately dependency-free: Node's own scrypt does the hashing, so there's
// no native module to break the build. Scale here is hundreds of B2B accounts,
// not millions; if that changes, swap the read/write for Postgres and keep the API.
// ============================================================================

export type User = {
  id: string;
  name: string;
  company: string;
  phone: string;
  email: string;
  passHash: string;
  createdAt: string;
};

const DATA_DIR = process.env.DATA_DIR || path.join(process.cwd(), '.data');
const FILE = path.join(DATA_DIR, 'users.json');

function ensure() {
  if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
  if (!fs.existsSync(FILE)) fs.writeFileSync(FILE, '[]', 'utf8');
}

function readAll(): User[] {
  ensure();
  try {
    return JSON.parse(fs.readFileSync(FILE, 'utf8')) as User[];
  } catch {
    return [];
  }
}

function writeAll(users: User[]) {
  ensure();
  fs.writeFileSync(FILE, JSON.stringify(users, null, 2), 'utf8');
}

/** Phone is the login handle — B2B customers remember it; emails change. */
export function normalisePhone(p: string) {
  return p.replace(/[\s\-()]/g, '').replace(/^\+?2/, '');
}

export function hashPassword(password: string): string {
  const salt = crypto.randomBytes(16).toString('hex');
  const key = crypto.scryptSync(password, salt, 64).toString('hex');
  return `${salt}:${key}`;
}

export function verifyPassword(password: string, stored: string): boolean {
  const [salt, key] = stored.split(':');
  if (!salt || !key) return false;
  const test = crypto.scryptSync(password, salt, 64).toString('hex');
  // timing-safe compare
  const a = Buffer.from(key, 'hex');
  const b = Buffer.from(test, 'hex');
  return a.length === b.length && crypto.timingSafeEqual(a, b);
}

export function findByPhone(phone: string): User | undefined {
  const p = normalisePhone(phone);
  return readAll().find((u) => normalisePhone(u.phone) === p);
}

export function findById(id: string): User | undefined {
  return readAll().find((u) => u.id === id);
}

export function createUser(input: Omit<User, 'id' | 'passHash' | 'createdAt'> & { password: string }): User {
  const users = readAll();
  const user: User = {
    id: crypto.randomUUID(),
    name: input.name.trim(),
    company: input.company.trim(),
    phone: input.phone.trim(),
    email: input.email.trim(),
    passHash: hashPassword(input.password),
    createdAt: new Date().toISOString(),
  };
  users.push(user);
  writeAll(users);
  return user;
}

/** Never leak the hash to the client. */
export function publicUser(u: User) {
  const { passHash, ...rest } = u;
  return rest;
}
