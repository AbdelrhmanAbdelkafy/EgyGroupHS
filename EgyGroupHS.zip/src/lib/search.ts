import { masterItems } from '@/content/catalog';
import { services, nav } from '@/content/site';
import { Locale } from '@/lib/i18n';

// ============================================================================
// Search.
//
// The whole corpus is ~50 entries, so there is no index to build and no library
// to pull in: normalise, substring-match, rank, done. It runs in under a
// millisecond on a phone, which is the only performance target that matters.
//
// The real work is Arabic normalisation. Someone typing "تنكات" and someone
// typing "تنكات" may be sending different bytes (hamza forms, ta marbuta,
// alef maqsura, diacritics, tatweel). Without folding those, search silently
// fails on the exact words customers actually use.
// ============================================================================

export type SearchHit = {
  title: string;
  subtitle: string;
  href: string;
  kind: 'product' | 'service' | 'page';
  kindLabel: string;
};

const DIACRITICS = /[\u0610-\u061A\u064B-\u065F\u0670\u06D6-\u06ED]/g;
const TATWEEL = /\u0640/g;

/** Fold the spelling variants people actually type. */
export function normalise(input: string): string {
  return input
    .toLowerCase()
    .replace(DIACRITICS, '')
    .replace(TATWEEL, '')
    .replace(/[أإآٱ]/g, 'ا')
    .replace(/ى/g, 'ي')
    .replace(/ؤ/g, 'و')
    .replace(/ئ/g, 'ي')
    .replace(/ة/g, 'ه')
    .replace(/[ـ'`"’،,\-–—_/\\().]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

/**
 * Arabic broken plurals defeat substring matching: محبس → محابس, ماسورة → مواسير.
 * The letters themselves change, so "حبس" never matches "محابس" no matter how
 * well you normalise. There's no rule to derive these — the pairs get listed.
 * Each group is written into the entry's haystack, so any member finds the rest,
 * and the English term finds the Arabic page.
 */
const ALIASES: string[][] = [
  ['تنك', 'تنكات', 'خزان', 'خزانات', 'صهريج', 'tank', 'tanks', 'vessel'],
  ['ماسورة', 'مواسير', 'ماسور', 'انبوبة', 'انابيب', 'pipe', 'pipes', 'tube', 'piping'],
  ['محبس', 'محابس', 'حبس', 'صمام', 'صمامات', 'valve', 'valves'],
  ['لوح', 'الواح', 'صاج', 'sheet', 'sheets', 'plate'],
  ['كوع', 'اكواع', 'كواع', 'elbow', 'elbows', 'fitting', 'fittings'],
  ['كرسي', 'كراسي', 'chair', 'chairs'],
  ['ترابيزة', 'ترابيزات', 'طاولة', 'table', 'tables'],
  ['فلنجة', 'فلنجات', 'flange', 'flanges'],
  ['كونشة', 'كونشات', 'شوكولاتة', 'شيكولاتة', 'conche', 'conching', 'chocolate'],
  ['كسارة', 'كسارات', 'طاحونة', 'crusher', 'crushers', 'mill'],
  ['طباخة', 'طباخات', 'حلة', 'cooker', 'cookers', 'kettle'],
  ['ميكسر', 'ميكسرات', 'خلاط', 'خلاطات', 'mixer', 'mixers', 'agitator'],
  ['بلندر', 'بلندرات', 'blender', 'blenders'],
  ['فلتر', 'فلاتر', 'مرشح', 'filter', 'filters', 'baghouse', 'cyclone'],
  ['سير', 'سيور', 'ناقل', 'conveyor', 'conveyors'],
  ['مبادل', 'مبادلات', 'heat exchanger', 'exchanger'],
  ['سلم', 'سلالم', 'ladder', 'ladders', 'stairs'],
  ['منصة', 'منصات', 'بلاتفورم', 'platform', 'platforms'],
  ['حوض', 'احواض', 'sink', 'sinks', 'basin'],
  ['رف', 'ارفف', 'shelf', 'shelving'],
  ['مسمار', 'مسامير', 'صامولة', 'bolt', 'bolts', 'fastener'],
  ['كويل', 'لفيفة', 'لفائف', 'coil', 'coils'],
  ['خراطة', 'تفريز', 'machining', 'turning', 'cnc'],
  ['غذائي', 'اغذية', 'طعام', 'البان', 'food', 'food grade', 'dairy', 'sanitary'],
  ['حقن', 'back purge', 'purge', 'purging'],
  ['اوربيتال', 'orbital'],
  ['ارجون', 'argon', 'tig'],
  ['ليزر', 'laser'],
  ['معاينة', 'مقاس', 'زيارة', 'visit', 'survey'],
];

/** Every alias group that the text touches gets folded into the haystack. */
function withAliases(hay: string): string {
  const extra: string[] = [];
  for (const group of ALIASES) {
    if (group.some((term) => hay.includes(normalise(term)))) {
      extra.push(...group.map(normalise));
    }
  }
  return extra.length ? `${hay} ${extra.join(' ')}` : hay;
}

type Entry = {
  title: string;
  subtitle: string;
  href: string;
  kind: SearchHit['kind'];
  kindLabel: string;
  /** normalised name — a hit here ranks highest */
  n: string;
  /** everything else, normalised — body, specs, the other language */
  hay: string;
};

/** Both languages go into every entry, so an Arabic page is findable by "tank". */
export function buildIndex(locale: Locale): Entry[] {
  const isAr = locale === 'ar';
  const out: Entry[] = [];

  for (const item of masterItems) {
    const title = item.name[locale];
    const other = item.name[isAr ? 'en' : 'ar'];
    const specValues = item.options
      .flatMap((o) => [o.label.ar, o.label.en, ...(o.values?.flatMap((v) => [v.ar, v.en]) ?? [])])
      .join(' ');
    out.push({
      title,
      subtitle: item.tagline[locale],
      href: `/${locale}/catalog/${item.slug}`,
      kind: 'product',
      kindLabel: item.family === 'standard' ? (isAr ? 'مخزون' : 'Stock') : (isAr ? 'صناعي' : 'Industrial'),
      n: normalise(title),
      hay: withAliases(
        normalise(
          [
            other,
            item.tagline.ar, item.tagline.en,
            item.body.ar, item.body.en,
            (item.facts ?? []).map((f) => `${f.ar} ${f.en}`).join(' '),
            specValues,
            item.slug.replace(/-/g, ' '),
          ].join(' ')
        )
      ),
    });
  }

  for (const sv of services.items) {
    const title = sv.title[locale];
    out.push({
      title,
      subtitle: sv.desc[locale],
      href: `/${locale}/services#${sv.slug}`,
      kind: 'service',
      kindLabel: isAr ? 'خدمة' : 'Service',
      n: normalise(title),
      hay: withAliases(normalise([sv.title.ar, sv.title.en, sv.desc.ar, sv.desc.en, sv.slug.replace(/-/g, ' ')].join(' '))),
    });
  }

  for (const item of nav) {
    const title = item.label[locale];
    out.push({
      title,
      subtitle: '',
      href: `/${locale}${item.href}`,
      kind: 'page',
      kindLabel: isAr ? 'صفحة' : 'Page',
      n: normalise(title),
      hay: normalise([item.label.ar, item.label.en].join(' ')),
    });
  }

  return out;
}

/**
 * Rank: exact name, then name prefix, then name contains, then body contains.
 * Multi-word queries must match every word — "تنك خلط" shouldn't return
 * everything containing "تنك".
 */
export function search(index: Entry[], query: string, limit = 8): SearchHit[] {
  const q = normalise(query);
  if (q.length < 2) return [];
  const words = q.split(' ').filter(Boolean);

  const scored: { e: Entry; score: number }[] = [];
  for (const e of index) {
    const all = `${e.n} ${e.hay}`;
    if (!words.every((w) => all.includes(w))) continue;

    let score = 0;
    if (e.n === q) score = 100;
    else if (e.n.startsWith(q)) score = 80;
    else if (e.n.includes(q)) score = 60;
    else if (words.every((w) => e.n.includes(w))) score = 40;
    else score = 20;

    if (e.kind === 'product') score += 5; // products are what people come for
    scored.push({ e, score });
  }

  scored.sort((a, b) => b.score - a.score || a.e.title.localeCompare(b.e.title));
  return scored.slice(0, limit).map(({ e }) => ({
    title: e.title,
    subtitle: e.subtitle,
    href: e.href,
    kind: e.kind,
    kindLabel: e.kindLabel,
  }));
}
