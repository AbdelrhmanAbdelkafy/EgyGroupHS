import fs from 'fs';
import path from 'path';
import crypto from 'crypto';

// ============================================================================
// Uploaded images.
//
// They go to .data/uploads, not public/. Anything under public/ arrives from the
// deployment zip, so a deploy would silently delete every photo the operator had
// added. .data is copied across on deploy, so it survives — which is the whole
// point of letting someone upload in the first place.
//
// The trade-off is that these can't be served as static files. A route handler
// serves them instead, with a long cache header: the filename contains a hash of
// the contents, so a given URL can never change meaning.
// ============================================================================

const DATA_DIR = process.env.DATA_DIR || path.join(process.cwd(), '.data');
export const UPLOAD_DIR = path.join(DATA_DIR, 'uploads');
const META = path.join(DATA_DIR, 'uploads.json');

export type Upload = { file: string; name: string; at: number; size: number };

const EXT: Record<string, string> = {
  'image/jpeg': 'jpg',
  'image/png': 'png',
  'image/webp': 'webp',
};

export function extFor(mime: string) {
  return EXT[mime];
}

export function readMeta(): Upload[] {
  try {
    if (!fs.existsSync(META)) return [];
    return JSON.parse(fs.readFileSync(META, 'utf8')) as Upload[];
  } catch {
    return [];
  }
}

function writeMeta(list: Upload[]) {
  if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
  fs.writeFileSync(META, JSON.stringify(list, null, 2), 'utf8');
}

export function saveUpload(buf: Buffer, mime: string, originalName: string): Upload {
  const ext = extFor(mime);
  if (!ext) throw new Error('unsupported_type');
  if (!fs.existsSync(UPLOAD_DIR)) fs.mkdirSync(UPLOAD_DIR, { recursive: true });

  // content hash: the same photo uploaded twice is one file, and the URL is stable
  const hash = crypto.createHash('sha256').update(buf).digest('hex').slice(0, 16);
  const file = `${hash}.${ext}`;
  fs.writeFileSync(path.join(UPLOAD_DIR, file), buf);

  const list = readMeta();
  const existing = list.find((u) => u.file === file);
  if (existing) return existing;

  const rec: Upload = { file, name: originalName.slice(0, 80), at: Date.now(), size: buf.length };
  writeMeta([rec, ...list]);
  return rec;
}

export function deleteUpload(file: string): boolean {
  // never let a name escape the uploads directory
  if (!/^[a-f0-9]{16}\.(jpg|png|webp)$/.test(file)) return false;
  const p = path.join(UPLOAD_DIR, file);
  try {
    if (fs.existsSync(p)) fs.unlinkSync(p);
  } catch {
    return false;
  }
  writeMeta(readMeta().filter((u) => u.file !== file));
  return true;
}

export function readUpload(file: string): { buf: Buffer; mime: string } | null {
  if (!/^[a-f0-9]{16}\.(jpg|png|webp)$/.test(file)) return null;
  const p = path.join(UPLOAD_DIR, file);
  if (!fs.existsSync(p)) return null;
  const ext = file.split('.').pop()!;
  const mime = ext === 'jpg' ? 'image/jpeg' : ext === 'png' ? 'image/png' : 'image/webp';
  return { buf: fs.readFileSync(p), mime };
}

/** The public URL for an upload. */
export const urlFor = (file: string) => `/api/img/${file}`;
