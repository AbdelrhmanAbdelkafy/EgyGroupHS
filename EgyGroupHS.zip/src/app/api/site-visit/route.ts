import { NextRequest, NextResponse } from 'next/server';
import { crmConfigured, vtLogin, createLead, createVisitEvent, ASSIGNEE_SALES } from '@/lib/crm';
import { currentUserId } from '@/lib/session';
import { findById } from '@/lib/users';

// ============================================================================
// POST /api/site-visit
// A request for an engineer to come and take measurements.
//
// Creates TWO records in the CRM:
//   1. Lead  — the customer and what they want
//   2. Event (activitytype = "Visit") — the appointment, in the engineer's
//      calendar, linked to that Lead
//
// The point of the payload below: the engineer should never have to phone the
// customer to find out where to go, when, what for, or who lets him in.
// ============================================================================

type Body = {
  subject: string;        // بخصوص إيه
  address: string;        // المكان
  mapUrl?: string;        // لينك خرايط (اختياري)
  date: string;           // yyyy-mm-dd
  time: string;           // HH:MM
  receiverName: string;   // مين هيستقبل المهندس
  receiverPhone: string;  // تليفونه
  notes?: string;
  voiceUrl?: string;      // رابط التسجيل الصوتي
  // guest-only (ignored when logged in)
  name?: string;
  company?: string;
  phone?: string;
  email?: string;
  locale?: 'ar' | 'en';
};

function buildDescription(b: Body, base: string, requester: { name: string; company: string; phone: string; email: string }) {
  const isAr = b.locale !== 'en';
  const L: string[] = [];
  L.push(isAr ? '═══ طلب معاينة — رفع مقاسات ═══' : '═══ SITE VISIT REQUEST — measurement ═══');
  L.push('');
  L.push(isAr ? `▸ بخصوص: ${b.subject}` : `▸ Subject: ${b.subject}`);
  L.push(isAr ? `▸ الموعد: ${b.date} — الساعة ${b.time}` : `▸ When: ${b.date} at ${b.time}`);
  L.push(isAr ? `▸ المكان: ${b.address}` : `▸ Where: ${b.address}`);
  if (b.mapUrl) L.push(isAr ? `▸ الخريطة: ${b.mapUrl}` : `▸ Map: ${b.mapUrl}`);
  L.push('');
  L.push(isAr ? '— هيستقبل المهندس —' : '— Who receives the engineer —');
  L.push(`${b.receiverName} · ${b.receiverPhone}`);
  L.push('');
  L.push(isAr ? '— طالب المعاينة —' : '— Requested by —');
  L.push(`${requester.name}${requester.company ? ' · ' + requester.company : ''}`);
  L.push(`${requester.phone}${requester.email ? ' · ' + requester.email : ''}`);
  if (b.notes) {
    L.push('');
    L.push(isAr ? '— ملاحظات —' : '— Notes —');
    L.push(b.notes);
  }
  if (b.voiceUrl) {
    L.push('');
    L.push(isAr ? `🎤 تسجيل صوتي من العميل: ${base}${b.voiceUrl}` : `🎤 Customer voice note: ${base}${b.voiceUrl}`);
  }
  return L.join('\n');
}

export async function POST(req: NextRequest) {
  let b: Body;
  try {
    b = (await req.json()) as Body;
  } catch {
    return NextResponse.json({ ok: false, error: 'bad_json' }, { status: 400 });
  }

  // Resolve requester: signed-in profile wins over anything posted from the client.
  const uid = currentUserId();
  const account = uid ? findById(uid) : undefined;
  const requester = account
    ? { name: account.name, company: account.company, phone: account.phone, email: account.email }
    : { name: (b.name || '').trim(), company: (b.company || '').trim(), phone: (b.phone || '').trim(), email: (b.email || '').trim() };

  const missing: string[] = [];
  if (!requester.name) missing.push('name');
  if (!requester.phone) missing.push('phone');
  if (!b.subject?.trim()) missing.push('subject');
  if (!b.address?.trim()) missing.push('address');
  if (!b.date?.trim()) missing.push('date');
  if (!b.time?.trim()) missing.push('time');
  if (!b.receiverName?.trim()) missing.push('receiverName');
  if (!b.receiverPhone?.trim()) missing.push('receiverPhone');
  if (missing.length) {
    return NextResponse.json({ ok: false, error: 'missing_fields', missing }, { status: 422 });
  }

  if (!crmConfigured()) {
    console.error('[site-visit] CRM not configured; request was:', JSON.stringify({ ...b, requester }));
    return NextResponse.json({ ok: false, error: 'crm_not_configured' }, { status: 503 });
  }

  const session = await vtLogin();
  if (!session) return NextResponse.json({ ok: false, error: 'crm_login_failed' }, { status: 502 });

  const isAr = b.locale !== 'en';
  const base = process.env.SITE_URL || 'https://egygrouphs.com';
  const description = buildDescription(b, base, requester);
  const subject = isAr ? `طلب معاينة — ${b.subject}` : `Site visit — ${b.subject}`;

  const lead = await createLead(session, {
    name: requester.name,
    company: requester.company,
    phone: requester.phone,
    email: requester.email,
    subject,
    description,
    assignee: ASSIGNEE_SALES,
  });
  if (!lead?.id) return NextResponse.json({ ok: false, error: 'lead_failed' }, { status: 502 });

  // Book the visit in the calendar. If this fails the lead still stands —
  // sales can schedule manually — so don't fail the whole request.
  const event = await createVisitEvent(session, {
    subject: `${subject} — ${requester.company || requester.name}`,
    date: b.date,
    time: b.time,
    durationMins: 60,
    description,
    parentId: lead.id,
    assignee: ASSIGNEE_SALES,
  });

  return NextResponse.json({
    ok: true,
    lead: lead.lead_no ?? null,
    visitBooked: Boolean(event?.id),
  });
}
