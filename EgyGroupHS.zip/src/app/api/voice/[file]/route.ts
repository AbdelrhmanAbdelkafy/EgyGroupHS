import { NextResponse } from 'next/server';
import fs from 'fs';
import path from 'path';

export const runtime = 'nodejs';

const DIR = process.env.VOICE_DIR || path.join(process.cwd(), '.data', 'voice');

/**
 * Serves a customer's voice note to whoever has the link — the link goes into
 * the CRM lead, so the engineer who opens the record can play it.
 * The name is generated server-side; the pattern check keeps the read inside
 * the directory regardless.
 */
export async function GET(_req: Request, { params }: { params: { file: string } }) {
  if (!/^[a-zA-Z0-9_-]+\.(webm|mp4|ogg|m4a|wav)$/.test(params.file)) {
    return new NextResponse('Not found', { status: 404 });
  }
  const p = path.join(DIR, params.file);
  if (!fs.existsSync(p)) return new NextResponse('Not found', { status: 404 });

  const buf = fs.readFileSync(p);
  const ext = params.file.split('.').pop()!;
  const mime =
    ext === 'webm' ? 'audio/webm' : ext === 'mp4' || ext === 'm4a' ? 'audio/mp4' : ext === 'ogg' ? 'audio/ogg' : 'audio/wav';

  return new NextResponse(new Uint8Array(buf), {
    headers: { 'Content-Type': mime, 'Cache-Control': 'private, max-age=86400', 'Content-Length': String(buf.length) },
  });
}
