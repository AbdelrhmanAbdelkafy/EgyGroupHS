import { NextRequest, NextResponse } from 'next/server';
import fs from 'fs';
import path from 'path';
import crypto from 'crypto';
import { fileFrom } from '@/lib/formfile';

// ============================================================================
// POST /api/voice  (multipart: field "audio")
// Stores the customer's voice note and returns a public URL. The URL goes into
// the CRM record so the engineer can listen before the visit instead of ringing
// the customer to ask what the job is.
// ============================================================================

export const runtime = 'nodejs';

const MAX_BYTES = 8 * 1024 * 1024; // 8 MB — a few minutes of opus is far less
// .data, not public/: public/ comes from the deployment zip, so a deploy would
// delete every recording a customer had left.
const DIR = process.env.VOICE_DIR || path.join(process.cwd(), '.data', 'voice');

const ALLOWED = new Set(['audio/webm', 'audio/ogg', 'audio/mp4', 'audio/mpeg', 'audio/wav']);
const EXT: Record<string, string> = {
  'audio/webm': 'webm',
  'audio/ogg': 'ogg',
  'audio/mp4': 'm4a',
  'audio/mpeg': 'mp3',
  'audio/wav': 'wav',
};

export async function POST(req: NextRequest) {
  let form: FormData;
  try {
    form = await req.formData();
  } catch {
    return NextResponse.json({ ok: false, error: 'bad_form' }, { status: 400 });
  }

  // duck-typed rather than `instanceof File`: that global doesn't exist before
  // Node 20, and this server runs 18 — the check would throw, not return false
  const file = fileFrom(form, 'audio');
  if (!file) {
    return NextResponse.json({ ok: false, error: 'no_audio' }, { status: 422 });
  }
  if (file.size === 0) {
    return NextResponse.json({ ok: false, error: 'empty_audio' }, { status: 422 });
  }
  if (file.size > MAX_BYTES) {
    return NextResponse.json({ ok: false, error: 'too_large' }, { status: 413 });
  }

  // browsers append codec info: "audio/webm;codecs=opus"
  const mime = (file.type || '').split(';')[0].trim();
  if (!ALLOWED.has(mime)) {
    return NextResponse.json({ ok: false, error: 'bad_type', got: mime }, { status: 415 });
  }

  try {
    if (!fs.existsSync(DIR)) fs.mkdirSync(DIR, { recursive: true });
    const name = `${Date.now()}-${crypto.randomBytes(6).toString('hex')}.${EXT[mime]}`;
    const buf = Buffer.from(await file.arrayBuffer());
    fs.writeFileSync(path.join(DIR, name), buf);
    return NextResponse.json({ ok: true, url: `/api/voice/${name}` });
  } catch (e) {
    console.error('[voice] write failed:', e);
    return NextResponse.json({ ok: false, error: 'write_failed' }, { status: 500 });
  }
}
