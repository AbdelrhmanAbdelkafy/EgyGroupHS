import { NextRequest, NextResponse } from 'next/server';
import { findByPhone, verifyPassword, publicUser } from '@/lib/users';
import { setSessionCookie } from '@/lib/session';

export async function POST(req: NextRequest) {
  let b: { phone?: string; password?: string };
  try {
    b = await req.json();
  } catch {
    return NextResponse.json({ ok: false, error: 'bad_json' }, { status: 400 });
  }
  if (!b.phone?.trim() || !b.password) {
    return NextResponse.json({ ok: false, error: 'missing_fields' }, { status: 422 });
  }
  const user = findByPhone(b.phone);
  // identical response for unknown phone and wrong password — don't reveal who exists
  if (!user || !verifyPassword(b.password, user.passHash)) {
    return NextResponse.json({ ok: false, error: 'bad_credentials' }, { status: 401 });
  }
  setSessionCookie(user.id);
  return NextResponse.json({ ok: true, user: publicUser(user) });
}
