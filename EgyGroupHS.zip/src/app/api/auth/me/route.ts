import { NextResponse } from 'next/server';
import { currentUserId } from '@/lib/session';
import { findById, publicUser } from '@/lib/users';

export async function GET() {
  const id = currentUserId();
  if (!id) return NextResponse.json({ ok: true, user: null });
  const user = findById(id);
  return NextResponse.json({ ok: true, user: user ? publicUser(user) : null });
}
