import { NextRequest, NextResponse } from 'next/server';
import { createUser, findByPhone, publicUser } from '@/lib/users';
import { setSessionCookie } from '@/lib/session';

export async function POST(req: NextRequest) {
  let b: { name?: string; company?: string; phone?: string; email?: string; password?: string };
  try {
    b = await req.json();
  } catch {
    return NextResponse.json({ ok: false, error: 'bad_json' }, { status: 400 });
  }
  const { name, company, phone, email, password } = b;
  if (!name?.trim() || !phone?.trim() || !password) {
    return NextResponse.json({ ok: false, error: 'missing_fields' }, { status: 422 });
  }
  if (password.length < 6) {
    return NextResponse.json({ ok: false, error: 'password_too_short' }, { status: 422 });
  }
  if (findByPhone(phone)) {
    return NextResponse.json({ ok: false, error: 'phone_exists' }, { status: 409 });
  }
  const user = createUser({ name, company: company || '', phone, email: email || '', password });
  setSessionCookie(user.id);
  return NextResponse.json({ ok: true, user: publicUser(user) });
}
