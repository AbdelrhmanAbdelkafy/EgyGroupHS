import { NextResponse } from 'next/server';
import fs from 'fs';
import path from 'path';

export const runtime = 'nodejs';

const DIR = path.join(process.env.DATA_DIR || path.join(process.cwd(), '.data'), 'photos');
const SIZES = new Set(['400', '800', '1600']);

/**
 * Serves a library photo from our own disk.
 *
 * The files were resized once, ahead of time — nothing is processed per request,
 * so this is a read and a send. Cached for a year: a photo's id never changes
 * meaning, because a different photo would have a different id.
 */
export async function GET(_req: Request, { params }: { params: { size: string; file: string } }) {
  if (!SIZES.has(params.size)) return new NextResponse('Not found', { status: 404 });

  const file = decodeURIComponent(params.file);
  // no separators, no traversal — ids are flat by construction
  if (!/^[A-Za-z0-9_.-]+\.jpg$/.test(file) || file.includes('..')) {
    return new NextResponse('Not found', { status: 404 });
  }

  const p = path.join(DIR, params.size, file);
  if (!fs.existsSync(p)) return new NextResponse('Not found', { status: 404 });

  const buf = fs.readFileSync(p);
  return new NextResponse(new Uint8Array(buf), {
    headers: {
      'Content-Type': 'image/jpeg',
      'Cache-Control': 'public, max-age=31536000, immutable',
      'Content-Length': String(buf.length),
    },
  });
}
