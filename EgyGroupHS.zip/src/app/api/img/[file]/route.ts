import { NextResponse } from 'next/server';
import { readUpload } from '@/lib/uploads';

export const runtime = 'nodejs';

/**
 * Serves an uploaded image. Public by design — these are product photos.
 * The filename is a content hash, so the response can be cached forever:
 * different content always means a different URL.
 */
export async function GET(_req: Request, { params }: { params: { file: string } }) {
  const hit = readUpload(params.file);
  if (!hit) return new NextResponse('Not found', { status: 404 });

  return new NextResponse(new Uint8Array(hit.buf), {
    headers: {
      'Content-Type': hit.mime,
      'Cache-Control': 'public, max-age=31536000, immutable',
      'Content-Length': String(hit.buf.length),
    },
  });
}
