import { NextRequest, NextResponse } from 'next/server';
import crypto from 'crypto';

// ============================================================================
// POST /api/quote
// Receives a quote request from the catalogue configurator and:
//   1. Creates a Lead in VTiger CRM  (leadsource=Website, assigned to Call Center)
//   2. Optionally mirrors it by email (set QUOTE_EMAIL_TO + SMTP_* to enable)
//
// Field names below are VERIFIED against the live VTiger instance:
//   firstname, phone, leadsource, assigned_user_id  → mandatory
//   company, email, description, cf_2262 (Subject), cf_905 (Country),
//   cf_1963 (Way of Communication), industry
//
// Required env vars (set on the server, never commit them):
//   VTIGER_URL         e.g. https://crm.stlixvalley.com
//   VTIGER_USERNAME    a VTiger username
//   VTIGER_ACCESS_KEY  that user's access key (VTiger → My Preferences)
//   VTIGER_ASSIGNEE    optional, defaults to the Call Center user
// ============================================================================

const VT_URL = process.env.VTIGER_URL || 'https://crm.stlixvalley.com';
const VT_USER = process.env.VTIGER_USERNAME || '';
const VT_KEY = process.env.VTIGER_ACCESS_KEY || '';
const VT_ASSIGNEE = process.env.VTIGER_ASSIGNEE || '19x753'; // Call Center

type QuoteBody = {
  product: string;
  specs: { label: string; value: string }[];
  name: string;
  company?: string;
  email?: string;
  phone: string;
  locale?: 'ar' | 'en';
};

async function vtigerLogin(): Promise<{ sessionName: string } | null> {
  try {
    // 1) challenge
    const chRes = await fetch(`${VT_URL}/webservice.php?operation=getchallenge&username=${encodeURIComponent(VT_USER)}`, {
      cache: 'no-store',
    });
    const ch = await chRes.json();
    if (!ch?.success) return null;
    const token: string = ch.result.token;

    // 2) login with md5(token + accessKey)
    const accessKey = crypto.createHash('md5').update(token + VT_KEY).digest('hex');
    const body = new URLSearchParams({ operation: 'login', username: VT_USER, accessKey });
    const lgRes = await fetch(`${VT_URL}/webservice.php`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body,
      cache: 'no-store',
    });
    const lg = await lgRes.json();
    if (!lg?.success) return null;
    return { sessionName: lg.result.sessionName };
  } catch {
    return null;
  }
}

function buildDescription(b: QuoteBody): string {
  const isAr = b.locale !== 'en';
  const lines: string[] = [];
  lines.push(isAr ? '— المواصفات المطلوبة —' : '— Requested specification —');
  for (const s of b.specs) lines.push(`• ${s.label}: ${s.value}`);
  lines.push('');
  lines.push(isAr ? `المصدر: الموقع الإلكتروني — كتالوج (${b.product})` : `Source: Website catalogue (${b.product})`);
  return lines.join('\n');
}

export async function POST(req: NextRequest) {
  let b: QuoteBody;
  try {
    b = (await req.json()) as QuoteBody;
  } catch {
    return NextResponse.json({ ok: false, error: 'bad_json' }, { status: 400 });
  }

  // minimal validation — VTiger requires name + phone
  if (!b?.name?.trim() || !b?.phone?.trim()) {
    return NextResponse.json({ ok: false, error: 'name_and_phone_required' }, { status: 422 });
  }

  if (!VT_USER || !VT_KEY) {
    // Not configured yet — don't lose the lead, log it and tell the client to fall back.
    console.error('[quote] VTiger credentials missing; request was:', JSON.stringify(b));
    return NextResponse.json({ ok: false, error: 'crm_not_configured' }, { status: 503 });
  }

  const session = await vtigerLogin();
  if (!session) {
    console.error('[quote] VTiger login failed');
    return NextResponse.json({ ok: false, error: 'crm_login_failed' }, { status: 502 });
  }

  const isAr = b.locale !== 'en';
  const element = {
    firstname: b.name.trim(),
    lastname: b.company?.trim() || b.name.trim(),
    company: b.company?.trim() || (isAr ? 'غير محدّد' : 'Not specified'),
    phone: b.phone.trim(),
    email: b.email?.trim() || '',
    leadsource: 'Website',
    industry: 'Manufacturing',
    assigned_user_id: VT_ASSIGNEE,
    cf_2262: isAr ? `طلب عرض سعر — ${b.product}` : `Quote request — ${b.product}`,
    description: buildDescription(b),
    cf_905: 'Egypt',
    cf_1963: 'Inbound',
  };

  try {
    const body = new URLSearchParams({
      operation: 'create',
      sessionName: session.sessionName,
      elementType: 'Leads',
      element: JSON.stringify(element),
    });
    const res = await fetch(`${VT_URL}/webservice.php`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body,
      cache: 'no-store',
    });
    const out = await res.json();
    if (!out?.success) {
      console.error('[quote] VTiger create failed:', JSON.stringify(out?.error));
      return NextResponse.json({ ok: false, error: 'crm_create_failed' }, { status: 502 });
    }
    return NextResponse.json({ ok: true, lead: out.result?.lead_no ?? null });
  } catch (e) {
    console.error('[quote] VTiger create threw:', e);
    return NextResponse.json({ ok: false, error: 'crm_unreachable' }, { status: 502 });
  }
}
