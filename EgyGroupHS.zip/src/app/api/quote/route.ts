import { NextRequest, NextResponse } from 'next/server';
import crypto from 'crypto';

// ============================================================================
// POST /api/quote
// Receives a quote request from the catalogue configurator and:
//   1. Creates a Lead in VTiger CRM  (leadsource=Website, assigned to Call Center)
//   2. Optionally mirrors it by email (set QUOTE_EMAIL_TO + SMTP_* to enable)
//
// Field names below are VERIFIED against the live VTiger instance:
//   firstname, phone, leadsource, assigned_user_id  → mandatory
//   company, email, description, cf_2262 (Subject), cf_905 (Country),
//   cf_1963 (Way of Communication), industry
//
// Required env vars (set on the server, never commit them):
//   VTIGER_URL         e.g. https://crm.stlixvalley.com
//   VTIGER_USERNAME    a VTiger username
//   VTIGER_ACCESS_KEY  that user's access key (VTiger → My Preferences)
//   VTIGER_ASSIGNEE    optional, defaults to the Call Center user
// ============================================================================

const VT_URL = process.env.VTIGER_URL || 'https://crm.stlixvalley.com';
const VT_USER = process.env.VTIGER_USERNAME || '';
const VT_KEY = process.env.VTIGER_ACCESS_KEY || '';
const VT_ASSIGNEE = process.env.VTIGER_ASSIGNEE || '19x753'; // Call Center

type CartItem = {
  name: string;
  specs: { label: string; value: string }[];
  note?: string;
};

type Contact = {
  name: string;
  company?: string;
  phone: string;
  email?: string;
  city?: string;
  address?: string;
  when?: string;
  note?: string;
};

/** New shape: a visit request carrying the whole brief. */
type VisitBody = {
  kind: 'visit';
  items: CartItem[];
  contact: Contact;
  locale?: 'ar' | 'en';
};

/** Legacy shape: a single product quote (kept so old clients don't break). */
type LegacyBody = {
  product: string;
  specs: { label: string; value: string }[];
  name: string;
  company?: string;
  email?: string;
  phone: string;
  locale?: 'ar' | 'en';
};

type QuoteBody = VisitBody | LegacyBody;

function isVisit(b: QuoteBody): b is VisitBody {
  return (b as VisitBody).kind === 'visit';
}

/** Normalise either shape into one internal record. */
function normalise(b: QuoteBody): { items: CartItem[]; contact: Contact; locale: 'ar' | 'en' } {
  if (isVisit(b)) return { items: b.items || [], contact: b.contact, locale: b.locale === 'en' ? 'en' : 'ar' };
  return {
    items: [{ name: b.product, specs: b.specs || [] }],
    contact: { name: b.name, company: b.company, phone: b.phone, email: b.email },
    locale: b.locale === 'en' ? 'en' : 'ar',
  };
}

async function vtigerLogin(): Promise<{ sessionName: string } | null> {
  try {
    // 1) challenge
    const chRes = await fetch(`${VT_URL}/webservice.php?operation=getchallenge&username=${encodeURIComponent(VT_USER)}`, {
      cache: 'no-store',
    });
    const ch = await chRes.json();
    if (!ch?.success) return null;
    const token: string = ch.result.token;

    // 2) login with md5(token + accessKey)
    const accessKey = crypto.createHash('md5').update(token + VT_KEY).digest('hex');
    const body = new URLSearchParams({ operation: 'login', username: VT_USER, accessKey });
    const lgRes = await fetch(`${VT_URL}/webservice.php`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body,
      cache: 'no-store',
    });
    const lg = await lgRes.json();
    if (!lg?.success) return null;
    return { sessionName: lg.result.sessionName };
  } catch {
    return null;
  }
}

function buildDescription(items: CartItem[], c: Contact, isAr: boolean): string {
  const L: string[] = [];
  L.push(isAr ? '=== طلب معاينة من الموقع ===' : '=== Site visit request (website) ===');
  L.push('');
  if (items.length) {
    L.push(isAr ? `— الأصناف المطلوبة (${items.length}) —` : `— Requested items (${items.length}) —`);
    items.forEach((it, i) => {
      L.push(`${i + 1}. ${it.name}`);
      for (const s of it.specs || []) L.push(`     ${s.label}: ${s.value}`);
      if (it.note) L.push(`     ${isAr ? 'ملاحظة' : 'Note'}: ${it.note}`);
    });
  } else {
    L.push(isAr ? '— بدون أصناف محدّدة —' : '— No specific items —');
  }
  L.push('');
  L.push(isAr ? '— بيانات الموقع —' : '— Site details —');
  if (c.city) L.push(`${isAr ? 'المدينة' : 'City'}: ${c.city}`);
  if (c.address) L.push(`${isAr ? 'العنوان' : 'Address'}: ${c.address}`);
  if (c.when) L.push(`${isAr ? 'الموعد المفضّل' : 'Preferred time'}: ${c.when}`);
  if (c.note) {
    L.push('');
    L.push(isAr ? '— ملاحظات العميل —' : '— Customer notes —');
    L.push(c.note);
  }
  L.push('');
  L.push(isAr ? 'الخطوة الجاية: معاينة ← دراسة ← مقايسة ← عرض سعر' : 'Next: visit → study → take-off → quotation');
  return L.join('\n');
}

export async function POST(req: NextRequest) {
  let raw: QuoteBody;
  try {
    raw = (await req.json()) as QuoteBody;
  } catch {
    return NextResponse.json({ ok: false, error: 'bad_json' }, { status: 400 });
  }

  const { items, contact, locale } = normalise(raw);
  const isAr = locale !== 'en';

  // VTiger requires a name and a phone — everything else is optional.
  if (!contact?.name?.trim() || !contact?.phone?.trim()) {
    return NextResponse.json({ ok: false, error: 'name_and_phone_required' }, { status: 422 });
  }

  if (!VT_USER || !VT_KEY) {
    // Not configured — log it so the request is recoverable, and tell the
    // client to fall back to email rather than silently dropping a lead.
    console.error('[quote] VTiger credentials missing. Request:', JSON.stringify({ items, contact }));
    return NextResponse.json({ ok: false, error: 'crm_not_configured' }, { status: 503 });
  }

  const session = await vtigerLogin();
  if (!session) {
    console.error('[quote] VTiger login failed. Request:', JSON.stringify({ items, contact }));
    return NextResponse.json({ ok: false, error: 'crm_login_failed' }, { status: 502 });
  }

  const subject = items.length
    ? isAr
      ? `طلب معاينة — ${items[0].name}${items.length > 1 ? ` +${items.length - 1}` : ''}`
      : `Site visit — ${items[0].name}${items.length > 1 ? ` +${items.length - 1}` : ''}`
    : isAr
      ? 'طلب معاينة'
      : 'Site visit request';

  const element = {
    firstname: contact.name.trim(),
    lastname: contact.company?.trim() || contact.name.trim(),
    company: contact.company?.trim() || (isAr ? 'غير محدّد' : 'Not specified'),
    phone: contact.phone.trim(),
    email: contact.email?.trim() || '',
    leadsource: 'Website',
    industry: 'Manufacturing',
    assigned_user_id: VT_ASSIGNEE,
    cf_2262: subject,
    description: buildDescription(items, contact, isAr),
    lane: contact.address?.trim() || '',
    city: contact.city?.trim() || '',
    cf_905: 'Egypt',
    cf_1963: 'Inbound',
  };

  try {
    const body = new URLSearchParams({
      operation: 'create',
      sessionName: session.sessionName,
      elementType: 'Leads',
      element: JSON.stringify(element),
    });
    const res = await fetch(`${VT_URL}/webservice.php`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body,
      cache: 'no-store',
    });
    const out = await res.json();
    if (!out?.success) {
      console.error('[quote] VTiger create failed:', JSON.stringify(out?.error), JSON.stringify({ items, contact }));
      return NextResponse.json({ ok: false, error: 'crm_create_failed' }, { status: 502 });
    }
    return NextResponse.json({ ok: true, lead: out.result?.lead_no ?? null });
  } catch (e) {
    console.error('[quote] VTiger create threw:', e, JSON.stringify({ items, contact }));
    return NextResponse.json({ ok: false, error: 'crm_unreachable' }, { status: 502 });
  }
}
