import { NextRequest, NextResponse } from 'next/server';
import { revalidatePath } from 'next/cache';
import { isAdmin } from '@/lib/admin';
import { readOverrides, setImages } from '@/lib/overrides';
import { masterItems } from '@/content/catalog';

export async function GET() {
  if (!isAdmin()) return NextResponse.json({ ok: false, error: 'unauthorised' }, { status: 401 });
  return NextResponse.json({ ok: true, overrides: readOverrides() });
}

export async function POST(req: NextRequest) {
  if (!isAdmin()) return NextResponse.json({ ok: false, error: 'unauthorised' }, { status: 401 });

  let b: { slug?: string; images?: string[] };
  try {
    b = await req.json();
  } catch {
    return NextResponse.json({ ok: false, error: 'bad_json' }, { status: 400 });
  }

  const slug = (b.slug || '').trim();
  if (!slug || !masterItems.some((i) => i.slug === slug)) {
    return NextResponse.json({ ok: false, error: 'unknown_slug' }, { status: 422 });
  }
  if (!Array.isArray(b.images)) {
    return NextResponse.json({ ok: false, error: 'images_must_be_array' }, { status: 422 });
  }
  // only our own library and our own uploads — no arbitrary URLs
  const bad = b.images.find(
    (u) => typeof u !== 'string' || !(u.startsWith('https://res.cloudinary.com/djrskkszi/') || u.startsWith('/assets/'))
  );
  if (bad) return NextResponse.json({ ok: false, error: 'bad_image_url', url: bad }, { status: 422 });

  setImages(slug, b.images.slice(0, 8));

  // the catalogue pages are static — rebuild the affected ones now
  try {
    revalidatePath('/[locale]/catalog/[slug]', 'page');
    revalidatePath('/[locale]/catalog', 'page');
  } catch {
    /* revalidation is best-effort; the write already succeeded */
  }

  return NextResponse.json({ ok: true, images: b.images });
}
