import { NextRequest, NextResponse } from 'next/server';
import { checkPassword, setAdminCookie, clearAdminCookie, adminConfigured, isAdmin } from '@/lib/admin';

export async function GET() {
  return NextResponse.json({ ok: true, admin: isAdmin(), configured: adminConfigured() });
}

export async function POST(req: NextRequest) {
  if (!adminConfigured()) {
    return NextResponse.json({ ok: false, error: 'not_configured' }, { status: 503 });
  }
  let b: { password?: string };
  try {
    b = await req.json();
  } catch {
    return NextResponse.json({ ok: false, error: 'bad_json' }, { status: 400 });
  }
  if (!b.password || !checkPassword(b.password)) {
    // slow the guessing down a little
    await new Promise((r) => setTimeout(r, 700));
    return NextResponse.json({ ok: false, error: 'bad_password' }, { status: 401 });
  }
  setAdminCookie();
  return NextResponse.json({ ok: true });
}

export async function DELETE() {
  clearAdminCookie();
  return NextResponse.json({ ok: true });
}
