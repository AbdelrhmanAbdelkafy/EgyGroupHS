import { NextRequest, NextResponse } from 'next/server';
import { isAdmin } from '@/lib/admin';
import { saveUpload, deleteUpload, readMeta, extFor, urlFor } from '@/lib/uploads';
import { readOverrides, writeOverrides } from '@/lib/overrides';
import { filesFrom } from '@/lib/formfile';

export const runtime = 'nodejs';

const MAX = 8 * 1024 * 1024; // the browser shrinks images before sending; this is the backstop

export async function GET() {
  if (!isAdmin()) return NextResponse.json({ ok: false, error: 'unauthorised' }, { status: 401 });
  return NextResponse.json({
    ok: true,
    uploads: readMeta().map((u) => ({ ...u, url: urlFor(u.file) })),
  });
}

export async function POST(req: NextRequest) {
  if (!isAdmin()) return NextResponse.json({ ok: false, error: 'unauthorised' }, { status: 401 });

  let form: FormData;
  try {
    form = await req.formData();
  } catch {
    return NextResponse.json({ ok: false, error: 'bad_form' }, { status: 400 });
  }

  // duck-typed: `File` is not a global before Node 20, and this server runs 18
  const files = filesFrom(form, 'file');
  if (files.length === 0) return NextResponse.json({ ok: false, error: 'no_file' }, { status: 422 });

  const saved: { url: string; name: string }[] = [];
  const failed: { name: string; why: string }[] = [];

  for (const f of files) {
    if (!extFor(f.type)) {
      failed.push({ name: f.name, why: 'type' });
      continue;
    }
    if (f.size > MAX) {
      failed.push({ name: f.name, why: 'size' });
      continue;
    }
    try {
      const buf = Buffer.from(await f.arrayBuffer());
      const rec = saveUpload(buf, f.type, f.name);
      saved.push({ url: urlFor(rec.file), name: rec.name });
    } catch {
      failed.push({ name: f.name, why: 'write' });
    }
  }

  return NextResponse.json({ ok: saved.length > 0, saved, failed });
}

export async function DELETE(req: NextRequest) {
  if (!isAdmin()) return NextResponse.json({ ok: false, error: 'unauthorised' }, { status: 401 });

  const file = new URL(req.url).searchParams.get('file') || '';
  if (!deleteUpload(file)) return NextResponse.json({ ok: false, error: 'not_found' }, { status: 404 });

  // a deleted photo must not stay assigned to a product — that would render a broken image
  const url = urlFor(file);
  const all = readOverrides();
  let touched = 0;
  for (const [slug, imgs] of Object.entries(all)) {
    if (!imgs.includes(url)) continue;
    const next = imgs.filter((u) => u !== url);
    if (next.length) all[slug] = next;
    else delete all[slug];
    touched++;
  }
  if (touched) writeOverrides(all);

  return NextResponse.json({ ok: true, removedFrom: touched });
}
