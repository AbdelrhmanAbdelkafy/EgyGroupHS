import { NextRequest, NextResponse } from 'next/server';
import { crmConfigured, vtLogin, createLead, ASSIGNEE_CALLCENTER } from '@/lib/crm';
import { currentUserId } from '@/lib/session';
import { findById } from '@/lib/users';

// ============================================================================
// POST /api/order
// Checkout for the cart: everything in it becomes ONE lead, so sales sees the
// whole basket in a single record rather than five disconnected enquiries.
// ============================================================================

type Line = {
  name: string;
  slug: string;
  qty: number;
  specs: { label: string; value: string }[];
};

type Body = {
  lines: Line[];
  notes?: string;
  // guest-only (ignored when signed in)
  name?: string;
  company?: string;
  phone?: string;
  email?: string;
  locale?: 'ar' | 'en';
};

export async function POST(req: NextRequest) {
  let b: Body;
  try {
    b = (await req.json()) as Body;
  } catch {
    return NextResponse.json({ ok: false, error: 'bad_json' }, { status: 400 });
  }

  if (!Array.isArray(b.lines) || b.lines.length === 0) {
    return NextResponse.json({ ok: false, error: 'empty_cart' }, { status: 422 });
  }

  const uid = currentUserId();
  const account = uid ? findById(uid) : undefined;
  const who = account
    ? { name: account.name, company: account.company, phone: account.phone, email: account.email }
    : { name: (b.name || '').trim(), company: (b.company || '').trim(), phone: (b.phone || '').trim(), email: (b.email || '').trim() };

  if (!who.name || !who.phone) {
    return NextResponse.json({ ok: false, error: 'name_and_phone_required' }, { status: 422 });
  }

  const isAr = b.locale !== 'en';
  const L: string[] = [];
  L.push(isAr ? '═══ طلب أصناف من الموقع ═══' : '═══ PRODUCT REQUEST FROM WEBSITE ═══');
  L.push('');
  b.lines.forEach((l, i) => {
    L.push(`${i + 1}. ${l.name} — ${isAr ? 'الكمية' : 'Qty'}: ${l.qty}`);
    l.specs.forEach((s) => L.push(`     • ${s.label}: ${s.value}`));
  });
  if (b.notes) {
    L.push('');
    L.push(isAr ? '— ملاحظات —' : '— Notes —');
    L.push(b.notes);
  }
  L.push('');
  L.push(isAr ? `عدد الأصناف: ${b.lines.length}` : `Items: ${b.lines.length}`);
  const description = L.join('\n');

  if (!crmConfigured()) {
    console.error('[order] CRM not configured; order was:', JSON.stringify({ ...b, who }));
    return NextResponse.json({ ok: false, error: 'crm_not_configured' }, { status: 503 });
  }

  const session = await vtLogin();
  if (!session) return NextResponse.json({ ok: false, error: 'crm_login_failed' }, { status: 502 });

  const first = b.lines[0].name;
  const more = b.lines.length - 1;
  const subject = isAr
    ? `طلب أصناف — ${first}${more > 0 ? ` +${more}` : ''}`
    : `Product request — ${first}${more > 0 ? ` +${more}` : ''}`;

  const lead = await createLead(session, {
    name: who.name,
    company: who.company,
    phone: who.phone,
    email: who.email,
    subject,
    description,
    assignee: ASSIGNEE_CALLCENTER,
  });
  if (!lead?.id) return NextResponse.json({ ok: false, error: 'lead_failed' }, { status: 502 });

  return NextResponse.json({ ok: true, lead: lead.lead_no ?? null });
}
