import type { MetadataRoute } from 'next';
import { locales } from '@/lib/i18n';
import { masterItems } from '@/content/catalog';

const BASE = 'https://egygrouphs.com';
const paths = ['', '/catalog', '/services', '/standards', '/tools', '/about', '/contact'];

export default function sitemap(): MetadataRoute.Sitemap {
  const entries: MetadataRoute.Sitemap = [];
  for (const locale of locales) {
    for (const p of paths) {
      entries.push({
        url: `${BASE}/${locale}${p}`,
        lastModified: new Date(),
        changeFrequency: p === '' ? 'weekly' : 'monthly',
        priority: p === '' ? 1 : 0.8,
        alternates: {
          languages: {
            ar: `${BASE}/ar${p}`,
            en: `${BASE}/en${p}`,
          },
        },
      });
    }
  }
  for (const locale of locales) {
    for (const m of masterItems) {
      entries.push({
        url: `${BASE}/${locale}/catalog/${m.slug}`,
        lastModified: new Date(),
        changeFrequency: 'monthly',
        priority: 0.7,
        alternates: { languages: { ar: `${BASE}/ar/catalog/${m.slug}`, en: `${BASE}/en/catalog/${m.slug}` } },
      });
    }
  }
  return entries;
}
