import type { MetadataRoute } from 'next';
import { locales } from '@/lib/i18n';

const BASE = 'https://egygrouphs.com';
const paths = ['', '/services', '/standards', '/about', '/contact'];

export default function sitemap(): MetadataRoute.Sitemap {
  const entries: MetadataRoute.Sitemap = [];
  for (const locale of locales) {
    for (const p of paths) {
      entries.push({
        url: `${BASE}/${locale}${p}`,
        lastModified: new Date(),
        changeFrequency: p === '' ? 'weekly' : 'monthly',
        priority: p === '' ? 1 : 0.8,
        alternates: {
          languages: {
            ar: `${BASE}/ar${p}`,
            en: `${BASE}/en${p}`,
          },
        },
      });
    }
  }
  return entries;
}
