import Link from 'next/link';

export default function NotFound() {
  return (
    <html lang="ar" dir="rtl">
      <body style={{ background: '#141618', color: '#eef1f4', fontFamily: 'system-ui', display: 'flex', minHeight: '100vh', alignItems: 'center', justifyContent: 'center' }}>
        <div style={{ textAlign: 'center', padding: 40 }}>
          <h1 style={{ fontSize: '3rem', margin: 0, color: '#F3A135' }}>404</h1>
          <p style={{ color: '#9aa4ad', marginTop: 12 }}>الصفحة غير موجودة · Page not found</p>
          <Link href="/ar" style={{ color: '#F3A135', marginTop: 20, display: 'inline-block' }}>الرئيسية · Home</Link>
        </div>
      </body>
    </html>
  );
}
