import type { Metadata, Viewport } from 'next';
import './globals.css';

export const metadata: Metadata = {
  metadataBase: new URL('https://egygrouphs.com'),
  manifest: '/manifest.json',
  applicationName: 'Hard Steel',
  appleWebApp: {
    capable: true,
    statusBarStyle: 'black-translucent',
    title: 'Hard Steel',
  },
  formatDetection: { telephone: true },
};

export const viewport: Viewport = {
  themeColor: '#141618',
  width: 'device-width',
  initialScale: 1,
  viewportFit: 'cover',
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return children;
}
