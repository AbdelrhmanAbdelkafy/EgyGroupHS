import type { MetadataRoute } from 'next';

export default function robots(): MetadataRoute.Robots {
  return {
    rules: {
      userAgent: '*',
      allow: '/',
      // the admin and the cart hold nothing a search engine should index
      disallow: ['/admin', '/api/', '/ar/admin', '/en/admin', '/ar/cart', '/en/cart'],
    },
    sitemap: 'https://egygrouphs.com/sitemap.xml',
    host: 'https://egygrouphs.com',
  };
}
