'use client';

import { useEffect, useMemo, useState } from 'react';
import { masterItems } from '@/content/catalog';
import library from '@/content/photo-library.json';

// ============================================================================
// Content manager — image assignment.
//
// It exists because whoever assigns a photo has to be able to see it. Pick a
// product on the left, click photos on the right, save. The library is filtered
// by what the classifier found in each photo, and by whether it is print-ready,
// so the good ones surface first.
//
// Order matters: the first image is the one the catalogue card shows.
// ============================================================================

type Photo = { i: number; url: string; name: string; type: string; q: string; w: number; h: number };
const LIB = library as Photo[];
const CL = 'https://res.cloudinary.com/djrskkszi/image/upload';

const thumb = (url: string, w = 300) =>
  url.includes('res.cloudinary.com') ? url.replace('/upload/', `/upload/w_${w},h_${w},c_fill,q_auto,f_auto/`) : url;

/** Uploaded photos are served whole — they were already shrunk in the browser. */
const isUpload = (url: string) => url.startsWith('/api/img/');

export function AdminClient() {
  const [ready, setReady] = useState(false);
  const [authed, setAuthed] = useState(false);
  const [configured, setConfigured] = useState(true);
  const [pw, setPw] = useState('');
  const [err, setErr] = useState('');

  const [overrides, setOverrides] = useState<Record<string, string[]>>({});
  const [slug, setSlug] = useState(masterItems[0]?.slug ?? '');
  const [picked, setPicked] = useState<string[]>([]);
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);

  const [uploads, setUploads] = useState<{ url: string; name: string; file: string; at: number }[]>([]);
  const [busy, setBusy] = useState('');

  const [typeFilter, setTypeFilter] = useState('الكل');
  const [readyOnly, setReadyOnly] = useState(true);
  const [q, setQ] = useState('');

  const item = masterItems.find((i) => i.slug === slug);

  useEffect(() => {
    fetch('/api/admin/login')
      .then((r) => r.json())
      .then((d) => {
        setAuthed(Boolean(d?.admin));
        setConfigured(d?.configured !== false);
      })
      .catch(() => {})
      .finally(() => setReady(true));
  }, []);

  useEffect(() => {
    if (!authed) return;
    fetch('/api/admin/images')
      .then((r) => r.json())
      .then((d) => d?.ok && setOverrides(d.overrides || {}))
      .catch(() => {});
    loadUploads();
  }, [authed]);

  const loadUploads = () =>
    fetch('/api/admin/upload')
      .then((r) => r.json())
      .then((d) => d?.ok && setUploads(d.uploads || []))
      .catch(() => {});

  /**
   * Shrink in the browser before sending. A phone camera produces 4–8 MB per
   * shot; nobody needs that for a product card, and on mobile data the upload
   * is the slow part. 1600px is past what the largest card renders.
   */
  const shrink = (file: File): Promise<Blob> =>
    new Promise((resolve, reject) => {
      const img = new Image();
      const url = URL.createObjectURL(file);
      img.onload = () => {
        URL.revokeObjectURL(url);
        const max = 1600;
        let { width: w, height: h } = img;
        if (w > max || h > max) {
          const k = Math.min(max / w, max / h);
          w = Math.round(w * k);
          h = Math.round(h * k);
        }
        const c = document.createElement('canvas');
        c.width = w;
        c.height = h;
        const ctx = c.getContext('2d');
        if (!ctx) return reject(new Error('no canvas'));
        ctx.drawImage(img, 0, 0, w, h);
        c.toBlob((b) => (b ? resolve(b) : reject(new Error('encode failed'))), 'image/jpeg', 0.85);
      };
      img.onerror = () => {
        URL.revokeObjectURL(url);
        reject(new Error('not an image'));
      };
      img.src = url;
    });

  const upload = async (files: FileList | null) => {
    if (!files || files.length === 0) return;
    setBusy(`جارٍ رفع ${files.length} صورة…`);
    setErr('');
    const fd = new FormData();
    for (const f of Array.from(files)) {
      try {
        const small = await shrink(f);
        fd.append('file', new File([small], f.name.replace(/\.[^.]+$/, '') + '.jpg', { type: 'image/jpeg' }));
      } catch {
        fd.append('file', f); // not decodable here — let the server judge it
      }
    }
    try {
      const res = await fetch('/api/admin/upload', { method: 'POST', body: fd });
      const d = await res.json().catch(() => ({}));
      if (d?.saved?.length) {
        await loadUploads();
        setTypeFilter('مرفوعاتي');
        // newly uploaded photos go straight onto the open product
        setPicked((p) => [...p, ...d.saved.map((x: { url: string }) => x.url)].slice(0, 8));
        setSaved(false);
      }
      if (d?.failed?.length) setErr(`${d.failed.length} صورة اترفضت (النوع أو الحجم).`);
      else if (!d?.saved?.length) setErr('مفيش صور اترفعت.');
    } catch {
      setErr('الرفع فشل — جرّب تاني.');
    } finally {
      setBusy('');
    }
  };

  const removeUpload = async (file: string) => {
    if (!confirm('تمسح الصورة دي نهائياً؟ هتتشال من أي منتج متحطة عليه.')) return;
    setBusy('جارٍ الحذف…');
    try {
      await fetch(`/api/admin/upload?file=${encodeURIComponent(file)}`, { method: 'DELETE' });
      await loadUploads();
      const url = `/api/img/${file}`;
      setPicked((p) => p.filter((u) => u !== url));
      const res = await fetch('/api/admin/images');
      const d = await res.json().catch(() => ({}));
      if (d?.ok) setOverrides(d.overrides || {});
    } finally {
      setBusy('');
    }
  };

  // load the product's current images whenever the selection changes
  useEffect(() => {
    if (!item) return;
    setPicked(overrides[item.slug] ?? item.images);
    setSaved(false);
  }, [slug, overrides, item]);

  const types = useMemo(() => ['الكل', 'مرفوعاتي', ...Array.from(new Set(LIB.map((p) => p.type)))], []);

  /** Uploads are shown as library photos, flagged so they can be deleted. */
  const asPhotos = useMemo<Photo[]>(
    () => uploads.map((u, i) => ({ i: -1 - i, url: u.url, name: u.name, type: 'مرفوعاتي', q: 'ready', w: 0, h: 0 })),
    [uploads]
  );

  const photos = useMemo(() => {
    const nq = q.trim().toLowerCase();
    const pool = typeFilter === 'مرفوعاتي' ? asPhotos : typeFilter === 'الكل' ? [...asPhotos, ...LIB] : LIB;
    return pool
      .filter((p) => {
        if (p.type === 'مرفوعاتي') return !nq || p.name.toLowerCase().includes(nq);
        if (p.q === 'rejected') return false;
        if (readyOnly && p.q !== 'ready') return false;
        if (typeFilter !== 'الكل' && p.type !== typeFilter) return false;
        if (nq && !p.name.toLowerCase().includes(nq)) return false;
        return true;
      })
      .slice(0, 170);
  }, [typeFilter, readyOnly, q, asPhotos]);

  const login = async () => {
    setErr('');
    const res = await fetch('/api/admin/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ password: pw }),
    });
    const d = await res.json().catch(() => ({}));
    if (d?.ok) setAuthed(true);
    else setErr(d?.error === 'not_configured' ? 'الأدمن مش متظبّط على السيرفر — ضيف ADMIN_PASSWORD في .env.local' : 'الباسورد غلط.');
  };

  const toggle = (url: string) => {
    setSaved(false);
    setPicked((p) => (p.includes(url) ? p.filter((x) => x !== url) : [...p, url].slice(0, 8)));
  };

  const move = (i: number, dir: -1 | 1) => {
    setSaved(false);
    setPicked((p) => {
      const j = i + dir;
      if (j < 0 || j >= p.length) return p;
      const n = [...p];
      [n[i], n[j]] = [n[j], n[i]];
      return n;
    });
  };

  const save = async () => {
    if (!item) return;
    setSaving(true);
    setErr('');
    try {
      const res = await fetch('/api/admin/images', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ slug: item.slug, images: picked }),
      });
      const d = await res.json().catch(() => ({}));
      if (d?.ok) {
        setOverrides((o) => ({ ...o, [item.slug]: picked }));
        setSaved(true);
      } else setErr('المحفظش. جرّب تاني.');
    } catch {
      setErr('مفيش اتصال.');
    } finally {
      setSaving(false);
    }
  };

  const reset = async () => {
    if (!item) return;
    setSaving(true);
    await fetch('/api/admin/images', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ slug: item.slug, images: [] }),
    }).catch(() => {});
    setOverrides((o) => {
      const n = { ...o };
      delete n[item.slug];
      return n;
    });
    setPicked(item.images);
    setSaving(false);
    setSaved(true);
  };

  const field = 'w-full rounded-md border border-line bg-ink px-3 py-2 text-[0.9rem] text-paper outline-none focus:border-amber';

  if (!ready) return <p className="p-10 text-center text-muted">…</p>;

  if (!authed) {
    return (
      <div className="mx-auto mt-[14vh] max-w-[380px] px-6">
        <div className="rounded-2xl border border-line bg-ink-2 p-8">
          <h1 className="text-[1.3rem]">إدارة المحتوى</h1>
          <p className="mt-2 text-[0.85rem] text-muted">للتعديل على صور المنتجات.</p>
          {!configured && (
            <p className="mt-4 rounded-lg border border-[#e0503a]/40 bg-[#e0503a]/10 px-3 py-2 text-[0.8rem] text-[#ff9683]">
              محتاج تضيف <code className="font-mono">ADMIN_PASSWORD</code> في <code className="font-mono">.env.local</code> على السيرفر.
            </p>
          )}
          <input
            type="password"
            value={pw}
            onChange={(e) => setPw(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && login()}
            placeholder="الباسورد"
            className={`${field} mt-5`}
          />
          {err && <p className="mt-2 text-[0.8rem] text-[#ff9683]">{err}</p>}
          <button onClick={login} className="mt-4 w-full rounded-md bg-amber px-5 py-3 text-[14px] font-semibold text-[#161310] transition hover:bg-amber-hi">
            دخول
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-[1400px] px-5 py-8">
      <div className="mb-6 flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-[1.5rem]">إدارة صور المنتجات</h1>
          <p className="mt-1 text-[0.85rem] text-muted">
            {masterItems.length} منتج · {LIB.length} صورة في المكتبة · معدّل: {Object.keys(overrides).length}
          </p>
        </div>
        <button
          onClick={() => fetch('/api/admin/login', { method: 'DELETE' }).then(() => setAuthed(false))}
          className="rounded-md border border-line px-4 py-2 text-[13px] text-muted transition hover:text-paper"
        >
          خروج
        </button>
      </div>

      <div className="grid grid-cols-1 gap-5 lg:grid-cols-[240px_1fr]">
        {/* products */}
        <aside className="lg:sticky lg:top-4 lg:max-h-[88vh] lg:self-start lg:overflow-y-auto">
          <ul className="flex flex-col gap-1">
            {masterItems.map((m) => {
              const edited = Boolean(overrides[m.slug]);
              const on = m.slug === slug;
              return (
                <li key={m.slug}>
                  <button
                    onClick={() => setSlug(m.slug)}
                    className={`flex w-full items-center gap-2 rounded-md px-3 py-2 text-start text-[0.88rem] transition ${
                      on ? 'bg-amber/15 font-semibold text-amber' : 'text-muted hover:bg-ink-2 hover:text-paper'
                    }`}
                  >
                    <span className="flex-1 truncate">{m.name.ar}</span>
                    {edited && <span className="h-[6px] w-[6px] shrink-0 rounded-full bg-amber" title="معدّل" />}
                  </button>
                </li>
              );
            })}
          </ul>
        </aside>

        <div className="min-w-0">
          {/* current selection */}
          <div className="rounded-xl border border-line bg-ink-2 p-4">
            <div className="mb-3 flex flex-wrap items-center justify-between gap-2">
              <h2 className="text-[1.05rem]">
                صور <span className="text-amber">{item?.name.ar}</span>
                <span className="ms-2 text-[0.8rem] text-muted">({picked.length})</span>
              </h2>
              <div className="flex gap-2">
                <button onClick={reset} disabled={saving} className="rounded-md border border-line px-3 py-1.5 text-[12px] text-muted transition hover:text-paper disabled:opacity-50">
                  رجّع الأصلي
                </button>
                <button onClick={save} disabled={saving} className="rounded-md bg-amber px-5 py-1.5 text-[12.5px] font-semibold text-[#161310] transition hover:bg-amber-hi disabled:opacity-50">
                  {saving ? 'جارٍ الحفظ…' : saved ? 'اتحفظ ✓' : 'احفظ'}
                </button>
              </div>
            </div>

            {picked.length === 0 ? (
              <p className="py-6 text-center text-[0.85rem] text-muted">مفيش صور — اختار من تحت.</p>
            ) : (
              <div className="flex flex-wrap gap-3">
                {picked.map((u, i) => (
                  <div key={u + i} className="group relative">
                    <div className="h-[104px] w-[104px] overflow-hidden rounded-lg border border-line bg-[#e9ebee]">
                      <img src={thumb(u, 220)} alt="" className="h-full w-full object-cover" />
                    </div>
                    {i === 0 && (
                      <span className="absolute -top-2 -start-2 rounded bg-amber px-1.5 py-0.5 font-mono text-[9px] font-bold text-[#161310]">
                        رئيسية
                      </span>
                    )}
                    <div className="absolute inset-x-0 bottom-0 flex justify-center gap-1 rounded-b-lg bg-ink/85 py-1 opacity-0 transition group-hover:opacity-100">
                      <button onClick={() => move(i, -1)} className="px-1.5 text-[12px] text-paper hover:text-amber">←</button>
                      <button onClick={() => toggle(u)} className="px-1.5 text-[12px] text-[#ff7a63]">✕</button>
                      <button onClick={() => move(i, 1)} className="px-1.5 text-[12px] text-paper hover:text-amber">→</button>
                    </div>
                  </div>
                ))}
              </div>
            )}
            {err && <p className="mt-3 text-[0.8rem] text-[#ff9683]">{err}</p>}
            <p className="mt-3 text-[0.75rem] text-muted">الأولى هي اللي بتظهر في الكتالوج · اضغط الصورة تحت عشان تضيف/تشيل</p>
          </div>

          {/* library */}
          <div className="mt-5 rounded-xl border border-line bg-ink-2 p-4">
            <div className="mb-3 flex flex-wrap items-center gap-2">
              <select value={typeFilter} onChange={(e) => setTypeFilter(e.target.value)} className={`${field} max-w-[190px]`}>
                {types.map((t) => (
                  <option key={t} value={t}>{t}</option>
                ))}
              </select>
              <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="دوّر باسم الملف…" className={`${field} max-w-[220px]`} />
              <label className="flex cursor-pointer items-center gap-2 text-[0.82rem] text-muted">
                <input type="checkbox" checked={readyOnly} onChange={(e) => setReadyOnly(e.target.checked)} className="accent-amber" />
                الجاهزة بس
              </label>
              <label className="ms-auto inline-flex cursor-pointer items-center gap-2 rounded-md border border-amber bg-amber/10 px-3.5 py-2 text-[0.82rem] font-semibold text-amber transition hover:bg-amber/20">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" className="h-[14px] w-[14px]">
                  <path d="M12 16V4M8 8l4-4 4 4M4 16v3a1 1 0 0 0 1 1h14a1 1 0 0 0 1-1v-3" />
                </svg>
                ارفع صور
                <input
                  type="file"
                  accept="image/jpeg,image/png,image/webp"
                  multiple
                  className="hidden"
                  onChange={(e) => {
                    upload(e.target.files);
                    e.target.value = '';
                  }}
                />
              </label>
              <span className="font-mono text-[11px] text-steel-lt">{photos.length} صورة</span>
            </div>

            {busy && (
              <p className="mb-3 rounded-lg border border-amber/40 bg-amber/10 px-3 py-2 text-[0.82rem] text-amber">{busy}</p>
            )}

            <div className="grid max-h-[58vh] grid-cols-3 gap-2 overflow-y-auto sm:grid-cols-5 lg:grid-cols-7">
              {photos.map((p) => {
                const on = picked.includes(p.url);
                const mine = isUpload(p.url);
                return (
                  <div key={mine ? p.url : p.i} className="group relative">
                    <button
                      onClick={() => toggle(p.url)}
                      title={mine ? `مرفوعة · ${p.name}` : `#${p.i} · ${p.type} · ${p.w}×${p.h} · ${p.name}`}
                      className={`relative block aspect-square w-full overflow-hidden rounded-md border-2 bg-[#e9ebee] transition ${
                        on ? 'border-amber' : 'border-transparent hover:border-steel-lt'
                      }`}
                    >
                      <img src={thumb(p.url, 200)} alt="" loading="lazy" className="h-full w-full object-cover" />
                      {on && (
                        <span className="absolute inset-0 grid place-items-center bg-amber/35">
                          <span className="text-[20px] font-bold text-[#161310]">✓</span>
                        </span>
                      )}
                      {p.q === 'ready' && !on && !mine && (
                        <span className="absolute end-1 top-1 h-[7px] w-[7px] rounded-full bg-[#4ade80]" title="جاهزة" />
                      )}
                      {mine && (
                        <span className="absolute start-1 top-1 rounded bg-amber px-1 py-[1px] font-mono text-[8px] font-bold text-[#161310]">
                          بتاعتي
                        </span>
                      )}
                    </button>
                    {mine && (
                      <button
                        onClick={() => removeUpload(p.url.split('/').pop() as string)}
                        title="امسح نهائياً"
                        className="absolute end-1 top-1 hidden h-[20px] w-[20px] items-center justify-center rounded bg-[#e0503a] text-[11px] font-bold text-white transition group-hover:flex hover:bg-[#ff6a52]"
                      >
                        ✕
                      </button>
                    )}
                  </div>
                );
              })}
            </div>
            {photos.length === 0 && <p className="py-8 text-center text-[0.85rem] text-muted">مفيش صور بالفلتر ده.</p>}
          </div>
        </div>
      </div>
    </div>
  );
}
