'use client';

import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { masterItems } from '@/content/catalog';
import { services } from '@/content/site';
import library from '@/content/photo-library.json';

// ============================================================================
// Content manager — image assignment.
//
// Built around one fact: the person using this is standing in a workshop with a
// phone. So nothing here may depend on hover — a control that only appears on
// mouse-over does not exist on a touch screen. Everything is always visible and
// thumb-sized.
//
// The library is never truncated. Hiding photos behind an invisible cap means
// someone scrolls to the end, concludes the photo isn't there, and gives up.
// 370 lazy-loaded thumbnails cost the browser nothing.
//
// Uploads land where they're going: a drop zone sits in the product's own image
// panel, not in the library toolbar. Everything is re-encoded to JPEG in the
// browser first, which shrinks a 6 MB phone photo to a few hundred KB and turns
// an iPhone's HEIC into something every browser can display.
// ============================================================================

type Photo = { i: number; url: string; name: string; type: string; q: string; w: number; h: number };
const LIB = library as Photo[];

import { photoSrc } from '@/lib/photo';

const thumb = (url: string, w = 300) => photoSrc(url, w, w);

const isUpload = (url: string) => url.startsWith('/api/img/');

/**
 * Products and services in one list, because to the person assigning photos they
 * are the same job. The key carries the kind: services are prefixed, since three
 * slugs — tanks, machining, heat-exchangers — name both a product and a service
 * and would otherwise share an entry.
 */
type Subject = { key: string; name: string; images: string[]; kind: 'product' | 'service'; max: number };

const SUBJECTS: Subject[] = [
  ...masterItems.map((m) => ({ key: m.slug, name: m.name.ar, images: m.images, kind: 'product' as const, max: 8 })),
  ...services.items.map((x) => ({
    key: `service:${x.slug}`,
    name: x.title.ar,
    images: [(x as { img?: string }).img].filter(Boolean) as string[],
    kind: 'service' as const,
    max: 1, // the card is a single background — more would never be seen
  })),
];

export function AdminClient() {
  const [ready, setReady] = useState(false);
  const [authed, setAuthed] = useState(false);
  const [configured, setConfigured] = useState(true);
  const [pw, setPw] = useState('');
  const [err, setErr] = useState('');
  const [note, setNote] = useState('');

  const [overrides, setOverrides] = useState<Record<string, string[]>>({});
  const [uploads, setUploads] = useState<{ url: string; name: string; file: string; at: number }[]>([]);
  const [slug, setSlug] = useState(SUBJECTS[0]?.key ?? '');
  const [kind, setKind] = useState<'product' | 'service'>('product');
  const [picked, setPicked] = useState<string[]>([]);
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);

  /** files mid-flight, shown as ghost tiles so the wait is visible */
  const [pending, setPending] = useState<{ id: string; preview: string }[]>([]);
  const [dragging, setDragging] = useState(false);
  /** Burnt into the pixels at upload — the only measure that survives a copy. */
  const [watermark, setWatermark] = useState(true);

  const [typeFilter, setTypeFilter] = useState('الكل');
  const [readyOnly, setReadyOnly] = useState(true);
  const [q, setQ] = useState('');

  const item = SUBJECTS.find((i) => i.key === slug);
  const shown = SUBJECTS.filter((x) => x.kind === kind);
  const listRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    fetch('/api/admin/login')
      .then((r) => r.json())
      .then((d) => {
        setAuthed(Boolean(d?.admin));
        setConfigured(d?.configured !== false);
      })
      .catch(() => {})
      .finally(() => setReady(true));
  }, []);

  const loadUploads = useCallback(
    () =>
      fetch('/api/admin/upload')
        .then((r) => r.json())
        .then((d) => d?.ok && setUploads(d.uploads || []))
        .catch(() => {}),
    []
  );

  const loadOverrides = useCallback(
    () =>
      fetch('/api/admin/images')
        .then((r) => r.json())
        .then((d) => d?.ok && setOverrides(d.overrides || {}))
        .catch(() => {}),
    []
  );

  useEffect(() => {
    if (!authed) return;
    loadOverrides();
    loadUploads();
  }, [authed, loadOverrides, loadUploads]);

  // switching product loads its images — but never while a save is in flight
  useEffect(() => {
    if (!item) return;
    setPicked(overrides[item.key] ?? item.images);
    setSaved(false);
  }, [slug]); // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => {
    if (!note) return;
    const t = setTimeout(() => setNote(''), 3000);
    return () => clearTimeout(t);
  }, [note]);

  // Every upload is normalised to exactly this. The library's photos are already
  // uniform because Cloudinary crops them on the fly; uploads are served as-is,
  // so unless they are made uniform here, one product shows a crisp 4000px photo
  // and the next a 400px one stretched to fit. 10:7 is the ratio that loses the
  // least when the site crops to its three slots (card 10:7, hero 16:10,
  // thumbs 4:3) — worst case ~11%, versus ~17% for 4:3 or 16:10.
  const OUT_W = 1600;
  const OUT_H = 1120;
  /** Below this on the long edge, upscaling shows: the person should know. */
  const MIN_GOOD = 900;

  /**
   * Halving repeatedly before the final draw. One drawImage from 4000px to
   * 1600px samples too sparsely and the result crawls with aliasing — stepping
   * down in halves lets each pass average its neighbours, which is what makes a
   * downscaled photo look sharp rather than noisy.
   */
  const stepDown = (src: HTMLCanvasElement | HTMLImageElement, sw: number, sh: number, tw: number, th: number) => {
    let cur: HTMLCanvasElement | HTMLImageElement = src;
    let cw = sw;
    let ch = sh;
    while (cw / 2 >= tw && ch / 2 >= th) {
      const half = document.createElement('canvas');
      half.width = Math.round(cw / 2);
      half.height = Math.round(ch / 2);
      const hx = half.getContext('2d');
      if (!hx) break;
      hx.imageSmoothingEnabled = true;
      hx.imageSmoothingQuality = 'high';
      hx.drawImage(cur, 0, 0, half.width, half.height);
      cur = half;
      cw = half.width;
      ch = half.height;
    }
    return { cur, cw, ch };
  };

  /**
   * The watermark, drawn straight onto the canvas before export.
   *
   * Every other protection is a speed bump: the browser has to receive the photo
   * to show it, so a screenshot or the network tab defeats all of them. This is
   * in the pixels. It survives copying, re-hosting and re-encoding — which is
   * the whole point.
   *
   * Placed bottom-start, small, at low opacity: readable enough to make a stolen
   * photo awkward to use, quiet enough not to spoil the product shot. Drawn with
   * a dark shadow so it stays legible over a light tank or a dark workshop alike.
   */
  const stamp = (ctx: CanvasRenderingContext2D) => {
    const text = 'egygrouphs.com';
    const pad = Math.round(OUT_W * 0.022);
    const size = Math.round(OUT_W * 0.026);
    ctx.save();
    ctx.font = `600 ${size}px system-ui, -apple-system, sans-serif`;
    ctx.textBaseline = 'bottom';
    ctx.textAlign = 'left';
    ctx.shadowColor = 'rgba(0,0,0,0.55)';
    ctx.shadowBlur = Math.round(size * 0.4);
    ctx.shadowOffsetY = 1;
    ctx.fillStyle = 'rgba(255,255,255,0.72)';
    ctx.fillText(text, pad, OUT_H - pad);
    ctx.restore();
  };

  /**
   * Normalise: centre-crop to 10:7 at a fixed size, re-encode as JPEG.
   * Also the reason an iPhone's HEIC works at all — whatever the browser can
   * decode leaves this function as a plain JPEG every browser can display.
   */
  const normalise = (file: File): Promise<{ blob: Blob; small: boolean; srcLong: number }> =>
    new Promise((resolve, reject) => {
      const img = new Image();
      const url = URL.createObjectURL(file);
      img.onload = () => {
        URL.revokeObjectURL(url);
        const sw = img.naturalWidth;
        const sh = img.naturalHeight;
        if (!sw || !sh) return reject(new Error('empty'));

        // cover: fill the frame, let the overflow fall off the edges
        const k = Math.max(OUT_W / sw, OUT_H / sh);
        const dw = Math.round(sw * k);
        const dh = Math.round(sh * k);

        const c = document.createElement('canvas');
        c.width = OUT_W;
        c.height = OUT_H;
        const ctx = c.getContext('2d');
        if (!ctx) return reject(new Error('no canvas'));
        ctx.imageSmoothingEnabled = true;
        ctx.imageSmoothingQuality = 'high';
        // a PNG may be transparent; JPEG can't be, and unpainted canvas is black
        ctx.fillStyle = '#e9ebee';
        ctx.fillRect(0, 0, OUT_W, OUT_H);

        if (k < 1) {
          const { cur, cw, ch } = stepDown(img, sw, sh, dw, dh);
          ctx.drawImage(cur, 0, 0, cw, ch, Math.round((OUT_W - dw) / 2), Math.round((OUT_H - dh) / 2), dw, dh);
        } else {
          ctx.drawImage(img, Math.round((OUT_W - dw) / 2), Math.round((OUT_H - dh) / 2), dw, dh);
        }

        if (watermark) stamp(ctx);

        c.toBlob(
          (b) => (b ? resolve({ blob: b, small: Math.max(sw, sh) < MIN_GOOD, srcLong: Math.max(sw, sh) }) : reject(new Error('encode'))),
          'image/jpeg',
          0.86
        );
      };
      img.onerror = () => {
        URL.revokeObjectURL(url);
        reject(new Error('decode'));
      };
      img.src = url;
    });

  const upload = async (files: File[]) => {
    const imgs = files.filter((f) => f.type.startsWith('image/') || /\.(jpe?g|png|webp|heic|heif)$/i.test(f.name));
    if (imgs.length === 0) {
      setErr('دول مش صور.');
      return;
    }
    setErr('');

    // ghost tiles first: the wait has to be visible, especially on mobile data
    const ghosts = imgs.map((f) => ({ id: `${f.name}-${f.size}-${Math.random()}`, preview: URL.createObjectURL(f) }));
    setPending(ghosts);

    const fd = new FormData();
    const tooSmall: string[] = [];
    for (const f of imgs) {
      try {
        const { blob, small, srcLong } = await normalise(f);
        if (small) tooSmall.push(`${f.name} (${srcLong}px)`);
        fd.append('file', new File([blob], f.name.replace(/\.[^.]+$/, '') + '.jpg', { type: 'image/jpeg' }));
      } catch {
        // undecodable here (an unusual HEIC, say) — let the server judge it
        fd.append('file', f);
      }
    }

    try {
      const res = await fetch('/api/admin/upload', { method: 'POST', body: fd });
      const d = await res.json().catch(() => ({}));
      if (d?.saved?.length) {
        await loadUploads();
        setPicked((p) => {
          const next = [...p, ...d.saved.map((x: { url: string }) => x.url)];
          return next.slice(0, item?.max ?? 8);
        });
        setSaved(false);
        setNote(
          (d.saved.length === 1 ? 'اترفعت واتحطت على المنتج' : `${d.saved.length} صور اترفعت واتحطت`) +
            ` — ${OUT_W}×${OUT_H}، اضغط «احفظ».`
        );
        if (tooSmall.length) {
          // upscaling can't invent detail — better to say so than ship a soft photo
          setErr(`دقة قليلة: ${tooSmall.join('، ')}. اترفعت بس هتبان مش واضحة — لو عندك نسخة أكبر استبدلها.`);
        }
      }
      if (d?.failed?.length) setErr(`${d.failed.length} صورة اترفضت — المتصفح مش قادر يقراها.`);
      else if (!d?.saved?.length) setErr('مفيش صور اترفعت.');
    } catch {
      setErr('الرفع فشل — شوف النت وجرّب تاني.');
    } finally {
      ghosts.forEach((g) => URL.revokeObjectURL(g.preview));
      setPending([]);
    }
  };

  const removeUpload = async (file: string) => {
    if (!confirm('تمسح الصورة دي نهائياً؟ هتتشال من أي منتج متحطة عليه.')) return;
    await fetch(`/api/admin/upload?file=${encodeURIComponent(file)}`, { method: 'DELETE' }).catch(() => {});
    await loadUploads();
    await loadOverrides();
    setPicked((p) => p.filter((u) => u !== `/api/img/${file}`));
    setNote('اتمسحت.');
  };

  const types = useMemo(() => ['الكل', 'مرفوعاتي', ...Array.from(new Set(LIB.map((p) => p.type)))], []);

  const mine = useMemo<Photo[]>(
    () => uploads.map((u, i) => ({ i: -1 - i, url: u.url, name: u.name, type: 'مرفوعاتي', q: 'ready', w: 0, h: 0 })),
    [uploads]
  );

  /** No cap. Every photo that matches is rendered — hiding some silently is how
   *  people conclude a photo doesn't exist. */
  const photos = useMemo(() => {
    const nq = q.trim().toLowerCase();
    const pool = typeFilter === 'مرفوعاتي' ? mine : typeFilter === 'الكل' ? [...mine, ...LIB] : LIB;
    return pool.filter((p) => {
      if (p.type === 'مرفوعاتي') return !nq || p.name.toLowerCase().includes(nq);
      if (p.q === 'rejected') return false;
      if (readyOnly && p.q !== 'ready') return false;
      if (typeFilter !== 'الكل' && p.type !== typeFilter) return false;
      if (nq && !p.name.toLowerCase().includes(nq)) return false;
      return true;
    });
  }, [typeFilter, readyOnly, q, mine]);

  const login = async () => {
    setErr('');
    const res = await fetch('/api/admin/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ password: pw }),
    });
    const d = await res.json().catch(() => ({}));
    if (d?.ok) setAuthed(true);
    else setErr(d?.error === 'not_configured' ? 'الأدمن مش متظبّط — ضيف ADMIN_PASSWORD في .env.local' : 'الباسورد غلط.');
  };

  const toggle = (url: string) => {
    setSaved(false);
    setPicked((p) => (p.includes(url) ? p.filter((x) => x !== url) : [...p, url].slice(-(item?.max ?? 8))));
  };

  const move = (i: number, dir: -1 | 1) => {
    setSaved(false);
    setPicked((p) => {
      const j = i + dir;
      if (j < 0 || j >= p.length) return p;
      const n = [...p];
      [n[i], n[j]] = [n[j], n[i]];
      return n;
    });
  };

  const save = async () => {
    if (!item) return;
    setSaving(true);
    setErr('');
    try {
      const res = await fetch('/api/admin/images', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ slug: item.key, images: picked }),
      });
      const d = await res.json().catch(() => ({}));
      if (d?.ok) {
        setOverrides((o) => ({ ...o, [item.key]: picked }));
        setSaved(true);
        setNote('اتحفظ — الصفحة اتحدّثت.');
      } else setErr('المحفظش. جرّب تاني.');
    } catch {
      setErr('مفيش اتصال.');
    } finally {
      setSaving(false);
    }
  };

  const reset = async () => {
    if (!item) return;
    setSaving(true);
    await fetch('/api/admin/images', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ slug: item.key, images: [] }),
    }).catch(() => {});
    setOverrides((o) => {
      const n = { ...o };
      delete n[item.key];
      return n;
    });
    setPicked(item.images);
    setSaving(false);
    setNote('رجعت للصور الأصلية.');
  };

  const onDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setDragging(false);
    upload(Array.from(e.dataTransfer.files || []));
  };

  const field = 'w-full rounded-md border border-line bg-ink px-3 py-2 text-[0.9rem] text-paper outline-none focus:border-amber';

  if (!ready) return <p className="p-10 text-center text-muted">…</p>;

  if (!authed) {
    return (
      <div className="mx-auto mt-[14vh] max-w-[380px] px-6">
        <div className="rounded-2xl border border-line bg-ink-2 p-8">
          <h1 className="text-[1.3rem]">إدارة المحتوى</h1>
          <p className="mt-2 text-[0.85rem] text-muted">للتعديل على صور المنتجات.</p>
          {!configured && (
            <p className="mt-4 rounded-lg border border-[#e0503a]/40 bg-[#e0503a]/10 px-3 py-2 text-[0.8rem] text-[#ff9683]">
              محتاج تضيف <code className="font-mono">ADMIN_PASSWORD</code> في <code className="font-mono">.env.local</code>.
            </p>
          )}
          <input
            type="password"
            value={pw}
            onChange={(e) => setPw(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && login()}
            placeholder="الباسورد"
            className={`${field} mt-5 py-3`}
          />
          {err && <p className="mt-2 text-[0.8rem] text-[#ff9683]">{err}</p>}
          <button onClick={login} className="mt-4 w-full rounded-md bg-amber px-5 py-3 text-[14px] font-semibold text-[#161310] transition hover:bg-amber-hi">
            دخول
          </button>
        </div>
      </div>
    );
  }

  const FilePicker = ({ label, cls }: { label: string; cls: string }) => (
    <label className={cls}>
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" className="h-[15px] w-[15px]">
        <path d="M12 16V4M8 8l4-4 4 4M4 16v3a1 1 0 0 0 1 1h14a1 1 0 0 0 1-1v-3" />
      </svg>
      {label}
      <input
        type="file"
        accept="image/*"
        multiple
        className="sr-only"
        onChange={(e) => {
          const f = Array.from(e.target.files || []);
          e.target.value = '';
          upload(f);
        }}
      />
    </label>
  );

  return (
    <div className="mx-auto max-w-[1400px] px-4 py-6 sm:px-5 sm:py-8">
      <div className="mb-5 flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-[1.4rem]">إدارة الصور</h1>
          <p className="mt-1 text-[0.82rem] text-muted">
            {masterItems.length} منتج · {services.items.length} خدمة · {LIB.length + mine.length} صورة · معدّل: {Object.keys(overrides).length}
          </p>
        </div>
        <button
          onClick={() => fetch('/api/admin/login', { method: 'DELETE' }).then(() => setAuthed(false))}
          className="rounded-md border border-line px-4 py-2 text-[13px] text-muted transition hover:text-paper"
        >
          خروج
        </button>
      </div>

      {note && (
        <p className="mb-4 rounded-lg border border-[#4ade80]/40 bg-[#4ade80]/10 px-4 py-2.5 text-[0.85rem] text-[#86efac]">{note}</p>
      )}
      {err && (
        <p className="mb-4 rounded-lg border border-[#e0503a]/40 bg-[#e0503a]/10 px-4 py-2.5 text-[0.85rem] text-[#ff9683]">{err}</p>
      )}

      <div className="grid grid-cols-1 gap-4 lg:grid-cols-[230px_1fr]">
        {/* products */}
        <aside className="lg:sticky lg:top-4 lg:max-h-[88vh] lg:self-start lg:overflow-y-auto">
          <div className="mb-2 flex gap-1 rounded-lg border border-line p-1">
            {(['product', 'service'] as const).map((k) => (
              <button
                key={k}
                onClick={() => {
                  setKind(k);
                  const first = SUBJECTS.find((x) => x.kind === k);
                  if (first) setSlug(first.key);
                }}
                className={`flex-1 rounded-md px-3 py-2 text-[0.84rem] transition ${
                  kind === k ? 'bg-amber font-semibold text-[#161310]' : 'text-muted hover:text-paper'
                }`}
              >
                {k === 'product' ? `منتجات (${masterItems.length})` : `خدمات (${services.items.length})`}
              </button>
            ))}
          </div>

          <select value={slug} onChange={(e) => setSlug(e.target.value)} className={`${field} py-3 lg:hidden`}>
            {shown.map((m) => (
              <option key={m.key} value={m.key}>
                {overrides[m.key] ? '● ' : ''}
                {m.name}
              </option>
            ))}
          </select>

          <ul className="hidden flex-col gap-1 lg:flex">
            {shown.map((m) => {
              const edited = Boolean(overrides[m.key]);
              const on = m.key === slug;
              return (
                <li key={m.key}>
                  <button
                    onClick={() => setSlug(m.key)}
                    className={`flex w-full items-center gap-2 rounded-md px-3 py-2 text-start text-[0.88rem] transition ${
                      on ? 'bg-amber/15 font-semibold text-amber' : 'text-muted hover:bg-ink-2 hover:text-paper'
                    }`}
                  >
                    <span className="flex-1 truncate">{m.name}</span>
                    {edited && <span className="h-[6px] w-[6px] shrink-0 rounded-full bg-amber" title="معدّل" />}
                  </button>
                </li>
              );
            })}
          </ul>
        </aside>

        <div className="min-w-0">
          {/* the product's images + the drop zone that feeds them */}
          <section
            ref={listRef}
            onDragOver={(e) => {
              e.preventDefault();
              setDragging(true);
            }}
            onDragLeave={() => setDragging(false)}
            onDrop={onDrop}
            className={`rounded-xl border-2 bg-ink-2 p-4 transition ${dragging ? 'border-dashed border-amber bg-amber/[0.06]' : 'border-line'}`}
          >
            <div className="mb-3 flex flex-wrap items-center justify-between gap-2">
              <h2 className="text-[1rem]">
                صور <span className="text-amber">{item?.name}</span>
                <span className="ms-2 font-mono text-[0.75rem] text-steel-lt">{picked.length}/{item?.max ?? 8}</span>
              </h2>
              <div className="flex gap-2">
                <button onClick={reset} disabled={saving} className="rounded-md border border-line px-3 py-2 text-[12px] text-muted transition hover:text-paper disabled:opacity-50">
                  رجّع الأصلي
                </button>
                <button onClick={save} disabled={saving} className="rounded-md bg-amber px-6 py-2 text-[13px] font-semibold text-[#161310] transition hover:bg-amber-hi disabled:opacity-50">
                  {saving ? '…' : saved ? 'اتحفظ ✓' : 'احفظ'}
                </button>
              </div>
            </div>

            <div className="flex flex-wrap gap-3">
              {picked.map((u, i) => (
                <div key={u + i} className="w-[96px]">
                  <div className="relative aspect-square overflow-hidden rounded-lg border border-line bg-[#e9ebee]">
                    <img src={thumb(u, 220)} alt="" className="h-full w-full object-cover" />
                    {i === 0 && (
                      <span className="absolute start-0 top-0 rounded-ee bg-amber px-1.5 py-[2px] font-mono text-[8.5px] font-bold text-[#161310]">
                        رئيسية
                      </span>
                    )}
                  </div>
                  {/* always visible: a touch screen has no hover */}
                  <div className="mt-1 flex items-center justify-between gap-0.5">
                    <button onClick={() => move(i, -1)} disabled={i === 0} className="h-[26px] flex-1 rounded border border-line text-[11px] text-muted transition active:bg-ink disabled:opacity-25">
                      ←
                    </button>
                    <button onClick={() => toggle(u)} className="h-[26px] w-[30px] rounded border border-[#e0503a]/50 text-[11px] text-[#ff7a63] transition active:bg-[#e0503a]/20">
                      ✕
                    </button>
                    <button onClick={() => move(i, 1)} disabled={i === picked.length - 1} className="h-[26px] flex-1 rounded border border-line text-[11px] text-muted transition active:bg-ink disabled:opacity-25">
                      →
                    </button>
                  </div>
                </div>
              ))}

              {/* in-flight files, so the wait is visible */}
              {pending.map((g) => (
                <div key={g.id} className="w-[96px]">
                  <div className="relative aspect-square overflow-hidden rounded-lg border border-amber bg-[#e9ebee]">
                    <img src={g.preview} alt="" className="h-full w-full object-cover opacity-40" />
                    <span className="absolute inset-0 grid place-items-center">
                      <span className="h-5 w-5 animate-spin rounded-full border-2 border-amber border-t-transparent" />
                    </span>
                  </div>
                  <p className="mt-1 text-center font-mono text-[9px] text-amber">جارٍ الرفع</p>
                </div>
              ))}

              {picked.length + pending.length < (item?.max ?? 8) && (
                <FilePicker
                  label="ارفع"
                  cls="flex aspect-square w-[96px] cursor-pointer flex-col items-center justify-center gap-1.5 rounded-lg border-2 border-dashed border-line text-[11px] text-muted transition hover:border-amber hover:text-amber"
                />
              )}
            </div>

            <div className="mt-3 flex flex-wrap items-center justify-between gap-3 border-t border-line pt-3">
              <p className="text-[0.75rem] leading-relaxed text-steel-lt">
                {item?.kind === 'service' ? 'خلفية كارت الخدمة — صورة واحدة' : 'الأولى هي اللي بتظهر في الكتالوج'} · اسحب الصور هنا، أو اضغط «ارفع»
                <br />
                بتتظبّط تلقائياً على {OUT_W}×{OUT_H} — نفس مقاس صور المكتبة
              </p>
              <label className="flex cursor-pointer items-center gap-2 rounded-md border border-line px-3 py-2 text-[0.8rem] text-muted transition hover:text-paper">
                <input type="checkbox" checked={watermark} onChange={(e) => setWatermark(e.target.checked)} className="h-4 w-4 accent-amber" />
                علامة مائية
                <span className="font-mono text-[9px] text-steel-lt">egygrouphs.com</span>
              </label>
            </div>
          </section>

          {/* library */}
          <section className="mt-4 rounded-xl border border-line bg-ink-2 p-4">
            <div className="mb-3 flex flex-wrap items-center gap-2">
              <select value={typeFilter} onChange={(e) => setTypeFilter(e.target.value)} className={`${field} max-w-[170px]`}>
                {types.map((t) => (
                  <option key={t} value={t}>
                    {t}
                    {t === 'مرفوعاتي' ? ` (${mine.length})` : ''}
                  </option>
                ))}
              </select>
              <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="بحث بالاسم…" className={`${field} max-w-[190px]`} />
              <label className="flex cursor-pointer items-center gap-2 text-[0.82rem] text-muted">
                <input type="checkbox" checked={readyOnly} onChange={(e) => setReadyOnly(e.target.checked)} className="h-4 w-4 accent-amber" />
                الجاهزة بس
              </label>
              <span className="ms-auto font-mono text-[11px] text-steel-lt">{photos.length} صورة</span>
            </div>

            <div className="grid max-h-[56vh] grid-cols-3 gap-2 overflow-y-auto sm:grid-cols-5 lg:grid-cols-7">
              {photos.map((p) => {
                const on = picked.includes(p.url);
                const own = isUpload(p.url);
                return (
                  <div key={own ? p.url : `lib-${p.i}`} className="relative">
                    <button
                      onClick={() => toggle(p.url)}
                      title={own ? `مرفوعة · ${p.name}` : `${p.type} · ${p.w}×${p.h}`}
                      className={`relative block aspect-square w-full overflow-hidden rounded-md border-2 bg-[#e9ebee] transition ${
                        on ? 'border-amber' : 'border-transparent hover:border-steel-lt'
                      }`}
                    >
                      <img src={thumb(p.url, 200)} alt="" loading="lazy" className="h-full w-full object-cover" />
                      {on && (
                        <span className="absolute inset-0 grid place-items-center bg-amber/40">
                          <span className="text-[22px] font-bold text-[#161310]">✓</span>
                        </span>
                      )}
                      {own && (
                        <span className="absolute start-0 top-0 rounded-ee bg-amber px-1 py-[1px] font-mono text-[8px] font-bold text-[#161310]">
                          بتاعتي
                        </span>
                      )}
                      {p.q === 'ready' && !on && !own && <span className="absolute end-1 top-1 h-[6px] w-[6px] rounded-full bg-[#4ade80]" />}
                    </button>
                    {own && (
                      <button
                        onClick={() => removeUpload(p.url.split('/').pop() as string)}
                        title="امسح نهائياً"
                        aria-label="امسح نهائياً"
                        className="absolute -end-1 -top-1 grid h-[22px] w-[22px] place-items-center rounded-full border border-ink-2 bg-[#e0503a] text-[11px] font-bold text-white shadow transition active:bg-[#ff6a52]"
                      >
                        ✕
                      </button>
                    )}
                  </div>
                );
              })}
            </div>
            {photos.length === 0 && <p className="py-8 text-center text-[0.85rem] text-muted">مفيش صور بالفلتر ده.</p>}
          </section>
        </div>
      </div>
    </div>
  );
}
