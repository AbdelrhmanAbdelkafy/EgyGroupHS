import type { Metadata } from 'next';
import { AdminClient } from './AdminClient';

export const metadata: Metadata = {
  title: 'إدارة المحتوى',
  robots: { index: false, follow: false },
};

// always fresh: an editor must see what's actually saved, never a cached copy
export const dynamic = 'force-dynamic';

export default function AdminPage() {
  return (
    <div className="min-h-screen pt-[74px]">
      <AdminClient />
    </div>
  );
}
