import type { Metadata } from 'next';
import { Locale, isLocale } from '@/lib/i18n';
import { seo, standardsPage as S } from '@/content/site';
import { CTA } from '@/components/sections';
import { Icon } from '@/components/Icon';

export async function generateMetadata({ params }: { params: { locale: string } }): Promise<Metadata> {
  const locale = (isLocale(params.locale) ? params.locale : 'ar') as Locale;
  return { title: seo.standards.title[locale], description: seo.standards.desc[locale] };
}

export default function StandardsPage({ params }: { params: { locale: string } }) {
  const locale = (isLocale(params.locale) ? params.locale : 'ar') as Locale;
  const t = <T extends { ar: string; en: string }>(x: T) => x[locale];

  return (
    <div className="pt-[74px]">
      <section className="py-[100px]">
        <div className="mx-auto max-w-content px-7">
          <div className="reveal mb-16 max-w-[720px]">
            <span className="eyebrow">{t(S.eyebrow)}</span>
            <h1 className="mt-4 text-[clamp(2rem,4vw,3rem)]">{t(S.title)}</h1>
            <p className="mt-4 text-[1.05rem] leading-[1.7] text-muted">{t(S.intro)}</p>
          </div>

          {/* Standards blocks */}
          <div className="grid grid-cols-1 gap-5 md:grid-cols-3">
            {S.blocks.map((b, i) => (
              <div key={i} className="reveal rounded-xl border border-line bg-ink-2 p-[32px]">
                <span className="inline-block rounded-md border border-amber/25 bg-amber/[0.12] px-3 py-2 font-mono text-[13px] font-semibold text-amber">{t(b.badge)}</span>
                <h3 className="mt-5 text-[1.25rem]">{t(b.title)}</h3>
                <p className="mt-3 text-[0.95rem] leading-[1.6] text-muted">{t(b.body)}</p>
              </div>
            ))}
          </div>

          {/* QA / testing */}
          <div className="reveal mt-20">
            <h2 className="text-[clamp(1.6rem,3vw,2.3rem)]">{t(S.qaTitle)}</h2>
            <div className="mt-8 grid grid-cols-1 gap-px overflow-hidden rounded-2xl border border-line bg-line sm:grid-cols-2 lg:grid-cols-4">
              {S.qaItems.map((q, i) => (
                <div key={i} className="bg-ink p-[28px]">
                  <Icon name="tick" className="mb-4 h-6 w-6 text-amber flip-x" strokeWidth={2} />
                  <h4 className="text-[1.08rem] font-bold">{t(q.name)}</h4>
                  <p className="mt-2 text-[0.88rem] leading-[1.5] text-muted">{t(q.d)}</p>
                </div>
              ))}
            </div>
            <p className="mt-8 max-w-[760px] text-[1.05rem] leading-[1.7] text-muted">{t(S.docLine)}</p>
          </div>
        </div>
      </section>
      <CTA locale={locale} />
    </div>
  );
}
