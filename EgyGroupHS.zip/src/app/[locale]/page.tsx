import type { Metadata } from 'next';
import { Locale, isLocale } from '@/lib/i18n';
import { seo } from '@/content/site';
import {
  Hero, SpecStrip, Creed, Sectors, Welding, Capabilities,
  Services, Stock, People, Institution, Ecosystem, Signature, CTA,
} from '@/components/sections';
import { OrganizationJsonLd, ServicesJsonLd } from '@/components/JsonLd';

export async function generateMetadata({ params }: { params: { locale: string } }): Promise<Metadata> {
  const locale = (isLocale(params.locale) ? params.locale : 'ar') as Locale;
  return { title: seo.home.title[locale], description: seo.home.desc[locale] };
}

export default function Home({ params }: { params: { locale: string } }) {
  const locale = (isLocale(params.locale) ? params.locale : 'ar') as Locale;
  return (
    <>
      <OrganizationJsonLd locale={locale} />
      <ServicesJsonLd locale={locale} />
      <Hero locale={locale} />
      <SpecStrip locale={locale} />
      <Creed locale={locale} />
      <Sectors locale={locale} />
      <Welding locale={locale} />
      <Capabilities locale={locale} />
      <Services locale={locale} />
      <Stock locale={locale} />
      <People locale={locale} />
      <Institution locale={locale} />
      <Ecosystem locale={locale} />
      <Signature locale={locale} />
      <CTA locale={locale} />
    </>
  );
}
