import type { Metadata } from 'next';
import { Locale, isLocale } from '@/lib/i18n';
import { seo } from '@/content/site';
import { Services, Welding, Capabilities, CTA } from '@/components/sections';
import { ServicesJsonLd } from '@/components/JsonLd';

export async function generateMetadata({ params }: { params: { locale: string } }): Promise<Metadata> {
  const locale = (isLocale(params.locale) ? params.locale : 'ar') as Locale;
  return { title: seo.services.title[locale], description: seo.services.desc[locale] };
}

export default function ServicesPage({ params }: { params: { locale: string } }) {
  const locale = (isLocale(params.locale) ? params.locale : 'ar') as Locale;
  return (
    <div className="pt-[74px]">
      <ServicesJsonLd locale={locale} />
      <Services locale={locale} />
      <Welding locale={locale} />
      <Capabilities locale={locale} />
      <CTA locale={locale} />
    </div>
  );
}
