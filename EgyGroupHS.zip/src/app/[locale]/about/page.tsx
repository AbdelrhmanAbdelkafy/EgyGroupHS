import type { Metadata } from 'next';
import { Locale, isLocale } from '@/lib/i18n';
import { seo } from '@/content/site';
import { Creed, People, Institution, Ecosystem, Signature, CTA } from '@/components/sections';
import { OrganizationJsonLd } from '@/components/JsonLd';

export async function generateMetadata({ params }: { params: { locale: string } }): Promise<Metadata> {
  const locale = (isLocale(params.locale) ? params.locale : 'ar') as Locale;
  return { title: seo.about.title[locale], description: seo.about.desc[locale] };
}

export default function AboutPage({ params }: { params: { locale: string } }) {
  const locale = (isLocale(params.locale) ? params.locale : 'ar') as Locale;
  return (
    <div className="pt-[74px]">
      <OrganizationJsonLd locale={locale} />
      <Creed locale={locale} />
      <People locale={locale} />
      <Institution locale={locale} />
      <Ecosystem locale={locale} />
      <Signature locale={locale} />
      <CTA locale={locale} />
    </div>
  );
}
