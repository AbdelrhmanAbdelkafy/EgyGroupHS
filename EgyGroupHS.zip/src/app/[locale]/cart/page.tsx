import type { Metadata } from 'next';
import { Locale, isLocale } from '@/lib/i18n';
import { CartView } from './CartView';

export const metadata: Metadata = { robots: { index: false } };

export default function CartPage({ params }: { params: { locale: string } }) {
  const locale = (isLocale(params.locale) ? params.locale : 'ar') as Locale;
  const isAr = locale === 'ar';
  return (
    <div className="pt-[74px]">
      <section className="py-[80px]">
        <div className="mx-auto max-w-content px-7">
          <div className="reveal mb-8">
            <span className="eyebrow">{isAr ? 'السلة' : 'Cart'}</span>
            <h1 className="mt-4 text-[clamp(1.8rem,3.5vw,2.5rem)]">{isAr ? 'أصنافك.' : 'Your items.'}</h1>
          </div>
          <div className="reveal">
            <CartView locale={locale} />
          </div>
        </div>
      </section>
    </div>
  );
}
