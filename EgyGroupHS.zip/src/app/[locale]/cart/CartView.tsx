'use client';

import { useEffect, useState } from 'react';
import { photoSrc } from '@/lib/photo';
import Link from 'next/link';
import { Locale } from '@/lib/i18n';
import { useCart } from '@/lib/cart';
import { Icon } from '@/components/Icon';

type Account = { name: string; company: string; phone: string; email: string } | null;

export function CartView({ locale }: { locale: Locale }) {
  const isAr = locale === 'ar';
  const { items: lines, setQty, remove, clear, ready } = useCart();
  const [account, setAccount] = useState<Account>(null);
  const [guest, setGuest] = useState({ name: '', company: '', phone: '', email: '' });
  const [notes, setNotes] = useState('');
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState('');
  const [sent, setSent] = useState(false);

  useEffect(() => {
    fetch('/api/auth/me').then((r) => r.json()).then((d) => d?.user && setAccount(d.user)).catch(() => {});
  }, []);

  const submit = async () => {
    setErr('');
    if (!account && (!guest.name.trim() || !guest.phone.trim())) {
      setErr(isAr ? 'محتاجين اسمك وتليفونك.' : 'We need your name and phone.');
      return;
    }
    setBusy(true);
    try {
      const res = await fetch('/api/order', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          lines: lines.map((l) => ({ name: l.name, slug: l.slug, qty: l.qty, specs: l.specs })),
          notes,
          ...(account ? {} : guest),
          locale,
        }),
      });
      const d = await res.json().catch(() => ({}));
      if (res.ok && d.ok) { setSent(true); clear(); }
      else setErr(
        d?.error === 'crm_not_configured'
          ? (isAr ? 'الخدمة مش مظبوطة حالياً. كلمنا من فضلك.' : 'Service not configured. Please call us.')
          : (isAr ? 'الطلب مانفعش يتبعت. جرّب تاني.' : 'Could not send. Try again.')
      );
    } catch {
      setErr(isAr ? 'مفيش اتصال.' : 'No connection.');
    } finally { setBusy(false); }
  };

  const field = 'w-full rounded-md border border-line bg-ink px-4 py-3 text-[0.95rem] text-paper outline-none transition focus:border-amber';

  if (sent) {
    return (
      <div className="rounded-2xl border border-amber/30 bg-amber/[0.06] p-10 text-center">
        <Icon name="check" className="mx-auto h-10 w-10 text-amber" strokeWidth={2} />
        <h2 className="mt-4 text-[1.5rem]">{isAr ? 'وصل طلبك.' : 'Your request is in.'}</h2>
        <p className="mx-auto mt-3 max-w-[420px] text-muted">
          {isAr ? 'المبيعات هتراجع الأصناف وترجعلك بعرض سعر.' : 'Sales will review the items and come back with a quote.'}
        </p>
        <Link href={`/${locale}/catalog`} className="mt-6 inline-flex items-center gap-2 text-[14px] font-semibold text-amber">
          {isAr ? 'ارجع للكتالوج' : 'Back to the catalogue'}
        </Link>
      </div>
    );
  }

  if (!ready) return <p className="text-muted">…</p>;

  if (lines.length === 0) {
    return (
      <div className="rounded-2xl border border-line bg-ink-2 p-12 text-center">
        <p className="text-[1.1rem]">{isAr ? 'السلة فاضية.' : 'Your cart is empty.'}</p>
        <p className="mx-auto mt-2 max-w-[440px] text-[0.92rem] text-muted">
          {isAr
            ? 'السلة للأصناف الجاهزة والتوريد. لو محتاج حاجة مصنّعة على المقاس، اطلب معاينة ومهندس يجيلك.'
            : 'The cart is for stock and supply items. If you need something made to measure, request a site visit and an engineer will come to you.'}
        </p>
        <div className="mt-6 flex flex-wrap justify-center gap-3">
          <Link href={`/${locale}/catalog`} className="rounded-md bg-amber px-6 py-3 text-[14px] font-semibold text-[#161310] transition hover:bg-amber-hi">
            {isAr ? 'تصفّح الكتالوج' : 'Browse the catalogue'}
          </Link>
          <Link href={`/${locale}/site-visit`} className="rounded-md border border-line px-6 py-3 text-[14px] text-muted transition hover:border-steel-lt hover:text-paper">
            {isAr ? 'اطلب معاينة' : 'Request a site visit'}
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 gap-6 lg:grid-cols-[1.3fr_0.7fr]">
      {/* lines */}
      <div className="flex flex-col gap-3">
        {lines.map((l) => (
          <div key={l.key} className="flex gap-4 rounded-xl border border-line bg-ink-2 p-4">
            <div className="h-[86px] w-[86px] shrink-0 overflow-hidden rounded-lg bg-[#e9ebee]">
              <img
                src={photoSrc(l.image, 180, 180)}
                alt={l.name}
                className="h-full w-full object-cover"
              />
            </div>
            <div className="min-w-0 flex-1">
              <div className="flex items-start justify-between gap-3">
                <h3 className="text-[1.02rem]">{l.name}</h3>
                <button onClick={() => remove(l.key)} className="shrink-0 text-[12px] text-muted transition hover:text-[#ff7a63]">
                  {isAr ? 'شيل' : 'Remove'}
                </button>
              </div>
              {l.specs.length > 0 && (
                <ul className="mt-1.5 flex flex-wrap gap-x-3 gap-y-0.5">
                  {l.specs.map((s, i) => (
                    <li key={i} className="text-[0.8rem] text-muted">{s.label}: <span className="text-paper">{s.value}</span></li>
                  ))}
                </ul>
              )}
              <div className="mt-3 inline-flex items-center gap-1 rounded-md border border-line">
                <button onClick={() => setQty(l.key, l.qty - 1)} className="px-3 py-1 text-muted transition hover:text-amber">−</button>
                <span className="min-w-[34px] text-center font-mono text-[13px]">{l.qty}</span>
                <button onClick={() => setQty(l.key, l.qty + 1)} className="px-3 py-1 text-muted transition hover:text-amber">+</button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* checkout */}
      <div className="rounded-2xl border border-line bg-ink-2 p-[26px] lg:sticky lg:top-[100px] lg:self-start">
        <h2 className="text-[1.15rem]">{isAr ? 'ابعت الطلب' : 'Send the request'}</h2>

        {account ? (
          <div className="mt-4 rounded-lg border border-line bg-ink px-4 py-3">
            <div className="text-[0.95rem]">{account.name}{account.company && <span className="text-muted"> · {account.company}</span>}</div>
            <div className="text-[0.82rem] text-muted">{account.phone}</div>
          </div>
        ) : (
          <div className="mt-4 flex flex-col gap-3">
            <input className={field} placeholder={isAr ? 'الاسم *' : 'Name *'} value={guest.name} onChange={(e) => setGuest({ ...guest, name: e.target.value })} />
            <input className={field} placeholder={isAr ? 'الشركة' : 'Company'} value={guest.company} onChange={(e) => setGuest({ ...guest, company: e.target.value })} />
            <input className={field} placeholder={isAr ? 'التليفون *' : 'Phone *'} value={guest.phone} onChange={(e) => setGuest({ ...guest, phone: e.target.value })} />
            <input className={field} type="email" placeholder={isAr ? 'البريد' : 'Email'} value={guest.email} onChange={(e) => setGuest({ ...guest, email: e.target.value })} />
          </div>
        )}

        <textarea
          className={`${field} mt-3 min-h-[80px] resize-y`}
          placeholder={isAr ? 'ملاحظات (اختياري)' : 'Notes (optional)'}
          value={notes}
          onChange={(e) => setNotes(e.target.value)}
        />

        {err && <p className="mt-3 text-[0.85rem] text-[#ff9683]">{err}</p>}

        <button
          onClick={submit}
          disabled={busy}
          className="mt-4 inline-flex w-full items-center justify-center gap-2 rounded-md bg-amber px-6 py-[14px] text-[15px] font-semibold text-[#161310] transition hover:bg-amber-hi disabled:opacity-60"
        >
          {busy ? (isAr ? 'جارٍ الإرسال…' : 'Sending…') : isAr ? 'اطلب عرض سعر' : 'Request a quote'}
        </button>

        <p className="mt-3 text-center text-[0.8rem] text-muted">
          {isAr ? 'المبيعات بترجعلك بالأسعار والتوفّر.' : 'Sales come back with prices and availability.'}
        </p>
      </div>
    </div>
  );
}
