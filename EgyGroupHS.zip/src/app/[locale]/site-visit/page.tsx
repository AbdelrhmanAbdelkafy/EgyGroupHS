import type { Metadata } from 'next';
import { Locale, isLocale } from '@/lib/i18n';
import { Suspense } from 'react';
import { SiteVisitForm } from './SiteVisitForm';

export async function generateMetadata({ params }: { params: { locale: string } }): Promise<Metadata> {
  const locale = (isLocale(params.locale) ? params.locale : 'ar') as Locale;
  const isAr = locale === 'ar';
  return {
    title: isAr
      ? 'طلب معاينة — مهندس يرفع المقاس في موقعك | المجموعة المصرية'
      : 'Request a site visit — an engineer measures on site | Egyptian Group',
    description: isAr
      ? 'اطلب مهندس من المجموعة المصرية (Hard Steel) يجي موقعك يرفع المقاس ويشوف المطلوب على الطبيعة. حدّد المكان والميعاد، وسجّل طلبك بصوتك.'
      : 'Request an engineer from the Egyptian Group (Hard Steel) to come to your site, take measurements and see the job first-hand. Set the place and time, and record your request in your own voice.',
  };
}

export default function SiteVisitPage({ params }: { params: { locale: string } }) {
  const locale = (isLocale(params.locale) ? params.locale : 'ar') as Locale;
  const isAr = locale === 'ar';

  return (
    <div className="pt-[74px]">
      <section className="py-[80px]">
        <div className="mx-auto max-w-[820px] px-7">
          <div className="reveal mb-9">
            <span className="eyebrow">{isAr ? 'طلب معاينة' : 'Site visit'}</span>
            <h1 className="mt-4 text-[clamp(1.9rem,4vw,2.8rem)]">
              {isAr ? 'خلي مهندس يجيلك يرفع المقاس.' : 'Have an engineer come and measure.'}
            </h1>
            <p className="mt-4 text-[1.05rem] leading-[1.75] text-muted">
              {isAr
                ? 'املأ اللي تحت وهيوصل لمبيعات المنتجات على طول. كل معلومة هنا بتوفّر مكالمة — المهندس هيعرف رايح فين، إمتى، بخصوص إيه، ومين هيستقبله.'
                : 'Fill this in and it reaches product sales directly. Every field here saves a phone call — the engineer knows where he is going, when, what for, and who will meet him.'}
            </p>
          </div>
          <div className="reveal">
            <Suspense fallback={<div className="h-[400px] rounded-2xl border border-line bg-ink-2" />}>
              <SiteVisitForm locale={locale} />
            </Suspense>
          </div>
        </div>
      </section>
    </div>
  );
}
