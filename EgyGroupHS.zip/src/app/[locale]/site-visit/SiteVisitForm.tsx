'use client';

import { useEffect, useRef, useState } from 'react';
import { useSearchParams } from 'next/navigation';
import { Locale } from '@/lib/i18n';
import { Icon } from '@/components/Icon';

// ============================================================================
// The site-visit form. Everything on it exists so the engineer can drive out
// and take measurements without ringing the customer first: where, when, what
// for, and who opens the gate. The voice note carries the things people
// explain in ten seconds but won't type.
// ============================================================================

type Account = { id: string; name: string; company: string; phone: string; email: string } | null;

const T = {
  eyebrow: { ar: 'طلب معاينة', en: 'Site visit' },
  title: { ar: 'خلي مهندس يجيلك يرفع المقاس.', en: 'Have an engineer come and measure.' },
  intro: {
    ar: 'املأ اللي تحت وهيوصل لمبيعات المنتجات على طول. كل معلومة هنا بتوفّر مكالمة — المهندس هيعرف رايح فين، إمتى، بخصوص إيه، ومين هيستقبله.',
    en: 'Fill this in and it reaches product sales directly. Every field here saves a phone call — the engineer knows where he is going, when, what for, and who will meet him.',
  },
  signedInAs: { ar: 'داخل باسم', en: 'Signed in as' },
  logout: { ar: 'خروج', en: 'Sign out' },
  tabLogin: { ar: 'عندي حساب', en: 'I have an account' },
  tabRegister: { ar: 'حساب جديد', en: 'New account' },
  tabGuest: { ar: 'كمّل من غير حساب', en: 'Continue as guest' },
  whyAccount: {
    ar: 'بحساب: بياناتك بتتحفظ، وتقدر تبعت طلب بصوتك في ثانية من غير ما تملأ حاجة تاني.',
    en: 'With an account your details are saved, and you can send a voice request in seconds without filling anything again.',
  },
  // fields
  subject: { ar: 'المعاينة بخصوص إيه؟', en: 'What is the visit about?' },
  subjectHint: { ar: 'مثال: تنك خلط 5 م³ · خط مواسير لمصنع ألبان', en: 'e.g. 5 m³ mixing tank · dairy plant piping' },
  address: { ar: 'المكان', en: 'Location' },
  addressHint: { ar: 'العنوان بالتفصيل — المنطقة الصناعية، رقم القطعة، علامة مميزة', en: 'Full address — industrial zone, plot number, landmark' },
  mapUrl: { ar: 'لينك الموقع على الخرايط (اختياري)', en: 'Map link (optional)' },
  date: { ar: 'التاريخ', en: 'Date' },
  time: { ar: 'الساعة', en: 'Time' },
  receiverName: { ar: 'مين هيستقبل المهندس؟', en: 'Who will receive the engineer?' },
  receiverPhone: { ar: 'تليفونه', en: 'His phone' },
  notes: { ar: 'أي حاجة تانية المهندس لازم يعرفها', en: 'Anything else the engineer should know' },
  notesHint: { ar: 'تصاريح دخول، مواعيد الورديات، خطر معيّن...', en: 'Entry permits, shift times, a specific hazard…' },
  // voice
  voiceTitle: { ar: 'أو سجّل صوتك', en: 'Or record your voice' },
  voiceHint: {
    ar: 'اشرح المطلوب بصوتك — المهندس هيسمعه قبل ما ييجي.',
    en: 'Explain it in your own voice — the engineer will hear it before he arrives.',
  },
  recStart: { ar: 'ابدأ التسجيل', en: 'Start recording' },
  recStop: { ar: 'إيقاف', en: 'Stop' },
  recAgain: { ar: 'سجّل تاني', en: 'Record again' },
  recDenied: { ar: 'المتصفح رفض الميكروفون. اسمح بالوصول وجرّب تاني.', en: 'The browser blocked the microphone. Allow access and try again.' },
  recUnsupported: { ar: 'متصفحك مش بيدعم التسجيل — اكتب في الملاحظات بدلها.', en: 'Your browser does not support recording — use the notes field instead.' },
  send: { ar: 'ابعت طلب المعاينة', en: 'Send visit request' },
  sending: { ar: 'جارٍ الإرسال…', en: 'Sending…' },
  doneTitle: { ar: 'وصل الطلب.', en: 'Request received.' },
  doneBody: {
    ar: 'الموعد اتحجز عند مبيعات المنتجات، والمهندس هيتواصل لتأكيد الميعاد.',
    en: 'The appointment is booked with product sales, and the engineer will confirm the timing.',
  },
};

export function SiteVisitForm({ locale }: { locale: Locale }) {
  const t = <K extends keyof typeof T>(k: K) => T[k][locale];
  const isAr = locale === 'ar';

  const params = useSearchParams();
  const [account, setAccount] = useState<Account>(null);
  const [checking, setChecking] = useState(true);
  const [mode, setMode] = useState<'login' | 'register' | 'guest'>('login');

  const [form, setForm] = useState({
    subject: '', address: '', mapUrl: '', date: '', time: '',
    receiverName: '', receiverPhone: '', notes: '',
  });
  const [guest, setGuest] = useState({ name: '', company: '', phone: '', email: '' });
  const [cred, setCred] = useState({ name: '', company: '', phone: '', email: '', password: '' });

  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState('');
  const [sent, setSent] = useState(false);

  // ---- voice ----
  const [recording, setRecording] = useState(false);
  const [audioUrl, setAudioUrl] = useState<string | null>(null);
  const [audioBlob, setAudioBlob] = useState<Blob | null>(null);
  const [secs, setSecs] = useState(0);
  const recRef = useRef<MediaRecorder | null>(null);
  const chunksRef = useRef<Blob[]>([]);
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);

  // carry over the spec picked in the catalogue
  useEffect(() => {
    const s = params?.get('subject');
    if (s) setForm((f) => (f.subject ? f : { ...f, subject: s }));
  }, [params]);

  useEffect(() => {
    fetch('/api/auth/me')
      .then((r) => r.json())
      .then((d) => {
        if (d?.user) { setAccount(d.user); setMode('guest'); }
      })
      .catch(() => {})
      .finally(() => setChecking(false));
  }, []);

  useEffect(() => () => {
    if (timerRef.current) clearInterval(timerRef.current);
    if (audioUrl) URL.revokeObjectURL(audioUrl);
  }, [audioUrl]);

  const startRec = async () => {
    setErr('');
    if (typeof window === 'undefined' || !navigator.mediaDevices?.getUserMedia || typeof MediaRecorder === 'undefined') {
      setErr(t('recUnsupported')); return;
    }
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const mime = MediaRecorder.isTypeSupported('audio/webm') ? 'audio/webm' : '';
      const rec = new MediaRecorder(stream, mime ? { mimeType: mime } : undefined);
      chunksRef.current = [];
      rec.ondataavailable = (e) => { if (e.data.size) chunksRef.current.push(e.data); };
      rec.onstop = () => {
        const blob = new Blob(chunksRef.current, { type: rec.mimeType || 'audio/webm' });
        setAudioBlob(blob);
        setAudioUrl(URL.createObjectURL(blob));
        stream.getTracks().forEach((tr) => tr.stop());
      };
      rec.start();
      recRef.current = rec;
      setRecording(true);
      setSecs(0);
      timerRef.current = setInterval(() => setSecs((s) => s + 1), 1000);
    } catch {
      setErr(t('recDenied'));
    }
  };

  const stopRec = () => {
    recRef.current?.stop();
    setRecording(false);
    if (timerRef.current) clearInterval(timerRef.current);
  };

  const resetRec = () => {
    if (audioUrl) URL.revokeObjectURL(audioUrl);
    setAudioUrl(null); setAudioBlob(null); setSecs(0);
  };

  const doAuth = async (kind: 'login' | 'register') => {
    setErr(''); setBusy(true);
    try {
      const body = kind === 'login'
        ? { phone: cred.phone, password: cred.password }
        : cred;
      const res = await fetch(`/api/auth/${kind}`, {
        method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body),
      });
      const d = await res.json();
      if (d?.ok) { setAccount(d.user); setMode('guest'); }
      else setErr(
        d?.error === 'bad_credentials' ? (isAr ? 'التليفون أو الباسورد غلط.' : 'Wrong phone or password.')
        : d?.error === 'phone_exists' ? (isAr ? 'التليفون ده مسجّل. ادخل بحسابك.' : 'That phone is registered. Sign in.')
        : d?.error === 'password_too_short' ? (isAr ? 'الباسورد لازم 6 حروف على الأقل.' : 'Password must be at least 6 characters.')
        : (isAr ? 'حصلت مشكلة. جرّب تاني.' : 'Something went wrong. Try again.')
      );
    } catch {
      setErr(isAr ? 'مفيش اتصال. جرّب تاني.' : 'No connection. Try again.');
    } finally { setBusy(false); }
  };

  const logout = async () => {
    await fetch('/api/auth/logout', { method: 'POST' }).catch(() => {});
    setAccount(null); setMode('login');
  };

  const submit = async () => {
    setErr('');
    const need = [form.subject, form.address, form.date, form.time, form.receiverName, form.receiverPhone];
    if (need.some((v) => !v.trim())) {
      setErr(isAr ? 'كمّل الحقول المطلوبة.' : 'Please complete the required fields.'); return;
    }
    if (!account && (!guest.name.trim() || !guest.phone.trim())) {
      setErr(isAr ? 'محتاجين اسمك وتليفونك.' : 'We need your name and phone.'); return;
    }
    setBusy(true);
    try {
      let voiceUrl: string | undefined;
      if (audioBlob) {
        const fd = new FormData();
        fd.append('audio', audioBlob, 'note.webm');
        const vr = await fetch('/api/voice', { method: 'POST', body: fd });
        const vd = await vr.json().catch(() => ({}));
        if (vd?.ok) voiceUrl = vd.url;
      }
      const res = await fetch('/api/site-visit', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...form, voiceUrl, ...(account ? {} : guest), locale }),
      });
      const d = await res.json().catch(() => ({}));
      if (res.ok && d.ok) setSent(true);
      else setErr(
        d?.error === 'crm_not_configured' ? (isAr ? 'الخدمة مش مظبوطة حالياً. كلمنا على طول من فضلك.' : 'The service is not configured. Please call us directly.')
        : (isAr ? 'الطلب مانفعش يتبعت. جرّب تاني أو كلمنا.' : 'The request could not be sent. Try again or call us.')
      );
    } catch {
      setErr(isAr ? 'مفيش اتصال. جرّب تاني.' : 'No connection. Try again.');
    } finally { setBusy(false); }
  };

  const field = 'w-full rounded-md border border-line bg-ink px-4 py-3 text-[0.95rem] text-paper outline-none transition focus:border-amber';
  const label = 'mb-2 block font-mono text-[11px] uppercase tracking-[0.14em] text-steel-lt';

  if (sent) {
    return (
      <div className="rounded-2xl border border-amber/30 bg-amber/[0.06] p-10 text-center">
        <Icon name="check" className="mx-auto h-10 w-10 text-amber" strokeWidth={2} />
        <h2 className="mt-4 text-[1.5rem]">{t('doneTitle')}</h2>
        <p className="mx-auto mt-3 max-w-[420px] text-muted">{t('doneBody')}</p>
      </div>
    );
  }

  return (
    <div className="flex flex-col gap-6">
      {/* identity */}
      <div className="rounded-2xl border border-line bg-ink-2 p-[26px]">
        {checking ? (
          <p className="text-[0.9rem] text-muted">…</p>
        ) : account ? (
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div>
              <div className="font-mono text-[11px] uppercase tracking-[0.14em] text-steel-lt">{t('signedInAs')}</div>
              <div className="mt-1 text-[1.05rem]">
                {account.name}
                {account.company && <span className="text-muted"> · {account.company}</span>}
              </div>
              <div className="text-[0.85rem] text-muted">{account.phone}</div>
            </div>
            <button onClick={logout} className="rounded-md border border-line px-4 py-2 text-[13px] text-muted transition hover:border-steel-lt hover:text-paper">
              {t('logout')}
            </button>
          </div>
        ) : (
          <>
            <div className="mb-4 flex flex-wrap gap-2">
              {(['login', 'register', 'guest'] as const).map((m) => (
                <button
                  key={m}
                  onClick={() => { setMode(m); setErr(''); }}
                  className={`rounded-md border px-4 py-[9px] text-[13.5px] transition ${
                    mode === m ? 'border-amber bg-amber text-[#161310] font-semibold' : 'border-line text-muted hover:border-steel-lt hover:text-paper'
                  }`}
                >
                  {m === 'login' ? t('tabLogin') : m === 'register' ? t('tabRegister') : t('tabGuest')}
                </button>
              ))}
            </div>

            {mode === 'login' && (
              <div className="flex flex-col gap-3">
                <input className={field} placeholder={isAr ? 'التليفون' : 'Phone'} value={cred.phone} onChange={(e) => setCred({ ...cred, phone: e.target.value })} />
                <input className={field} type="password" placeholder={isAr ? 'الباسورد' : 'Password'} value={cred.password} onChange={(e) => setCred({ ...cred, password: e.target.value })} />
                <button onClick={() => doAuth('login')} disabled={busy} className="rounded-md bg-amber px-6 py-3 text-[14px] font-semibold text-[#161310] transition hover:bg-amber-hi disabled:opacity-60">
                  {busy ? t('sending') : isAr ? 'دخول' : 'Sign in'}
                </button>
              </div>
            )}

            {mode === 'register' && (
              <div className="flex flex-col gap-3">
                <p className="text-[0.85rem] leading-[1.6] text-muted">{t('whyAccount')}</p>
                <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
                  <input className={field} placeholder={isAr ? 'الاسم' : 'Name'} value={cred.name} onChange={(e) => setCred({ ...cred, name: e.target.value })} />
                  <input className={field} placeholder={isAr ? 'الشركة' : 'Company'} value={cred.company} onChange={(e) => setCred({ ...cred, company: e.target.value })} />
                  <input className={field} placeholder={isAr ? 'التليفون' : 'Phone'} value={cred.phone} onChange={(e) => setCred({ ...cred, phone: e.target.value })} />
                  <input className={field} type="email" placeholder={isAr ? 'البريد' : 'Email'} value={cred.email} onChange={(e) => setCred({ ...cred, email: e.target.value })} />
                </div>
                <input className={field} type="password" placeholder={isAr ? 'باسورد (6 حروف على الأقل)' : 'Password (6+ characters)'} value={cred.password} onChange={(e) => setCred({ ...cred, password: e.target.value })} />
                <button onClick={() => doAuth('register')} disabled={busy} className="rounded-md bg-amber px-6 py-3 text-[14px] font-semibold text-[#161310] transition hover:bg-amber-hi disabled:opacity-60">
                  {busy ? t('sending') : isAr ? 'اعمل حساب' : 'Create account'}
                </button>
              </div>
            )}

            {mode === 'guest' && (
              <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
                <input className={field} placeholder={isAr ? 'الاسم *' : 'Name *'} value={guest.name} onChange={(e) => setGuest({ ...guest, name: e.target.value })} />
                <input className={field} placeholder={isAr ? 'الشركة' : 'Company'} value={guest.company} onChange={(e) => setGuest({ ...guest, company: e.target.value })} />
                <input className={field} placeholder={isAr ? 'التليفون *' : 'Phone *'} value={guest.phone} onChange={(e) => setGuest({ ...guest, phone: e.target.value })} />
                <input className={field} type="email" placeholder={isAr ? 'البريد' : 'Email'} value={guest.email} onChange={(e) => setGuest({ ...guest, email: e.target.value })} />
              </div>
            )}
          </>
        )}
      </div>

      {/* the visit itself */}
      <div className="rounded-2xl border border-line bg-ink-2 p-[26px]">
        <div className="flex flex-col gap-5">
          <div>
            <label className={label}>{t('subject')} *</label>
            <input className={field} placeholder={t('subjectHint')} value={form.subject} onChange={(e) => setForm({ ...form, subject: e.target.value })} />
          </div>

          <div>
            <label className={label}>{t('address')} *</label>
            <textarea className={`${field} min-h-[90px] resize-y`} placeholder={t('addressHint')} value={form.address} onChange={(e) => setForm({ ...form, address: e.target.value })} />
          </div>

          <div>
            <label className={label}>{t('mapUrl')}</label>
            <input className={field} dir="ltr" placeholder="https://maps.app.goo.gl/…" value={form.mapUrl} onChange={(e) => setForm({ ...form, mapUrl: e.target.value })} />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className={label}>{t('date')} *</label>
              <input className={field} type="date" value={form.date} onChange={(e) => setForm({ ...form, date: e.target.value })} />
            </div>
            <div>
              <label className={label}>{t('time')} *</label>
              <input className={field} type="time" value={form.time} onChange={(e) => setForm({ ...form, time: e.target.value })} />
            </div>
          </div>

          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
            <div>
              <label className={label}>{t('receiverName')} *</label>
              <input className={field} value={form.receiverName} onChange={(e) => setForm({ ...form, receiverName: e.target.value })} />
            </div>
            <div>
              <label className={label}>{t('receiverPhone')} *</label>
              <input className={field} value={form.receiverPhone} onChange={(e) => setForm({ ...form, receiverPhone: e.target.value })} />
            </div>
          </div>

          <div>
            <label className={label}>{t('notes')}</label>
            <textarea className={`${field} min-h-[80px] resize-y`} placeholder={t('notesHint')} value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} />
          </div>
        </div>
      </div>

      {/* voice */}
      <div className="rounded-2xl border border-line bg-ink-2 p-[26px]">
        <h3 className="text-[1.1rem]">🎤 {t('voiceTitle')}</h3>
        <p className="mt-2 text-[0.88rem] leading-[1.6] text-muted">{t('voiceHint')}</p>

        <div className="mt-5 flex flex-wrap items-center gap-3">
          {!recording && !audioUrl && (
            <button onClick={startRec} className="inline-flex items-center gap-2 rounded-md border border-amber bg-amber/10 px-5 py-3 text-[14px] font-semibold text-amber transition hover:bg-amber/20">
              <span className="h-[10px] w-[10px] rounded-full bg-amber" />
              {t('recStart')}
            </button>
          )}
          {recording && (
            <>
              <button onClick={stopRec} className="inline-flex items-center gap-2 rounded-md border border-[#e0503a] bg-[#e0503a]/12 px-5 py-3 text-[14px] font-semibold text-[#ff7a63] transition hover:bg-[#e0503a]/20">
                <span className="h-[10px] w-[10px] animate-pulse rounded-sm bg-[#ff7a63]" />
                {t('recStop')}
              </button>
              <span className="font-mono text-[14px] text-amber">
                {String(Math.floor(secs / 60)).padStart(2, '0')}:{String(secs % 60).padStart(2, '0')}
              </span>
            </>
          )}
          {audioUrl && !recording && (
            <>
              <audio controls src={audioUrl} className="max-w-full" />
              <button onClick={resetRec} className="rounded-md border border-line px-4 py-2 text-[13px] text-muted transition hover:border-steel-lt hover:text-paper">
                {t('recAgain')}
              </button>
            </>
          )}
        </div>
      </div>

      {err && (
        <div className="rounded-lg border border-[#e0503a]/40 bg-[#e0503a]/10 px-4 py-3 text-[0.9rem] text-[#ff9683]">{err}</div>
      )}

      <button
        onClick={submit}
        disabled={busy}
        className="inline-flex items-center justify-center gap-[9px] rounded-md bg-amber px-7 py-[16px] text-[15px] font-semibold text-[#161310] transition hover:bg-amber-hi disabled:opacity-60"
      >
        {busy ? t('sending') : t('send')}
        {!busy && <Icon name="arrow" className="h-[15px] w-[15px] flip-x" strokeWidth={2.4} />}
      </button>
    </div>
  );
}

export const siteVisitCopy = T;
