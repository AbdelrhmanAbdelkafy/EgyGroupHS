import type { Metadata } from 'next';
import Link from 'next/link';
import { Locale, isLocale } from '@/lib/i18n';
import { masterItems, catalogPage as CP } from '@/content/catalog';
import { Icon } from '@/components/Icon';
import { CatalogGrid } from './CatalogGrid';

export async function generateMetadata({ params }: { params: { locale: string } }): Promise<Metadata> {
  const locale = (isLocale(params.locale) ? params.locale : 'ar') as Locale;
  const isAr = locale === 'ar';
  return {
    title: isAr
      ? 'الكتالوج — تنكات، خطوط مواسير، تجهيزات استانلس | المجموعة المصرية'
      : 'Catalogue — Tanks, Process Piping, Stainless Fixtures | Egyptian Group',
    description: isAr
      ? 'كتالوج منتجات المجموعة المصرية (Hard Steel): تنكات وخزانات، خطوط مواسير، سلالم سيفتي، منصات، ترابيزات وكراسي استانلس. حدّد مواصفاتك واطلب عرض سعر.'
      : 'Product catalogue of the Egyptian Group (Hard Steel): tanks and vessels, process piping, safety ladders, platforms, stainless tables and chairs. Specify what you need and request a quote.',
  };
}

export default function CatalogPage({ params }: { params: { locale: string } }) {
  const locale = (isLocale(params.locale) ? params.locale : 'ar') as Locale;
  const t = <T extends { ar: string; en: string }>(x: T) => x[locale];

  return (
    <div className="pt-[74px]">
      <section className="py-[90px]">
        <div className="mx-auto max-w-content px-7">
          <div className="reveal mb-12 max-w-[700px]">
            <span className="eyebrow">{t(CP.eyebrow)}</span>
            <h1 className="mt-4 text-[clamp(2rem,4vw,3rem)]">{t(CP.title)}</h1>
            <p className="mt-4 text-[1.05rem] leading-[1.7] text-muted">{t(CP.intro)}</p>
          </div>
          <CatalogGrid locale={locale} />
        </div>
      </section>

      {/* quote strip */}
      <section className="border-y border-line bg-ink-2 py-[70px]">
        <div className="mx-auto flex max-w-content flex-wrap items-center justify-between gap-8 px-7">
          <div>
            <h2 className="text-[clamp(1.5rem,3vw,2.2rem)]">
              {locale === 'ar' ? 'مش لاقي اللي بتدوّر عليه؟' : "Can't find what you need?"}
            </h2>
            <p className="mt-3 max-w-[520px] text-muted">
              {locale === 'ar'
                ? 'كل حاجة بنعملها حسب الطلب. ابعت رسمتك أو مواصفتك والمكتب الفني يرجعلك.'
                : 'Everything we do is made to order. Send a drawing or a spec and the technical office will come back to you.'}
            </p>
          </div>
          <Link
            href={`/${locale}/contact`}
            className="inline-flex items-center gap-[9px] rounded-md bg-amber px-[28px] py-[15px] text-[15px] font-semibold text-[#161310] transition hover:bg-amber-hi"
          >
            {locale === 'ar' ? 'ابعت رسمتك' : 'Send your drawing'}
            <Icon name="arrow" className="h-[15px] w-[15px] flip-x" strokeWidth={2.4} />
          </Link>
        </div>
      </section>
    </div>
  );
}
