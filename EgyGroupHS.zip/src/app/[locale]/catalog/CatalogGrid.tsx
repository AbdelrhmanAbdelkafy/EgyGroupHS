'use client';

import { useState, useEffect } from 'react';
import { useSearchParams } from 'next/navigation';
import Link from 'next/link';
import { Locale } from '@/lib/i18n';
import { masterItems, catalogPage as CP } from '@/content/catalog';
import { Icon } from '@/components/Icon';

export function CatalogGrid({ locale, overrides = {} }: { locale: Locale; overrides?: Record<string, string[]> }) {
  /** an image chosen in the content manager wins over the one in the source file */
  const imageOf = (m: { slug: string; images: string[] }) => (overrides[m.slug]?.[0]) || m.images[0];
  const t = <T extends { ar: string; en: string }>(x: T) => x[locale];
  const params = useSearchParams();
  const [filter, setFilter] = useState<'all' | 'custom' | 'standard'>('all');

  // a link like /catalog?f=custom lands directly on that view
  useEffect(() => {
    const f = params?.get('f');
    if (f === 'custom' || f === 'standard' || f === 'all') setFilter(f);
  }, [params]);
  const shown = masterItems.filter((m) => filter === 'all' || m.family === filter);

  const btn = (k: 'all' | 'custom' | 'standard', label: string, n: number) => (
    <button
      key={k}
      onClick={() => setFilter(k)}
      className={`rounded-md border px-4 py-[9px] text-[14px] font-medium transition ${
        filter === k ? 'border-amber bg-amber text-[#161310] font-semibold' : 'border-line text-muted hover:border-steel-lt hover:text-paper'
      }`}
    >
      {label} <span className="opacity-60">({n})</span>
    </button>
  );

  return (
    <>
      <div className="reveal mb-8 flex flex-wrap gap-2">
        {btn('all', t(CP.filters.all), masterItems.length)}
        {btn('custom', t(CP.filters.custom), masterItems.filter((m) => m.family === 'custom').length)}
        {btn('standard', t(CP.filters.standard), masterItems.filter((m) => m.family === 'standard').length)}
      </div>

      <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-3">
        {shown.map((m) => (
          <Link
            key={m.slug}
            href={`/${locale}/catalog/${m.slug}`}
            className="group overflow-hidden rounded-xl border border-line bg-ink-2 transition hover:-translate-y-[3px] hover:border-steel"
          >
            <div className="relative h-[210px] overflow-hidden bg-[#e9ebee]">
              {/* Cloudinary on-the-fly resize keeps this fast */}
              <img
                src={
                  imageOf(m).includes('res.cloudinary.com')
                    ? imageOf(m).replace('/upload/', '/upload/w_600,h_420,c_fill,q_auto,f_auto/')
                    : imageOf(m)
                }
                alt={t(m.name)}
                loading="lazy"
                className={`h-full w-full transition duration-500 group-hover:scale-[1.04] ${
                  imageOf(m).includes('/assets/') ? 'object-contain p-3' : 'object-cover'
                }`}
              />
              <span className="absolute top-3 rounded-full border border-line bg-ink/85 px-3 py-1 font-mono text-[10px] tracking-wider text-amber ltr:left-3 rtl:right-3">
                {m.family === 'custom' ? (locale === 'ar' ? 'حسب الطلب' : 'MADE TO ORDER') : locale === 'ar' ? 'قياسي' : 'STANDARD'}
              </span>
            </div>
            <div className="p-[22px]">
              <h3 className="text-[1.2rem]">{t(m.name)}</h3>
              <p className="mt-2 text-[0.9rem] leading-[1.55] text-muted">{t(m.tagline)}</p>
              <span className="mt-4 inline-flex items-center gap-2 text-[13.5px] font-semibold text-amber">
                {t(CP.quoteCta)}
                <Icon name="arrow" className="h-[13px] w-[13px] flip-x" strokeWidth={2.5} />
              </span>
            </div>
          </Link>
        ))}
      </div>
    </>
  );
}
