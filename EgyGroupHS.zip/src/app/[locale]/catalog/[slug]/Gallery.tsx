'use client';

import { useState } from 'react';
import { Locale } from '@/lib/i18n';
import { Lightbox } from '@/components/Lightbox';

// ============================================================================
// Product gallery.
//
// The first photo leads; the rest tile beneath it. Any of them opens the viewer
// at that photo, so the slider order matches what was on screen.
//
// The no-copy attributes here (and the transparent film over each tile) block
// right-click, drag-to-desktop and iOS's long-press "Save Image". They stop a
// casual grab. They cannot stop a screenshot or the network tab, and nothing in
// a browser can — the watermark burnt in at upload time is what actually travels
// with the file.
// ============================================================================

import { photoSrc } from '@/lib/photo';

export function Gallery({ images, alt, locale }: { images: string[]; alt: string; locale: Locale }) {
  const [open, setOpen] = useState<number | null>(null);
  const shown = images.slice(0, 4);
  const isAr = locale === 'ar';

  return (
    <>
      <div className="reveal mt-8 grid grid-cols-2 gap-3">
        {shown.map((src, i) => (
          <button
            key={i}
            onClick={() => setOpen(i)}
            aria-label={`${alt} — ${isAr ? 'كبّر الصورة' : 'enlarge'} ${i + 1}`}
            className={`group relative overflow-hidden rounded-xl border border-line transition hover:border-amber ${
              i === 0 ? 'col-span-2' : ''
            }`}
            style={{ aspectRatio: i === 0 ? '16/10' : '4/3' }}
            onContextMenu={(e) => e.preventDefault()}
          >
            <img
              src={photoSrc(src, i === 0 ? 1000 : 500, i === 0 ? 625 : 375)}
              alt={alt}
              loading={i === 0 ? 'eager' : 'lazy'}
              draggable={false}
              className={`h-full w-full ${src.includes('/assets/') ? 'object-contain bg-[#e9ebee] p-4' : 'object-cover'}`}
              style={{ WebkitTouchCallout: 'none', WebkitUserSelect: 'none', userSelect: 'none' }}
            />

            {/* a film over the photo: long-press and right-click land here, not on the img */}
            <span className="absolute inset-0" aria-hidden="true" />

            <span className="pointer-events-none absolute end-2 top-2 grid h-8 w-8 place-items-center rounded-full bg-ink/70 opacity-0 backdrop-blur transition group-hover:opacity-100">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" className="h-[15px] w-[15px] text-paper">
                <path d="M11 4a7 7 0 1 0 0 14 7 7 0 0 0 0-14zM16 16l4.5 4.5M11 8v6M8 11h6" />
              </svg>
            </span>

            {i === 0 && images.length > 1 && (
              <span className="pointer-events-none absolute bottom-2 start-2 rounded bg-ink/70 px-2 py-1 font-mono text-[10px] text-paper backdrop-blur">
                {images.length} {isAr ? 'صور' : 'photos'}
              </span>
            )}
          </button>
        ))}
      </div>

      {open !== null && (
        <Lightbox images={images} index={open} onIndex={setOpen} onClose={() => setOpen(null)} locale={locale} alt={alt} />
      )}
    </>
  );
}
