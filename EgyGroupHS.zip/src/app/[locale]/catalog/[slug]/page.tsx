import type { Metadata } from 'next';
import Link from 'next/link';
import { notFound } from 'next/navigation';
import { Locale, isLocale, locales } from '@/lib/i18n';
import { masterItems, catalogPage as CP } from '@/content/catalog';
import { Icon } from '@/components/Icon';
import { Configurator } from './Configurator';

export function generateStaticParams() {
  return locales.flatMap((locale) => masterItems.map((m) => ({ locale, slug: m.slug })));
}

export async function generateMetadata({ params }: { params: { locale: string; slug: string } }): Promise<Metadata> {
  const locale = (isLocale(params.locale) ? params.locale : 'ar') as Locale;
  const item = masterItems.find((m) => m.slug === params.slug);
  if (!item) return {};
  return {
    title: `${item.name[locale]} — ${locale === 'ar' ? 'المجموعة المصرية (Hard Steel)' : 'Egyptian Group (Hard Steel)'}`,
    description: item.body[locale].slice(0, 155),
    openGraph: { images: [item.images[0]] },
  };
}

export default function ProductPage({ params }: { params: { locale: string; slug: string } }) {
  const locale = (isLocale(params.locale) ? params.locale : 'ar') as Locale;
  const item = masterItems.find((m) => m.slug === params.slug);
  if (!item) notFound();
  const t = <T extends { ar: string; en: string }>(x: T) => x[locale];

  // Product schema for SEO/GEO
  const jsonLd = {
    '@context': 'https://schema.org',
    '@type': 'Product',
    name: t(item.name),
    description: t(item.body),
    image: item.images,
    brand: { '@type': 'Brand', name: locale === 'ar' ? 'المجموعة المصرية (Hard Steel)' : 'Egyptian Group (Hard Steel)' },
    manufacturer: { '@type': 'Organization', name: 'Egyptian Group (Hard Steel)', address: { '@type': 'PostalAddress', addressCountry: 'EG' } },
  };

  return (
    <div className="pt-[74px]">
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }} />

      <section className="py-[70px]">
        <div className="mx-auto max-w-content px-7">
          <Link href={`/${locale}/catalog`} className="mb-7 inline-flex items-center gap-2 text-[13.5px] text-muted transition hover:text-amber">
            <Icon name="arrow" className="h-[13px] w-[13px] rotate-180 flip-x" strokeWidth={2.4} />
            {t(CP.backToCatalog)}
          </Link>

          <div className="grid grid-cols-1 gap-12 lg:grid-cols-[1.1fr_0.9fr]">
            {/* LEFT — imagery + copy */}
            <div>
              <div className="reveal">
                <span className="eyebrow">{t(item.category)}</span>
                <h1 className="mt-4 text-[clamp(1.9rem,3.6vw,2.8rem)]">{t(item.name)}</h1>
                <p className="mt-3 text-[1.15rem] font-semibold text-amber">{t(item.tagline)}</p>
                <p className="mt-5 text-[1.02rem] leading-[1.75] text-muted">{t(item.body)}</p>
              </div>

              {/* real factory photos */}
              <div className="reveal mt-8 grid grid-cols-2 gap-3">
                {item.images.slice(0, 4).map((src, i) => (
                  <div
                    key={i}
                    className={`overflow-hidden rounded-xl border border-line ${i === 0 ? 'col-span-2' : ''}`}
                    style={{ aspectRatio: i === 0 ? '16/10' : '4/3' }}
                  >
                    <img
                      src={
                        src.includes('res.cloudinary.com')
                          ? src.replace('/upload/', `/upload/w_${i === 0 ? 1000 : 500},h_${i === 0 ? 625 : 375},c_fill,q_auto,f_auto/`)
                          : src
                      }
                      alt={t(item.name)}
                      loading={i === 0 ? 'eager' : 'lazy'}
                      className="h-full w-full object-cover"
                    />
                  </div>
                ))}
              </div>

              {/* facts */}
              {item.facts && (
                <div className="reveal mt-8 rounded-xl border border-line bg-ink-2 p-6">
                  <h3 className="mb-4 font-mono text-[11px] uppercase tracking-[0.16em] text-steel-lt">{t(CP.factsTitle)}</h3>
                  <div className="flex flex-col gap-3">
                    {item.facts.map((f, i) => (
                      <div key={i} className="flex items-start gap-3 text-[0.95rem]">
                        <Icon name="tick" className="mt-[3px] h-4 w-4 shrink-0 text-amber flip-x" strokeWidth={2.4} />
                        <span>{t(f)}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>

            {/* RIGHT — configurator */}
            <div className="reveal lg:sticky lg:top-[100px] lg:self-start">
              <Configurator item={item} locale={locale} />
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
