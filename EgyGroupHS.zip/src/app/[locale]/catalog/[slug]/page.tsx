import type { Metadata } from 'next';
import Link from 'next/link';
import { notFound } from 'next/navigation';
import { Locale, isLocale, locales } from '@/lib/i18n';
import { masterItems, catalogPage as CP } from '@/content/catalog';
import { imagesFor } from '@/lib/overrides';
import { Icon } from '@/components/Icon';
import { Configurator } from './Configurator';
import { Gallery } from './Gallery';

export function generateStaticParams() {
  return locales.flatMap((locale) => masterItems.map((m) => ({ locale, slug: m.slug })));
}

export async function generateMetadata({ params }: { params: { locale: string; slug: string } }): Promise<Metadata> {
  const locale = (isLocale(params.locale) ? params.locale : 'ar') as Locale;
  const item = masterItems.find((m) => m.slug === params.slug);
  if (!item) return {};
  const isAr = locale === 'ar';
  const brand = isAr ? 'المجموعة المصرية (Hard Steel)' : 'Egyptian Group (Hard Steel)';

  // Hand-written SEO wins; otherwise fall back to the product copy.
  const title = item.seo?.title[locale] ?? `${item.name[locale]} — ${brand}`;
  const description = item.seo?.desc[locale] ?? item.body[locale].slice(0, 155);

  return {
    title,
    description,
    keywords: item.seo?.terms,
    alternates: {
      canonical: `/${locale}/catalog/${item.slug}`,
      languages: { ar: `/ar/catalog/${item.slug}`, en: `/en/catalog/${item.slug}` },
    },
    openGraph: {
      title,
      description,
      type: 'website',
      locale: isAr ? 'ar_EG' : 'en_US',
      images: [imagesFor(item.slug, item.images)[0]],
    },
    twitter: { card: 'summary_large_image', title, description, images: [imagesFor(item.slug, item.images)[0]] },
  };
}

export default function ProductPage({ params }: { params: { locale: string; slug: string } }) {
  const locale = (isLocale(params.locale) ? params.locale : 'ar') as Locale;
  const item = masterItems.find((m) => m.slug === params.slug);
  if (!item) notFound();
  const t = <T extends { ar: string; en: string }>(x: T) => x[locale];

  const isAr = locale === 'ar';
  const brand = isAr ? 'المجموعة المصرية (Hard Steel)' : 'Egyptian Group (Hard Steel)';

  // Structured data. Two things matter here: tell search engines this is a
  // product made by a named manufacturer in Egypt, and give the breadcrumb so
  // the result shows a path instead of a bare URL.
  const jsonLd = {
    '@context': 'https://schema.org',
    '@graph': [
      {
        '@type': 'Product',
        '@id': `https://egygrouphs.com/${locale}/catalog/${item.slug}#product`,
        name: t(item.name),
        alternateName: item.seo?.terms?.slice(0, 6),
        description: item.seo?.desc[locale] ?? t(item.body),
        image: imagesFor(item.slug, item.images),
        category: t(item.category),
        brand: { '@type': 'Brand', name: brand },
        manufacturer: {
          '@type': 'Organization',
          name: brand,
          address: { '@type': 'PostalAddress', addressCountry: 'EG', addressRegion: isAr ? 'القاهرة الكبرى' : 'Greater Cairo' },
        },
        offers: {
          '@type': 'Offer',
          availability: 'https://schema.org/InStock',
          priceCurrency: 'EGP',
          // Priced after a site survey — declared rather than faked with a number.
          priceSpecification: { '@type': 'PriceSpecification', valueAddedTaxIncluded: false },
          url: `https://egygrouphs.com/${locale}/catalog/${item.slug}`,
          seller: { '@type': 'Organization', name: brand },
        },
        areaServed: { '@type': 'Country', name: 'Egypt' },
      },
      {
        '@type': 'BreadcrumbList',
        itemListElement: [
          { '@type': 'ListItem', position: 1, name: isAr ? 'الرئيسية' : 'Home', item: `https://egygrouphs.com/${locale}` },
          { '@type': 'ListItem', position: 2, name: isAr ? 'الكتالوج' : 'Catalogue', item: `https://egygrouphs.com/${locale}/catalog` },
          { '@type': 'ListItem', position: 3, name: t(item.name) },
        ],
      },
    ],
  };

  return (
    <div className="pt-[74px]">
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }} />

      <section className="py-[70px]">
        <div className="mx-auto max-w-content px-7">
          <Link href={`/${locale}/catalog`} className="mb-7 inline-flex items-center gap-2 text-[13.5px] text-muted transition hover:text-amber">
            <Icon name="arrow" className="h-[13px] w-[13px] rotate-180 flip-x" strokeWidth={2.4} />
            {t(CP.backToCatalog)}
          </Link>

          <div className="grid grid-cols-1 gap-12 lg:grid-cols-[1.1fr_0.9fr]">
            {/* LEFT — imagery + copy */}
            <div>
              <div className="reveal">
                <span className="eyebrow">{t(item.category)}</span>
                <h1 className="mt-4 text-[clamp(1.9rem,3.6vw,2.8rem)]">{t(item.name)}</h1>
                <p className="mt-3 text-[1.15rem] font-semibold text-amber">{t(item.tagline)}</p>
                <p className="mt-5 text-[1.02rem] leading-[1.75] text-muted">{t(item.body)}</p>
              </div>

              {/* real factory photos — click to zoom */}
              <Gallery images={imagesFor(item.slug, item.images)} alt={t(item.name)} locale={locale} />

              {/* facts */}
              {item.facts && (
                <div className="reveal mt-8 rounded-xl border border-line bg-ink-2 p-6">
                  <h3 className="mb-4 font-mono text-[11px] uppercase tracking-[0.16em] text-steel-lt">{t(CP.factsTitle)}</h3>
                  <div className="flex flex-col gap-3">
                    {item.facts.map((f, i) => (
                      <div key={i} className="flex items-start gap-3 text-[0.95rem]">
                        <Icon name="tick" className="mt-[3px] h-4 w-4 shrink-0 text-amber flip-x" strokeWidth={2.4} />
                        <span>{t(f)}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>

            {/* RIGHT — configurator */}
            <div className="reveal lg:sticky lg:top-[100px] lg:self-start">
              <Configurator item={item} locale={locale} image={imagesFor(item.slug, item.images)[0]} />
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
