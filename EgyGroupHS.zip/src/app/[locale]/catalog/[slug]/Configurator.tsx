'use client';

import { useState } from 'react';
import Link from 'next/link';
import { Locale } from '@/lib/i18n';
import { MasterItem, catalogPage as CP } from '@/content/catalog';
import { Icon } from '@/components/Icon';
import { useCart } from '@/lib/cart';

/**
 * Two different products, two different journeys:
 *
 *  standard  → pick the spec, put it in the cart, ask for a price.
 *              These are stock or catalogue items; nobody needs to drive out.
 *
 *  custom    → no cart. A tank or a process line cannot be priced from a form,
 *              so the honest next step is an engineer on site with a tape.
 *              The chosen spec is carried over to the visit request.
 */
export function Configurator({ item, locale, image }: { item: MasterItem; locale: Locale; image?: string }) {
  const t = <T extends { ar: string; en: string }>(x: T) => x[locale];
  const isAr = locale === 'ar';
  const { add, count } = useCart();

  const [sel, setSel] = useState<Record<string, string>>({});
  const [qty, setQty] = useState(1);
  const [added, setAdded] = useState(false);

  const isStock = item.family === 'standard';

  const set = (k: string, v: string) => {
    setSel((s) => ({ ...s, [k]: v }));
    setAdded(false);
  };

  const specs = item.options.filter((o) => sel[o.key]).map((o) => ({ label: t(o.label), value: sel[o.key] }));

  const addToCart = () => {
    add({ slug: item.slug, name: t(item.name), image: image || item.images[0], specs }, qty);
    setAdded(true);
  };

  // carry the spec into the visit request so the customer doesn't retype it
  const visitHref = () => {
    const brief = [t(item.name), ...specs.map((s) => `${s.label}: ${s.value}`)].join(' — ');
    return `/${locale}/site-visit?subject=${encodeURIComponent(brief)}`;
  };

  const field = 'w-full rounded-md border border-line bg-ink px-4 py-3 text-[0.95rem] text-paper outline-none transition focus:border-amber';

  return (
    <div className="rounded-2xl border border-line bg-ink-2 p-[30px]">
      <h2 className="text-[1.25rem]">{t(CP.optionsTitle)}</h2>
      <p className="mt-2 text-[0.85rem] leading-[1.6] text-muted">
        {isStock
          ? isAr ? 'حدّد المواصفة والكمية، وضيفها لسلتك.' : 'Pick the specification and quantity, then add it to your cart.'
          : isAr ? 'حدّد اللي تعرفه — والباقي المهندس يشوفه على الطبيعة.' : 'Specify what you know — the engineer sees the rest on site.'}
      </p>

      <div className="mt-6 flex flex-col gap-6">
        {item.options.map((o) => (
          <div key={o.key}>
            <label className="mb-2 block font-mono text-[11px] uppercase tracking-[0.14em] text-steel-lt">{t(o.label)}</label>
            {o.kind === 'choice' ? (
              <div className="flex flex-wrap gap-2">
                {o.values!.map((v, i) => {
                  const val = t(v);
                  const on = sel[o.key] === val;
                  return (
                    <button
                      key={i}
                      onClick={() => set(o.key, val)}
                      className={`rounded-md border px-[14px] py-[9px] text-[13.5px] transition ${
                        on ? 'border-amber bg-amber/15 font-semibold text-amber' : 'border-line text-muted hover:border-steel-lt hover:text-paper'
                      }`}
                    >
                      {val}
                    </button>
                  );
                })}
              </div>
            ) : (
              <input
                className={field}
                placeholder={o.hint ? t(o.hint) : ''}
                value={sel[o.key] || ''}
                onChange={(e) => set(o.key, e.target.value)}
              />
            )}
          </div>
        ))}
      </div>

      {specs.length > 0 && (
        <div className="mt-7 rounded-lg border border-amber/25 bg-amber/[0.06] p-4">
          <div className="mb-2 font-mono text-[11px] uppercase tracking-[0.14em] text-amber">
            {isAr ? 'مواصفاتك' : 'Your specification'}
          </div>
          <ul className="flex flex-col gap-1">
            {specs.map((s, i) => (
              <li key={i} className="text-[0.9rem] text-paper">• {s.label}: {s.value}</li>
            ))}
          </ul>
        </div>
      )}

      {isStock ? (
        <>
          <div className="mt-6 flex items-center gap-4">
            <span className="font-mono text-[11px] uppercase tracking-[0.14em] text-steel-lt">{isAr ? 'الكمية' : 'Qty'}</span>
            <div className="inline-flex items-center gap-1 rounded-md border border-line">
              <button onClick={() => setQty((q) => Math.max(1, q - 1))} className="px-3 py-2 text-muted transition hover:text-amber">−</button>
              <span className="min-w-[38px] text-center font-mono text-[14px]">{qty}</span>
              <button onClick={() => setQty((q) => q + 1)} className="px-3 py-2 text-muted transition hover:text-amber">+</button>
            </div>
          </div>

          <button
            onClick={addToCart}
            className="mt-5 inline-flex w-full items-center justify-center gap-[9px] rounded-md bg-amber px-7 py-[15px] text-[15px] font-semibold text-[#161310] transition hover:bg-amber-hi"
          >
            <Icon name="check" className="h-[15px] w-[15px]" strokeWidth={2.6} />
            {isAr ? 'ضيف للسلة' : 'Add to cart'}
          </button>

          {added && (
            <div className="mt-4 rounded-lg border border-amber/30 bg-amber/[0.08] p-4 text-center">
              <p className="text-[0.9rem] font-semibold text-amber">{isAr ? 'اتضاف ✓' : 'Added ✓'}</p>
              <p className="mt-1 text-[0.82rem] text-muted">
                {isAr ? `عندك ${count} صنف في السلة.` : `${count} item${count === 1 ? '' : 's'} in your cart.`}
              </p>
              <div className="mt-3 flex flex-wrap justify-center gap-2">
                <Link href={`/${locale}/cart`} className="rounded-md bg-amber px-5 py-[10px] text-[13.5px] font-semibold text-[#161310] transition hover:bg-amber-hi">
                  {isAr ? 'شوف السلة' : 'View cart'}
                </Link>
                <Link href={`/${locale}/catalog`} className="rounded-md border border-line px-5 py-[10px] text-[13.5px] text-muted transition hover:border-steel-lt hover:text-paper">
                  {isAr ? 'ضيف صنف تاني' : 'Add another item'}
                </Link>
              </div>
            </div>
          )}

          <p className="mt-4 text-center text-[0.82rem] text-muted">
            {isAr ? 'المبيعات بترجعلك بالسعر والتوفّر.' : 'Sales come back with price and availability.'}
          </p>
        </>
      ) : (
        <>
          <Link
            href={visitHref()}
            className="mt-6 inline-flex w-full items-center justify-center gap-[9px] rounded-md bg-amber px-7 py-[15px] text-[15px] font-semibold text-[#161310] transition hover:bg-amber-hi"
          >
            {isAr ? 'اطلب معاينة' : 'Request a site visit'}
            <Icon name="arrow" className="h-[15px] w-[15px] flip-x" strokeWidth={2.4} />
          </Link>
          <p className="mt-4 text-center text-[0.82rem] leading-[1.6] text-muted">
            {isAr
              ? 'ده شغل بيتصنّع على المقاس — مهندس يجي يرفع المقاس ويشوف الموقع، وبعدها نقدّم عرض السعر.'
              : 'This is made to measure — an engineer comes out, takes the measurements and sees the site, then we price it.'}
          </p>
        </>
      )}
    </div>
  );
}
