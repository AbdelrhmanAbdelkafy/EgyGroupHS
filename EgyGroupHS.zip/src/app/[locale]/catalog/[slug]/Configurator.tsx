'use client';

import { useState } from 'react';
import { Locale } from '@/lib/i18n';
import { MasterItem, catalogPage as CP } from '@/content/catalog';
import { Icon } from '@/components/Icon';

/**
 * Options configurator → builds a spec summary → sends it as a quote request.
 * Delivery: email now (mailto with the full spec), CRM (VTiger) wiring next phase.
 */
export function Configurator({ item, locale }: { item: MasterItem; locale: Locale }) {
  const t = <T extends { ar: string; en: string }>(x: T) => x[locale];
  const isAr = locale === 'ar';
  const [sel, setSel] = useState<Record<string, string>>({});
  const [contact, setContact] = useState({ name: '', company: '', email: '', phone: '' });
  const [sent, setSent] = useState(false);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState('');

  const set = (k: string, v: string) => setSel((s) => ({ ...s, [k]: v }));

  const specLines = item.options
    .filter((o) => sel[o.key])
    .map((o) => `${t(o.label)}: ${sel[o.key]}`);

  const buildBody = () => {
    const L: string[] = [];
    L.push(isAr ? `طلب عرض سعر — ${t(item.name)}` : `Quote request — ${t(item.name)}`);
    L.push('');
    L.push(isAr ? '— المواصفات المطلوبة —' : '— Requested specification —');
    specLines.forEach((l) => L.push('• ' + l));
    L.push('');
    L.push(isAr ? '— بيانات التواصل —' : '— Contact —');
    L.push(`${isAr ? 'الاسم' : 'Name'}: ${contact.name}`);
    L.push(`${isAr ? 'الشركة' : 'Company'}: ${contact.company}`);
    L.push(`${isAr ? 'البريد' : 'Email'}: ${contact.email}`);
    L.push(`${isAr ? 'التليفون' : 'Phone'}: ${contact.phone}`);
    return L.join('\n');
  };

  const mailFallback = () => {
    const subject = encodeURIComponent(`${isAr ? 'طلب عرض سعر' : 'Quote request'} — ${t(item.name)}`);
    const body = encodeURIComponent(buildBody());
    window.location.href = `mailto:?subject=${subject}&body=${body}`;
  };

  const submit = async () => {
    setErr('');
    if (!contact.name.trim() || !contact.phone.trim()) {
      setErr(isAr ? 'محتاجين الاسم والتليفون على الأقل.' : 'Name and phone are required.');
      return;
    }
    setBusy(true);
    try {
      const res = await fetch('/api/quote', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          product: t(item.name),
          specs: item.options.filter((o) => sel[o.key]).map((o) => ({ label: t(o.label), value: sel[o.key] })),
          name: contact.name,
          company: contact.company,
          email: contact.email,
          phone: contact.phone,
          locale,
        }),
      });
      const out = await res.json().catch(() => ({}));
      if (res.ok && out.ok) {
        setSent(true);
      } else {
        // CRM unavailable → don't lose the request: hand it to email.
        mailFallback();
        setSent(true);
      }
    } catch {
      mailFallback();
      setSent(true);
    } finally {
      setBusy(false);
    }
  };

  const field =
    'w-full rounded-md border border-line bg-ink px-4 py-3 text-[0.95rem] text-paper outline-none transition focus:border-amber';

  return (
    <div className="rounded-2xl border border-line bg-ink-2 p-[30px]">
      <h2 className="text-[1.25rem]">{t(CP.optionsTitle)}</h2>

      <div className="mt-6 flex flex-col gap-6">
        {item.options.map((o) => (
          <div key={o.key}>
            <label className="mb-2 block font-mono text-[11px] uppercase tracking-[0.14em] text-steel-lt">{t(o.label)}</label>
            {o.kind === 'choice' ? (
              <div className="flex flex-wrap gap-2">
                {o.values!.map((v, i) => {
                  const val = t(v);
                  const on = sel[o.key] === val;
                  return (
                    <button
                      key={i}
                      onClick={() => set(o.key, val)}
                      className={`rounded-md border px-[14px] py-[9px] text-[13.5px] transition ${
                        on ? 'border-amber bg-amber/15 font-semibold text-amber' : 'border-line text-muted hover:border-steel-lt hover:text-paper'
                      }`}
                    >
                      {val}
                    </button>
                  );
                })}
              </div>
            ) : (
              <input
                className={field}
                placeholder={o.hint ? t(o.hint) : ''}
                value={sel[o.key] || ''}
                onChange={(e) => set(o.key, e.target.value)}
              />
            )}
          </div>
        ))}
      </div>

      {/* live spec summary */}
      {specLines.length > 0 && (
        <div className="mt-7 rounded-lg border border-amber/25 bg-amber/[0.06] p-4">
          <div className="mb-2 font-mono text-[11px] uppercase tracking-[0.14em] text-amber">
            {isAr ? 'مواصفاتك' : 'Your specification'}
          </div>
          <ul className="flex flex-col gap-1">
            {specLines.map((l, i) => (
              <li key={i} className="text-[0.9rem] text-paper">
                • {l}
              </li>
            ))}
          </ul>
        </div>
      )}

      {/* contact */}
      <div className="mt-7 border-t border-line pt-6">
        <h3 className="mb-4 text-[1.05rem]">{isAr ? 'بياناتك' : 'Your details'}</h3>
        <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
          <input className={field} placeholder={isAr ? 'الاسم' : 'Name'} value={contact.name} onChange={(e) => setContact({ ...contact, name: e.target.value })} />
          <input className={field} placeholder={isAr ? 'الشركة' : 'Company'} value={contact.company} onChange={(e) => setContact({ ...contact, company: e.target.value })} />
          <input className={field} type="email" placeholder={isAr ? 'البريد الإلكتروني' : 'Email'} value={contact.email} onChange={(e) => setContact({ ...contact, email: e.target.value })} />
          <input className={field} placeholder={isAr ? 'التليفون' : 'Phone'} value={contact.phone} onChange={(e) => setContact({ ...contact, phone: e.target.value })} />
        </div>
      </div>

      <button
        onClick={submit}
        disabled={busy}
        className="mt-6 inline-flex w-full items-center justify-center gap-[9px] rounded-md bg-amber px-7 py-[15px] text-[15px] font-semibold text-[#161310] transition hover:bg-amber-hi disabled:opacity-60"
      >
        {busy ? (isAr ? 'جارٍ الإرسال…' : 'Sending…') : t(CP.sendTitle)}
        {!busy && <Icon name="arrow" className="h-[15px] w-[15px] flip-x" strokeWidth={2.4} />}
      </button>
      {err && <p className="mt-3 text-center text-[0.85rem] text-amber">{err}</p>}

      {sent && (
        <p className="mt-4 text-center text-[0.9rem] text-amber">
          {isAr ? 'وصلنا طلبك واتسجّل — المكتب الفني هيرجعلك.' : 'Your request reached us and is logged — the technical office will reply.'}
        </p>
      )}

      <p className="mt-4 text-center text-[0.82rem] text-muted">
        {isAr ? 'المكتب الفني يراجع المواصفة ويرجعلك بنطاق وسعر.' : 'The technical office reviews the spec and returns a scope and price.'}
      </p>
    </div>
  );
}
