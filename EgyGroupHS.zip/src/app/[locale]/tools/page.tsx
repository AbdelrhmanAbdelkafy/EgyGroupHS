import type { Metadata } from 'next';
import { Locale, isLocale, locales } from '@/lib/i18n';
import { notFound } from 'next/navigation';
import { WeightTool } from './WeightTool';

export function generateStaticParams() {
  return locales.map((locale) => ({ locale }));
}

export function generateMetadata({ params }: { params: { locale: string } }): Metadata {
  const ar = params.locale === 'ar';
  const title = ar ? 'حاسبة أوزان الاستانلس والجداول القياسية' : 'Stainless weight calculator & standard tables';
  const description = ar
    ? 'احسب وزن اللوح والماسورة والبار والقطاعات المجوفة والزوايا — باختيار الخامة والكثافة، مش بافتراضها. مع جداول ASME B36.19M والمواسير الصحية وسماحات السمك.'
    : 'Calculate the weight of sheet, pipe, bar, hollow section and angle — choosing the grade and density rather than assuming one. With ASME B36.19M, hygienic tube and thickness tolerance tables.';
  return {
    title,
    description,
    keywords: ar
      ? ['حاسبة وزن الاستانلس', 'وزن ماسورة استانلس', 'جدول مواسير', 'كثافة 304', 'كثافة 316', 'حاسبة أوزان المعادن', 'ASME B36.19M']
      : ['stainless weight calculator', 'pipe weight chart', '304 density', 'ASME B36.19M', 'steel weight calculator Egypt'],
    alternates: {
      canonical: `/${params.locale}/tools`,
      languages: { ar: '/ar/tools', en: '/en/tools' },
    },
    openGraph: { title, description, type: 'website' },
  };
}

export default function ToolsPage({ params }: { params: { locale: string } }) {
  if (!isLocale(params.locale)) notFound();
  const locale = params.locale as Locale;
  const ar = locale === 'ar';

  return (
    <main className="pt-[74px]">
      <section className="border-b border-line px-7 py-14">
        <div className="mx-auto max-w-content">
          <span className="font-mono text-[11px] uppercase tracking-[0.2em] text-amber">
            {ar ? '—— أدوات' : '—— Tools'}
          </span>
          <h1 className="mt-3 max-w-[19ch] text-[clamp(2rem,5vw,3.2rem)] font-extrabold leading-[1.08]">
            {ar ? (
              <>
                الوزن اللي <span className="text-amber">تحاسبنا عليه</span>.
              </>
            ) : (
              <>
                The weight you <span className="text-amber">get invoiced for</span>.
              </>
            )}
          </h1>
          <p className="mt-4 max-w-[62ch] text-[1rem] leading-relaxed text-muted">
            {ar
              ? 'حاسبة أوزان بتقفل الكثافة من الخامة اللي تختارها — أو من شهادة الخامة اللي معاك. والمعادلة مكتوبة قدامك، عشان أي حد بيشتري حديد بيراجع الحساب بنفسه.'
              : 'A calculator that takes its density from the grade you choose — or from the mill certificate in your hand. The working is shown, because anyone buying steel checks the arithmetic themselves.'}
          </p>
        </div>
      </section>

      <section className="px-7 py-10">
        <div className="mx-auto max-w-content">
          <WeightTool locale={locale} />
        </div>
      </section>
    </main>
  );
}
