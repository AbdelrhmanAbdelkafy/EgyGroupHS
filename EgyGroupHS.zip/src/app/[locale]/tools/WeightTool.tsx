'use client';

import { useMemo, useState } from 'react';
import Link from 'next/link';
import { Locale } from '@/lib/i18n';
import { Icon } from '@/components/Icon';
import {
  GRADES, SECTIONS, calculate,
  PIPE_SCHEDULE, SANITARY_TUBE, SHEET_STOCK, THICKNESS_TOLERANCE,
} from '@/lib/weight';

// ============================================================================
// The calculator, and the tables it draws on.
//
// The density selector is the point of the whole page, so it sits in its own
// panel rather than hiding among the dimensions. Choosing "custom" is a first
// class option: a mill certificate beats a textbook figure, and the person
// holding the certificate should be able to type what it says.
// ============================================================================

const T = {
  tabCalc: { ar: 'حاسبة الأوزان', en: 'Weight calculator' },
  tabSpec: { ar: 'الجداول القياسية', en: 'Standard tables' },
  section: { ar: 'القطاع', en: 'Section' },
  dims: { ar: 'المقاسات', en: 'Dimensions' },
  length: { ar: 'الطول', en: 'Length' },
  qty: { ar: 'العدد', en: 'Quantity' },
  material: { ar: 'الخامة والكثافة', en: 'Material & density' },
  grade: { ar: 'الخامة', en: 'Grade' },
  custom: { ar: 'كثافة مخصّصة', en: 'Custom density' },
  density: { ar: 'الكثافة', en: 'Density' },
  perPiece: { ar: 'وزن القطعة', en: 'Per piece' },
  perMetre: { ar: 'كجم / متر', en: 'kg / metre' },
  total: { ar: 'الإجمالي', en: 'Total' },
  area: { ar: 'مساحة المقطع', en: 'Cross-section' },
  formula: { ar: 'المعادلة', en: 'Formula' },
  quote: { ar: 'اطلب عرض سعر بالمواصفات دي', en: 'Request a quote for this spec' },
};

export function WeightTool({ locale }: { locale: Locale }) {
  const isAr = locale === 'ar';
  const t = <K extends keyof typeof T>(k: K) => T[k][locale];

  const [tab, setTab] = useState<'calc' | 'spec'>('calc');
  const [sectionId, setSectionId] = useState(SECTIONS[0].id);
  const section = SECTIONS.find((s) => s.id === sectionId)!;

  const [dims, setDims] = useState<Record<string, number>>(() =>
    Object.fromEntries(SECTIONS[0].fields.map((f) => [f.key, f.def ?? 0]))
  );
  const [length, setLength] = useState(2500);
  const [qty, setQty] = useState(1);

  const [gradeId, setGradeId] = useState('304');
  const [useCustom, setUseCustom] = useState(false);
  const [customRho, setCustomRho] = useState(8.0);

  const grade = GRADES.find((g) => g.id === gradeId)!;
  const density = useCustom ? customRho : grade.density;

  const pick = (id: string) => {
    const s = SECTIONS.find((x) => x.id === id)!;
    setSectionId(id);
    setDims(Object.fromEntries(s.fields.map((f) => [f.key, f.def ?? 0])));
  };

  const r = useMemo(() => calculate(section, dims, length, density, qty), [section, dims, length, density, qty]);

  const num = (n: number, d = 2) =>
    n.toLocaleString(isAr ? 'ar-EG' : 'en-GB', { minimumFractionDigits: d, maximumFractionDigits: d });

  const specText = useMemo(() => {
    const d = section.fields.map((f) => `${f.label[locale]} ${dims[f.key]}`).join(' × ');
    return `${section.name[locale]} — ${d} — ${isAr ? 'طول' : 'L'} ${length}mm — ${grade.name[locale]}${
      useCustom ? ` (ρ ${customRho})` : ''
    } — ${isAr ? 'عدد' : 'Qty'} ${qty} — ${num(r.total)} kg`;
  }, [section, dims, length, grade, useCustom, customRho, qty, r.total, locale, isAr]);

  const field =
    'w-full rounded-md border border-line bg-ink px-3 py-2.5 text-[0.95rem] text-paper outline-none transition focus:border-amber';
  const label = 'mb-1.5 block text-[0.8rem] text-muted';

  return (
    <div>
      {/* tabs */}
      <div className="mb-7 flex gap-2">
        {(['calc', 'spec'] as const).map((k) => (
          <button
            key={k}
            onClick={() => setTab(k)}
            className={`rounded-md border px-5 py-2.5 text-[0.9rem] transition ${
              tab === k
                ? 'border-amber bg-amber font-semibold text-[#161310]'
                : 'border-line text-muted hover:border-steel-lt hover:text-paper'
            }`}
          >
            {k === 'calc' ? t('tabCalc') : t('tabSpec')}
          </button>
        ))}
      </div>

      {tab === 'calc' ? (
        <div className="grid grid-cols-1 gap-5 lg:grid-cols-[1fr_360px]">
          <div className="flex flex-col gap-5">
            {/* section */}
            <section className="rounded-xl border border-line bg-ink-2 p-5">
              <h2 className="mb-3 text-[0.95rem] font-semibold">{t('section')}</h2>
              <div className="flex flex-wrap gap-2">
                {SECTIONS.map((s) => (
                  <button
                    key={s.id}
                    onClick={() => pick(s.id)}
                    className={`rounded-md border px-3.5 py-2 text-[0.85rem] transition ${
                      s.id === sectionId
                        ? 'border-amber bg-amber/12 font-semibold text-amber'
                        : 'border-line text-muted hover:border-steel-lt hover:text-paper'
                    }`}
                  >
                    {s.name[locale]}
                  </button>
                ))}
              </div>
            </section>

            {/* dimensions */}
            <section className="rounded-xl border border-line bg-ink-2 p-5">
              <h2 className="mb-3 text-[0.95rem] font-semibold">{t('dims')}</h2>
              <div className="grid grid-cols-2 gap-4 sm:grid-cols-3">
                {section.fields.map((f) => (
                  <div key={f.key}>
                    <label className={label}>
                      {f.label[locale]} <span className="font-mono text-[10px] text-steel-lt">{f.unit}</span>
                    </label>
                    <input
                      type="number"
                      inputMode="decimal"
                      min={0}
                      step="any"
                      value={dims[f.key] ?? ''}
                      onChange={(e) => setDims((d) => ({ ...d, [f.key]: Number(e.target.value) || 0 }))}
                      className={field}
                    />
                  </div>
                ))}
                <div>
                  <label className={label}>
                    {t('length')} <span className="font-mono text-[10px] text-steel-lt">مم</span>
                  </label>
                  <input
                    type="number"
                    inputMode="decimal"
                    min={0}
                    step="any"
                    value={length}
                    onChange={(e) => setLength(Number(e.target.value) || 0)}
                    className={field}
                  />
                </div>
                <div>
                  <label className={label}>{t('qty')}</label>
                  <input
                    type="number"
                    inputMode="numeric"
                    min={1}
                    value={qty}
                    onChange={(e) => setQty(Math.max(1, Number(e.target.value) || 1))}
                    className={field}
                  />
                </div>
              </div>
            </section>

            {/* density — the reason this page exists */}
            <section className="rounded-xl border border-amber/30 bg-amber/[0.04] p-5">
              <h2 className="mb-1 text-[0.95rem] font-semibold text-amber">{t('material')}</h2>
              <p className="mb-4 text-[0.78rem] text-muted">
                {isAr
                  ? 'الكثافة بتتقفل من الخامة — مش مفترضة. الفرق بين 304 و430 حوالي 4% في الوزن.'
                  : 'Density follows the grade — it is not assumed. 304 to 430 is about 4% of the weight.'}
              </p>

              <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                <div>
                  <label className={label}>{t('grade')}</label>
                  <select
                    value={gradeId}
                    onChange={(e) => {
                      setGradeId(e.target.value);
                      setUseCustom(false);
                    }}
                    disabled={useCustom}
                    className={`${field} disabled:opacity-40`}
                  >
                    {GRADES.map((g) => (
                      <option key={g.id} value={g.id}>
                        {g.name[locale]} — {g.density.toFixed(2)}
                      </option>
                    ))}
                  </select>
                  {grade.note && !useCustom && (
                    <p className="mt-1.5 text-[0.75rem] text-steel-lt">{grade.note[locale]}</p>
                  )}
                </div>

                <div>
                  <label className="mb-1.5 flex cursor-pointer items-center gap-2 text-[0.8rem] text-muted">
                    <input
                      type="checkbox"
                      checked={useCustom}
                      onChange={(e) => setUseCustom(e.target.checked)}
                      className="accent-amber"
                    />
                    {t('custom')}
                  </label>
                  <div className="relative">
                    <input
                      type="number"
                      inputMode="decimal"
                      min={0.1}
                      step="0.01"
                      value={customRho}
                      onChange={(e) => setCustomRho(Number(e.target.value) || 0)}
                      disabled={!useCustom}
                      className={`${field} disabled:opacity-40`}
                    />
                    <span className="pointer-events-none absolute end-3 top-1/2 -translate-y-1/2 font-mono text-[10px] text-steel-lt">
                      جم/سم³
                    </span>
                  </div>
                  <p className="mt-1.5 text-[0.75rem] text-steel-lt">
                    {isAr ? 'من شهادة الخامة لو متاحة' : 'From the mill certificate if you have it'}
                  </p>
                </div>
              </div>
            </section>
          </div>

          {/* result */}
          <aside className="lg:sticky lg:top-[90px] lg:self-start">
            <div className="rounded-xl border border-line bg-ink-2 p-5">
              <div className="mb-4 border-b border-line pb-4">
                <span className="block text-[0.78rem] text-muted">{t('total')}</span>
                <span className="mt-1 block text-[2.4rem] font-extrabold leading-none text-amber">
                  {num(r.total)}
                  <span className="ms-2 text-[1rem] font-medium text-muted">kg</span>
                </span>
                {qty > 1 && (
                  <span className="mt-1.5 block font-mono text-[0.75rem] text-steel-lt">
                    {num(r.perPiece)} × {qty}
                  </span>
                )}
              </div>

              <dl className="flex flex-col gap-2.5 text-[0.85rem]">
                {[
                  [t('perPiece'), `${num(r.perPiece)} kg`],
                  [t('perMetre'), num(r.perMetre, 3)],
                  [t('area'), `${num(r.areaMm2, 1)} mm²`],
                  [t('density'), `${density.toFixed(2)} g/cm³`],
                ].map(([k, v]) => (
                  <div key={k} className="flex items-baseline justify-between gap-3">
                    <dt className="text-muted">{k}</dt>
                    <dd className="font-mono text-paper">{v}</dd>
                  </div>
                ))}
              </dl>

              <div className="mt-4 rounded-lg border border-line bg-ink p-3">
                <span className="mb-1 block font-mono text-[9.5px] uppercase tracking-[0.14em] text-steel-lt">
                  {t('formula')}
                </span>
                <p className="text-[0.8rem] leading-relaxed text-muted">{section.formula[locale]}</p>
              </div>

              <p className="mt-3 text-[0.72rem] leading-relaxed text-steel-lt">
                {isAr
                  ? 'وزن نظري بمقاسات اسمية. الوزن الفعلي بيختلف بسماح سمك اللوح — شوف جدول السماحات.'
                  : 'Theoretical, on nominal dimensions. Delivered weight moves with the thickness tolerance — see the table.'}
              </p>

              <Link
                href={`/${locale}/site-visit?subject=${encodeURIComponent(specText)}`}
                className="mt-4 flex w-full items-center justify-center gap-2 rounded-md bg-amber px-4 py-3 text-[14px] font-semibold text-[#161310] transition hover:bg-amber-hi"
              >
                {t('quote')}
                <Icon name="arrow" className="h-[14px] w-[14px] flip-x" strokeWidth={2.4} />
              </Link>
            </div>
          </aside>
        </div>
      ) : (
        <SpecTables locale={locale} />
      )}
    </div>
  );
}

function SpecTables({ locale }: { locale: Locale }) {
  const isAr = locale === 'ar';
  const card = 'rounded-xl border border-line bg-ink-2 p-5';
  const h = 'mb-1 text-[1rem] font-semibold';
  const sub = 'mb-4 text-[0.78rem] text-muted';

  return (
    <div className="flex flex-col gap-5">
      <section className={card}>
        <h2 className={h}>{isAr ? 'مواسير العمليات — ASME B36.19M' : 'Process pipe — ASME B36.19M'}</h2>
        <p className={sub}>{isAr ? 'المقاس بالـ DN، والسمك بيتحدد بالـ Schedule. كل الأرقام بالمليمتر.' : 'Sized by DN; the wall follows the schedule. All figures in mm.'}</p>
        <Table headers={PIPE_SCHEDULE.headers} rows={PIPE_SCHEDULE.rows} highlight={[3, 4, 5, 6]} />
      </section>

      <section className={card}>
        <h2 className={h}>{isAr ? 'مواسير صحية (غذائي) — DIN 11850 / BPE' : 'Hygienic tube — DIN 11850 / BPE'}</h2>
        <p className={sub}>
          {isAr
            ? 'دي بتتقاس بالقطر الخارجي مش بالـ NPS — ودي اللي بتمشي في خطوط الأغذية والألبان.'
            : 'Sized on outside diameter, not NPS — this is what food and dairy lines run.'}
        </p>
        <Table headers={SANITARY_TUBE.headers} rows={SANITARY_TUBE.rows} />
      </section>

      <div className="grid grid-cols-1 gap-5 md:grid-cols-2">
        <section className={card}>
          <h2 className={h}>{isAr ? 'الألواح — الأسماك' : 'Sheet — thicknesses'}</h2>
          <p className={sub}>{isAr ? 'مم' : 'mm'}</p>
          <div className="flex flex-wrap gap-1.5">
            {SHEET_STOCK.thicknesses.map((x) => (
              <span key={x} className="rounded border border-line px-2.5 py-1 font-mono text-[12px] text-paper">
                {x}
              </span>
            ))}
          </div>
          <h3 className="mb-2 mt-5 text-[0.85rem] font-semibold">{isAr ? 'المقاسات' : 'Sizes'}</h3>
          <div className="flex flex-wrap gap-1.5">
            {SHEET_STOCK.sizes.map((x) => (
              <span key={x} className="rounded border border-line px-2.5 py-1 font-mono text-[12px] text-muted">
                {x}
              </span>
            ))}
          </div>
        </section>

        <section className={card}>
          <h2 className={h}>{isAr ? 'سماح السمك — EN 10088-2' : 'Thickness tolerance — EN 10088-2'}</h2>
          <p className={sub}>
            {isAr ? 'السبب في إن الوزن المستلم مش بيطابق الحسابي بالظبط.' : 'Why delivered weight never exactly matches the calculation.'}
          </p>
          <Table headers={[isAr ? 'السمك (مم)' : 'Thickness (mm)', isAr ? 'السماح' : 'Tolerance']} rows={THICKNESS_TOLERANCE.map((x) => [x.range, x.tol])} />
        </section>
      </div>

      <section className={card}>
        <h2 className={h}>{isAr ? 'الكثافات' : 'Densities'}</h2>
        <p className={sub}>{isAr ? 'جم/سم³ — دي اللي الحاسبة بتستعملها' : 'g/cm³ — what the calculator uses'}</p>
        <Table
          headers={[isAr ? 'الخامة' : 'Grade', isAr ? 'الكثافة' : 'Density', isAr ? 'ملاحظة' : 'Note']}
          rows={GRADES.map((g) => [g.name[locale], g.density.toFixed(2), g.note?.[locale] ?? '—'])}
        />
      </section>
    </div>
  );
}

function Table({ headers, rows, highlight = [] }: { headers: string[]; rows: string[][]; highlight?: number[] }) {
  return (
    <div className="-mx-2 overflow-x-auto px-2">
      <table className="w-full min-w-[380px] border-collapse text-[0.85rem]">
        <thead>
          <tr className="border-b border-line">
            {headers.map((x, i) => (
              <th
                key={i}
                className={`whitespace-nowrap px-3 py-2 text-start font-mono text-[10.5px] uppercase tracking-[0.1em] ${
                  highlight.includes(i) ? 'text-amber' : 'text-steel-lt'
                }`}
              >
                {x}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {rows.map((r, i) => (
            <tr key={i} className="border-b border-line/50 last:border-none odd:bg-ink/40">
              {r.map((c, j) => (
                <td key={j} className={`whitespace-nowrap px-3 py-2 ${j === 0 ? 'font-semibold text-paper' : 'font-mono text-muted'}`}>
                  {c}
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
