import type { Metadata } from 'next';
import { Locale, isLocale } from '@/lib/i18n';
import { seo, contactPage as CP } from '@/content/site';
import { ContactForm } from './ContactForm';

export async function generateMetadata({ params }: { params: { locale: string } }): Promise<Metadata> {
  const locale = (isLocale(params.locale) ? params.locale : 'ar') as Locale;
  return { title: seo.contact.title[locale], description: seo.contact.desc[locale] };
}

export default function ContactPage({ params }: { params: { locale: string } }) {
  const locale = (isLocale(params.locale) ? params.locale : 'ar') as Locale;
  const t = <T extends { ar: string; en: string }>(x: T) => x[locale];

  return (
    <div className="pt-[74px]">
      <section className="py-[100px]">
        <div className="mx-auto max-w-content px-7">
          <div className="reveal mb-14 max-w-[680px]">
            <span className="eyebrow">{t(CP.eyebrow)}</span>
            <h1 className="mt-4 text-[clamp(2rem,4vw,3rem)]">{t(CP.title)}</h1>
            <p className="mt-4 text-[1.05rem] leading-[1.7] text-muted">{t(CP.intro)}</p>
          </div>

          <div className="grid grid-cols-1 gap-12 lg:grid-cols-[1.3fr_0.7fr]">
            <div className="reveal">
              <ContactForm locale={locale} />
            </div>
            <div className="reveal">
              <h2 className="text-[1.2rem]">{t(CP.infoTitle)}</h2>
              <div className="mt-6 flex flex-col gap-5">
                {CP.info.map((it, i) => (
                  <div key={i} className="border-b border-line pb-5 last:border-none">
                    <div className="font-mono text-[11px] uppercase tracking-[0.14em] text-steel-lt">{t(it.label)}</div>
                    <div className="mt-2 text-[1.05rem]">{t(it.value)}</div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
