'use client';

import { useState } from 'react';
import { Locale } from '@/lib/i18n';
import { contactPage as CP } from '@/content/site';
import { Icon } from '@/components/Icon';

export function ContactForm({ locale }: { locale: Locale }) {
  const t = <T extends { ar: string; en: string }>(x: T) => x[locale];
  const [sent, setSent] = useState(false);
  const L = CP.formLabels;

  // Placeholder handler — wire to CRM (VTiger) / email endpoint on deploy.
  const handleSubmit = () => setSent(true);

  const field = 'w-full rounded-md border border-line bg-ink px-4 py-3 text-[0.95rem] text-paper outline-none transition focus:border-amber';

  return (
    <div className="rounded-2xl border border-line bg-ink-2 p-[34px]">
      {sent ? (
        <div className="py-10 text-center">
          <Icon name="tick" className="mx-auto mb-4 h-10 w-10 text-amber flip-x" strokeWidth={2} />
          <p className="text-[1.1rem] font-semibold">
            {locale === 'ar' ? 'وصلنا طلبك. المكتب الفني هيرجعلك.' : 'Your request reached us. The technical office will respond.'}
          </p>
        </div>
      ) : (
        <div className="flex flex-col gap-4">
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            <input className={field} placeholder={t(L.name)} aria-label={t(L.name)} />
            <input className={field} placeholder={t(L.company)} aria-label={t(L.company)} />
            <input className={field} type="email" placeholder={t(L.email)} aria-label={t(L.email)} />
            <input className={field} placeholder={t(L.phone)} aria-label={t(L.phone)} />
          </div>
          <textarea className={`${field} min-h-[130px] resize-y`} placeholder={t(L.message)} aria-label={t(L.message)} />
          <button
            onClick={handleSubmit}
            className="inline-flex items-center justify-center gap-[9px] rounded-md bg-amber px-7 py-[14px] text-[15px] font-semibold text-[#161310] transition hover:bg-amber-hi"
          >
            {t(L.submit)}
            <Icon name="arrow" className="h-[15px] w-[15px] flip-x" strokeWidth={2.4} />
          </button>
        </div>
      )}
    </div>
  );
}
