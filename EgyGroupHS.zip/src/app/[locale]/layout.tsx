import type { Metadata } from 'next';
import { Archivo, IBM_Plex_Sans_Arabic, IBM_Plex_Mono } from 'next/font/google';
import { notFound } from 'next/navigation';
import { Locale, locales, isLocale, dir } from '@/lib/i18n';
import { Header } from '@/components/Header';
import { Footer } from '@/components/Footer';
import { Reveal } from '@/components/Reveal';
import { company } from '@/content/site';

const archivo = Archivo({ subsets: ['latin'], weight: ['400', '500', '600', '700', '800', '900'], variable: '--font-archivo', display: 'swap' });
const plexAr = IBM_Plex_Sans_Arabic({ subsets: ['arabic'], weight: ['400', '500', '600', '700'], variable: '--font-plex-ar', display: 'swap' });
const plexMono = IBM_Plex_Mono({ subsets: ['latin'], weight: ['400', '500', '600'], variable: '--font-plex-mono', display: 'swap' });

export function generateStaticParams() {
  return locales.map((locale) => ({ locale }));
}

export async function generateMetadata({ params }: { params: { locale: string } }): Promise<Metadata> {
  const locale = isLocale(params.locale) ? params.locale : 'ar';
  const isAr = locale === 'ar';
  return {
    title: {
      default: isAr ? 'المجموعة المصرية (Hard Steel)' : 'Egyptian Group (Hard Steel)',
      template: isAr ? '%s' : '%s',
    },
    alternates: {
      canonical: `/${locale}`,
      languages: { ar: '/ar', en: '/en' },
    },
    openGraph: {
      type: 'website',
      locale: isAr ? 'ar_EG' : 'en_US',
      siteName: company.nameFull[locale],
      images: ['/assets/laser-cutting.jpg'],
    },
  };
}

export default function LocaleLayout({
  children,
  params,
}: {
  children: React.ReactNode;
  params: { locale: string };
}) {
  if (!isLocale(params.locale)) notFound();
  const locale = params.locale as Locale;
  const bodyFont = locale === 'ar' ? plexAr.className : archivo.className;

  return (
    <html lang={locale} dir={dir(locale)} className={`${archivo.variable} ${plexAr.variable} ${plexMono.variable}`}>
      <body className={bodyFont}>
        <Header locale={locale} />
        <main>{children}</main>
        <Footer locale={locale} />
        <Reveal />
      </body>
    </html>
  );
}
