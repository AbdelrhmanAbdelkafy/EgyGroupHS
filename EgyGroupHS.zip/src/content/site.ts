// ============================================================================
// SINGLE SOURCE OF TRUTH — all bilingual site content lives here.
// Every string is { ar, en }. Pages/components read from this file only.
// To move to a CMS later, this shape maps cleanly to Strapi collections.
// ============================================================================

export type L = { ar: string; en: string };

export const company = {
  nameShort: { ar: 'المجموعة المصرية', en: 'Egyptian Group' } as L,
  brandTag: 'HARD STEEL',
  nameFull: { ar: 'المجموعة المصرية (Hard Steel)', en: 'The Egyptian Group (Hard Steel)' } as L,
  domain: 'egygrouphs.com',
  // Placeholders — replace with real data when available
  phone: '[phone]',
  email: '[email]',
  branches: {
    ar: 'القاهرة الكبرى · شمال الصعيد',
    en: 'Greater Cairo · Northern Upper Egypt',
  } as L,
  yearsInMarket: 15,
};

// ---------------------------------------------------------------------------
// NAV
// ---------------------------------------------------------------------------
export const nav: { href: string; label: L }[] = [
  { href: '/catalog', label: { ar: 'الكتالوج', en: 'Catalogue' } },
  { href: '/services', label: { ar: 'الخدمات', en: 'Services' } },
  { href: '/standards', label: { ar: 'المعايير والجودة', en: 'Standards & QA' } },
  { href: '/about', label: { ar: 'من نحن', en: 'About' } },
  { href: '/contact', label: { ar: 'تواصل', en: 'Contact' } },
];

// ---------------------------------------------------------------------------
// HERO (home)
// ---------------------------------------------------------------------------
export const hero = {
  eyebrow: { ar: 'تصنيع معدني صحي · مصر', en: 'Hygienic Metal Fabrication · Egypt' } as L,
  titleHtml: {
    ar: 'لحام تقدر <em>توثّقه</em>،<br/>وسطح تقدر تنضّفه.',
    en: 'The weld you can<br/>document. The finish<br/>you can <em>clean.</em>',
  } as L,
  sub: {
    ar: 'بنصنّع لمصانع الأغذية والأدوية والكيماويات — قص ليزر حتى 30 مم، لحام أوربيتال صحي وفق ASME BPE، وتحليل مواد داخل المصنع. خمستاشر سنة، وأكبر مخزون خامات في مصر ورا كل موعد تسليم.',
    en: 'We fabricate for food, pharmaceutical and chemical plants — laser cutting to 30 mm, orbital sanitary welding to ASME BPE, and in-house material testing. Fifteen years, and the largest raw-material stock in Egypt behind every lead time.',
  } as L,
  ctaPrimary: { ar: 'ابعتلنا رسمة', en: 'Send us a drawing' } as L,
  ctaSecondary: { ar: 'شوف الأرقام', en: 'See the numbers' } as L,
};

export const specStrip: { n: string; u: L; l: L }[] = [
  { n: '30', u: { ar: 'مم', en: 'mm' }, l: { ar: 'قص ليزر · ألواح حتى 6×2.5م', en: 'Laser cut · sheets to 6×2.5 m' } },
  { n: '360', u: { ar: '°', en: '°' }, l: { ar: 'لحام أوربيتال صحي', en: 'Orbital sanitary welding' } },
  { n: '15', u: { ar: 'سنة', en: 'yrs' }, l: { ar: 'في السوق المصري', en: 'In the Egyptian market' } },
  { n: 'ASME', u: { ar: 'BPE', en: 'BPE' }, l: { ar: 'كود التصنيع · ISO 9001', en: 'Fabrication code · ISO 9001' } },
];

// ---------------------------------------------------------------------------
// CREED
// ---------------------------------------------------------------------------
export const creed = {
  eyebrow: { ar: 'ليه إحنا موجودين', en: 'Why we exist' } as L,
  bigHtml: {
    ar: 'إحنا موجودين عشان <em>نعمّق ونقوّي الصناعة المصرية</em> — نصنّع هنا المعدات اللي كانت بتتستورد، ونبني المنظومة اللي بتخلّي ده يتكرّر.',
    en: "We're here to <em>deepen and strengthen Egyptian industry</em> — to build, here, the equipment factories used to import, and the ecosystem that makes it repeatable.",
  } as L,
  body: {
    ar: 'دي مش جملة على الحيطة. دي أكبر مخزون خامات في مصر عشان المشروع ما يستناش توريد؛ وتحليل ولحام وفق الكودات العالمية عشان الشغل المحلي يعدّي التدقيق الدولي؛ وفنيّون مصريون بنوفّرلهم السكن والإعاشة والتأمين والتدريب — لأنك مش هتبني صناعة قوية على ناس مش بتراعيهم.',
    en: "That's not a slogan on a wall. It's the largest material stock in Egypt so a project never waits on an import; it's testing and welding to international code so local work clears an international audit; and it's Egyptian technicians we house, feed, insure and train — because you can't build a strong industry on people you don't take care of.",
  } as L,
};

// ---------------------------------------------------------------------------
// SECTORS
// ---------------------------------------------------------------------------
export const sectors = {
  eyebrow: { ar: 'لمين بنصنّع', en: 'Who we build for' } as L,
  title: { ar: 'ثلاثة قطاعات، فيها اللحام الوحش يعني سحب المنتج.', en: 'Three sectors where a bad weld is a recall.' } as L,
  intro: {
    ar: 'حيث يلامس المنتج المعدن، تشطيب السطح واللحام والتوثيق هم اللي بيقرّروا التشغيلة تتشحن ولا تترمي. ده شغلنا.',
    en: 'Where product touches metal, the surface finish, the weld, and the paperwork decide whether a batch ships or gets scrapped. That\'s the work we do.',
  } as L,
  items: [
    {
      icon: 'drop',
      title: { ar: 'الأغذية والمشروبات', en: 'Food & Beverage' } as L,
      body: {
        ar: 'خطوط ومعدات تُنظَّف بالكامل وتتحمّل دورات الغسيل اليومية — بلا شقوق يستقر فيها المنتج.',
        en: 'Process piping and equipment that clean down fully and survive daily CIP — no crevices for product to sit in.',
      } as L,
    },
    {
      icon: 'flask',
      title: { ar: 'الأدوية', en: 'Pharmaceutical' } as L,
      body: {
        ar: 'لحام موثّق، ومواد متتبَّعة، وتشطيبات حسب المواصفة — الملف اللي المدقّق بيطلبه، جاهز قبل ما يطلبه.',
        en: 'Welds documented, materials traced, finishes to spec — the package an auditor asks for, ready before they ask.',
      } as L,
    },
    {
      icon: 'beaker',
      title: { ar: 'الكيماويات والعمليات', en: 'Chemical & Process' } as L,
      body: {
        ar: 'مبادلات حرارية وخطوط ووحدات مجمّعة تتحمّل الوسائط الكيميائية — ومختبَرة قبل ما تسيب المصنع.',
        en: 'Heat exchangers, piping and skids built to hold against aggressive media — and tested before they leave the floor.',
      } as L,
    },
  ],
};

// ---------------------------------------------------------------------------
// ORBITAL WELDING (signature feature)
// ---------------------------------------------------------------------------
export const welding = {
  eyebrow: { ar: 'اللي بيفرّقنا', en: 'The differentiator' } as L,
  title: { ar: 'لحام أوربيتال — للوصلات اللي مفيش فيها هامش خطأ.', en: 'Orbital welding — for joints with no margin for error.' } as L,
  body: {
    ar: 'الماكينة بتلفّ رأس اللحام 360° حوالين ماسورة ثابتة، فكل وصلة متطابقة وقابلة للتكرار. ده اللي بتطلبه الشغلانات شديدة الدقة وعالية الضغط — خطوط الأغذية والأدوية الصحية، وكمان خطوط العمليات المضغوطة اللي لحام واحد ضعيف فيها يبقى نقطة فشل. ولسه نادر في السوق المصري.',
    en: "A machine rotates the weld head 360° around a fixed tube, so every joint is identical and repeatable. That's what high-precision and high-pressure work demands — sanitary food and pharma lines, but equally the pressurised process piping where one weak weld is a failure point. It's still rare in the Egyptian market.",
  } as L,
  bullets: [
    { ar: 'تطبيقات عالية الضغط وشديدة الدقة', en: 'High-pressure & high-precision applications' } as L,
    { ar: 'بماكينات لحام آلية احترافية', en: 'Run on professional-grade automated welding machines' } as L,
    { ar: 'مفحوص بالأشعة (RT) والسائل النافذ (PT)', en: 'Inspected by radiography (RT) and dye penetrant (PT)' } as L,
    { ar: 'لحام متكرّر وخالٍ من الشقوق، موثّق وفق ASME BPE', en: 'Repeatable, crevice-free welds, documented to ASME BPE' } as L,
  ],
  images: [
    { src: '/assets/orbital-welding.jpg', cap: { ar: 'رأس أوربيتال · ماسورة صحية', en: 'Orbital head · sanitary tube' } as L },
    { src: '/assets/orbital-2.jpg', cap: { ar: 'مصدر ورأس لحام أوربيتال', en: 'Orbital power source & weld head' } as L },
  ],
};

// ---------------------------------------------------------------------------
// CAPABILITIES (numbers table)
// ---------------------------------------------------------------------------
export const capabilities = {
  eyebrow: { ar: 'إمكانيات الورشة', en: 'Shop-floor capability' } as L,
  title: { ar: 'الأرقام اللي هيسألك عنها الاستشاري.', en: 'The numbers your consultant will ask for.' } as L,
  rows: [
    { name: { ar: 'قص ليزر فايبر', en: 'Fiber laser cutting' } as L, sub: { ar: 'كربوني، ستانلس، ألومنيوم', en: 'Carbon, stainless & aluminium' } as L, val: { ar: '≤ 30 mm · 6×2.5 m', en: '≤ 30 mm · 6×2.5 m' } as L },
    { name: { ar: 'اللحام', en: 'Welding' } as L, sub: { ar: 'TIG · ليزر · أوربيتال صحي', en: 'TIG · Laser · Orbital sanitary' } as L, val: { ar: '4 طرق', en: '4 methods' } as L },
    { name: { ar: 'فحص اللحام', en: 'Weld inspection' } as L, sub: { ar: 'أشعة سينية وسائل نافذ', en: 'Radiography & dye penetrant' } as L, val: { ar: 'RT · PT', en: 'RT · PT' } as L },
    { name: { ar: 'تحليل المواد — داخلياً', en: 'Material testing — in-house' } as L, sub: { ar: 'كيميائي وميكانيكي', en: 'Chemical & mechanical' } as L, val: { ar: 'متتبَّع', en: 'Traceable' } as L },
    { name: { ar: 'التشكيل', en: 'Forming' } as L, sub: { ar: 'ثني CNC بدقة عالية', en: 'CNC press-brake bending' } as L, val: { ar: 'CNC', en: 'CNC' } as L },
    { name: { ar: 'التنكات والخزانات', en: 'Tanks & vessels' } as L, sub: { ar: 'تخزين · خلط · ضغط · صحي', en: 'Storage · mixing · pressure · sanitary' } as L, val: { ar: 'حسب الطلب', en: 'To order' } as L },
    { name: { ar: 'تشغيل CNC', en: 'CNC machining' } as L, sub: { ar: 'خراطة وتفريز حسب الرسم', en: 'Turning & milling to drawing' } as L, val: { ar: 'دقة عالية', en: 'Precision' } as L },
    { name: { ar: 'خطوط المواسير الصحية', en: 'Sanitary piping' } as L, sub: { ar: 'ملحومة أوربيتال، تُركَّب بالموقع', en: 'Orbital-welded, installed on site' } as L, val: { ar: 'بالموقع', en: 'On-site' } as L },
  ],
  asideTitle: { ar: 'مطابق للكود، ومثبَت بالورق', en: 'Built to code, proven on paper' } as L,
  asideBody: {
    ar: 'كل مشروع يُصنَّع ويُلحَم ويُوثَّق وفق معايير معتمدة — وكل مادة تُختبَر في معملنا قبل أول شرارة.',
    en: 'Every job is fabricated, welded and documented against recognised standards — and every material is tested in our own lab before a spark is struck.',
  } as L,
  standards: [
    { badge: { ar: 'ISO 9001', en: 'ISO 9001' } as L, d: { ar: 'نظام جودة معتمد', en: 'Certified quality management' } as L },
    { badge: { ar: 'ASME BPE', en: 'ASME BPE' } as L, d: { ar: 'تصنيع وفق كود المعالجة الحيوية', en: 'Fabricated to bioprocessing code' } as L },
    { badge: { ar: 'السلامة', en: 'SAFETY' } as L, d: { ar: 'الصحة والسلامة المهنية', en: 'Occupational health & safety' } as L },
  ],
};

// ---------------------------------------------------------------------------
// SERVICES (11 + send-drawing)
// ---------------------------------------------------------------------------
export const services = {
  eyebrow: { ar: 'إيه اللي بنعمله', en: 'What we do' } as L,
  title: { ar: 'ورشة واحدة، من الرسمة للتسليم مفتاح.', en: 'One shop, from drawing to turnkey handover.' } as L,
  intro: {
    ar: 'قطعة مقصوصة واحدة أو خط عمليات مركّب بالكامل — سقف واحد، نظام جودة واحد، وفريق واحد مسؤول من الأول للآخر.',
    en: 'A single cut part or a fully installed process line — one roof, one quality system, one team accountable end to end.',
  } as L,
  items: [
    { slug: 'laser-cutting', icon: 'wave', title: { ar: 'قص ليزر', en: 'Laser cutting' } as L, desc: { ar: 'ليزر فايبر حتى 30 مم على الكربوني والستانلس والألومنيوم.', en: 'Fiber laser to 30 mm on carbon, stainless and aluminium.' } as L , img: '/assets/laser-cutting.jpg'},
    { slug: 'laser-welding', icon: 'spark', title: { ar: 'لحام ليزر', en: 'Laser welding' } as L, desc: { ar: 'وصلات بأقل تشوّه وأقل تشطيب.', en: 'Low-distortion joints with minimal finishing work.' } as L , img: '/assets/laser-welding.jpg'},
    { slug: 'orbital-welding', icon: 'ring', title: { ar: 'لحام أوربيتال', en: 'Orbital welding' } as L, desc: { ar: 'لحام صحي آلي 360°، موثّق بالكامل.', en: 'Automated 360° sanitary welds, fully documented.' } as L , img: '/assets/orbital-welding.jpg'},
    { slug: 'sanitary-piping', icon: 'pipe', title: { ar: 'خطوط مواسير', en: 'Sanitary piping' } as L, desc: { ar: 'خطوط ملحومة أوربيتال، تُركَّب وتُختبَر بالموقع.', en: 'Orbital-welded process lines, installed and tested on site.' } as L , img: '/assets/orbital-2.jpg'},
    { slug: 'tanks', icon: 'roll', title: { ar: 'تنكات وخزانات', en: 'Tanks & vessels' } as L, desc: { ar: 'تخزين وخلط وضغط وصحية — بأعلى المعايير.', en: 'Storage, mixing, pressure and sanitary — to the highest standards.' } as L, img: '/assets/stock.jpg' },
    { slug: 'forming', icon: 'bend', title: { ar: 'تشكيل معادن', en: 'Metal forming' } as L, desc: { ar: 'ثني CNC بدقة عالية.', en: 'CNC press-brake bending to tight tolerance.' } as L , img: '/assets/press-brake.jpg'},
    { slug: 'machining', icon: 'target', title: { ar: 'تشغيل CNC', en: 'CNC machining' } as L, desc: { ar: 'خراطة وتفريز بدقة عالية حسب الرسم.', en: 'Precision turning and milling to drawing.' } as L },
    { slug: 'heat-exchangers', icon: 'grid', title: { ar: 'مبادلات حرارية', en: 'Heat exchangers' } as L, desc: { ar: 'مصنّعة ومختبَرة بالضغط لخدمة العمليات.', en: 'Fabricated and pressure-tested for process duty.' } as L },
    { slug: 'technical-office', icon: 'home', title: { ar: 'مكتب فني', en: 'Technical office' } as L, desc: { ar: 'تصميم ورسومات وحصر مواد قبل التصنيع.', en: 'Design, drawings and material take-off before fabrication.' } as L },
    { slug: 'shutdown', icon: 'bolt', title: { ar: 'صيانات وShutdown', en: 'Shutdown & maintenance' } as L, desc: { ar: 'أعمال إيقاف مخطّطة بفِرَق تلتزم بالجدول.', en: 'Planned turnaround work by crews that hit the window.' } as L },
    { slug: 'turnkey', icon: 'check', title: { ar: 'تسليم مفتاح', en: 'Turnkey delivery' } as L, desc: { ar: 'من التصميم للتشغيل بعقد واحد.', en: 'Design to commissioning under one contract.' } as L },
  ],
  drawingTile: { title: { ar: 'ابعت رسمتك', en: 'Send your drawing' } as L, desc: { ar: 'المكتب الفني يراجعها ويرجع بنطاق وسعر.', en: 'The technical office reviews it and returns scope + price.' } as L },
};

// ---------------------------------------------------------------------------
// STOCK + FLEET
// ---------------------------------------------------------------------------
export const stock = {
  eyebrow: { ar: 'مخزون + أسطول = ميزة موعد التسليم', en: 'Stock + fleet = the lead-time advantage' } as L,
  title: { ar: 'الخامة موجودة عندنا أصلاً.', en: 'The material is already here.' } as L,
  bodyHtml: [
    {
      ar: 'عندنا <b>أكبر مخزون خامات في مصر</b> — مواسير وألواح وقطاعات ستانلس وألومنيوم، جاهزة على الرفوف. أول ما المشروع يتعتمد، التصنيع يبدأ نفس الأسبوع، بدل ما تستنى أسابيع على توريد ممكن يعدّي الجمرك في ميعاده أو لأ.',
      en: 'We hold the <b>largest raw-material stock in Egypt</b> — stainless and aluminium pipe, sheet and sections, on the racks. When a project is approved, fabrication starts the same week instead of waiting weeks on an import that may or may not clear customs on time.',
    } as L,
    {
      ar: 'والقصة مش بتقف عند الرفوف: أسطول النقل الخاص بينا بيوصّل الخامات والفِرَق لموقعك — فالتسليم كمان مش مستني عربية حد تاني.',
      en: "And it doesn't stop at the racks: our own transport fleet moves material and crews to your site — so the delivery isn't waiting on someone else's truck either.",
    } as L,
    {
      ar: 'للاستشاري، ده جدول زمني تقدر تعتمد عليه. للمصنع، ده وقت توقّف أقل.',
      en: 'For a consultant, that means a schedule you can trust. For a plant, it means less downtime.',
    } as L,
  ],
  image: '/assets/stock.jpg',
};

// ---------------------------------------------------------------------------
// PEOPLE
// ---------------------------------------------------------------------------
export const people = {
  eyebrow: { ar: 'العاملون', en: 'Our people' } as L,
  title: { ar: 'الصناعة القوية بتتبني على ناس بتراعيها.', en: 'A strong industry is built on people you take care of.' } as L,
  intro: {
    ar: 'العملاء العالميون بيدقّقوا إزاي المورّد بيعامل عماله قبل ما يطلبوا. إحنا بنحقّق المعيار ده — مش عشان نعدّي تدقيق، لكن لأن دي طريقة العقيدة على أرض الواقع.',
    en: 'International buyers audit how a supplier treats its workforce before they place an order. We meet that standard — not to pass an audit, but because it\'s how the creed works in practice.',
  } as L,
  cards: [
    {
      icon: 'home',
      title: { ar: 'رعاية تطابق معايير العمالة الدولية', en: 'Care that meets international labour standards' } as L,
      body: {
        ar: 'فنّيونا بنوفّرلهم السكن والإعاشة والمواصلات، مع تأمين اجتماعي وصحي — الظروف اللي تدقيقات سلاسل التوريد العالمية بتدوّر عليها.',
        en: 'Our technicians are housed, fed and transported, with social and health insurance — the conditions global supply-chain audits look for.',
      } as L,
      chips: [
        { ar: 'سكن', en: 'Housing' } as L,
        { ar: 'إعاشة', en: 'Meals' } as L,
        { ar: 'مواصلات', en: 'Transport' } as L,
        { ar: 'تأمين اجتماعي وصحي', en: 'Social & health insurance' } as L,
      ],
    },
    {
      icon: 'grad',
      title: { ar: 'بنكوّن الفني، مش بس بنوظّفه', en: 'We train the technician, not just hire one' } as L,
      body: {
        ar: 'تدريب فني ومؤسسي بيبني فِرَق ماهرة ومستقرة بعقيدة عمل سليمة — صنايعية بيتحمّلوا مسؤولية اللحام، مش بس بيسجّلوا حضور.',
        en: 'Technical and institutional training builds skilled, stable crews with a sound work ethic — craftsmen who take responsibility for the weld, not just clock in.',
      } as L,
      chips: [
        { ar: 'تدريب فني', en: 'Technical training' } as L,
        { ar: 'تدريب مؤسسي', en: 'Institutional training' } as L,
        { ar: 'عقيدة سليمة', en: 'Sound work ethic' } as L,
      ],
    },
  ],
};

// ---------------------------------------------------------------------------
// INSTITUTION (how we run)
// ---------------------------------------------------------------------------
export const institution = {
  eyebrow: { ar: 'إزاي بندير الشغل', en: 'How we run' } as L,
  title: { ar: 'مصنع بيتدار زي مؤسسة — مش ورشة.', en: 'A factory run like an institution — not a workshop.' } as L,
  intro: {
    ar: 'معظم التصنيع في السوق بيتدار من دماغ واحد. إحنا بندير بأنظمة: توصلنا بسهولة، وكل طلب متتبّع، ومفيش حاجة بتتحرّك بره النظام.',
    en: 'Most fabrication in the market is run out of someone\'s head. We run on systems: you reach us easily, every request is tracked, and nothing moves outside the process.',
  } as L,
  cards: [
    {
      icon: 'chat',
      title: { ar: 'سهل توصلنا، صعب طلب يضيع', en: 'Easy to reach, hard to lose a request' } as L,
      body: {
        ar: 'مركز اتصال مخصّص ونظام CRM حيّ معناهم إن كل استفسار وعرض سعر وأوردر متسجّل ومتابَع — مفيش طلب بيقع، ومفيش حد بيستنى ردّ مش جاي.',
        en: 'A dedicated call centre and a live CRM mean every enquiry, quote and order is logged and followed — no request falls through, no one waits for a call-back that never comes.',
      } as L,
      chips: [{ ar: 'مركز اتصال', en: 'Call centre' } as L, { ar: 'CRM', en: 'CRM' } as L, { ar: 'كل طلب متتبّع', en: 'Every request tracked' } as L],
    },
    {
      icon: 'shield',
      title: { ar: 'حوكمة، مش واسطة', en: 'Governance, not favours' } as L,
      body: {
        ar: 'الاعتمادات بتمشي في نظام موثّق ولا مجال فيه للتجاوز. نفس الانضباط اللي بيخلّي العملاء العالميين يثقوا فينا — وعشان كده عملاؤنا بيفضلوا سريين، ونموّنا كله بالتوصية مش بالإعلان.',
        en: 'Approvals run through a documented process with no room for shortcuts. It\'s the same discipline that lets global clients trust us — and why our clients stay confidential and our growth comes by referral, not advertising.',
      } as L,
      chips: [{ ar: 'نظام موثّق', en: 'Documented process' } as L, { ar: 'سرية العملاء', en: 'Client confidentiality' } as L, { ar: 'نموّ بالتوصية', en: 'Growth by referral' } as L],
    },
  ],
};

// ---------------------------------------------------------------------------
// ECOSYSTEM
// ---------------------------------------------------------------------------
export const ecosystem = {
  eyebrow: { ar: 'رايحين على فين', en: 'Where we\'re headed' } as L,
  titleHtml: {
    ar: 'الخط كله تحت سقف واحد — لأن المقصود مش الخط. المقصود <em>العادة</em> اللي وراه.',
    en: 'The whole line, under one roof — because the point isn\'t the line. It\'s the <em>habit</em> behind it.',
  } as L,
  intro: {
    ar: 'الاستشاري مالوش لازمة يلفّ على خمس موردين ويحكم بينهم لما وصلة تنقّط. فتحت سقفنا، كل مرحلة بتغذّي اللي بعدها — الخامة، التصميم، التصنيع، الفحص، النقل، التركيب — وفريق واحد مسؤول من الرسمة للتسليم. لكن منظومة زي دي مايستاهلش نبنيها إلا لو أثبتت حاجة أكبر: إن ده ببساطة إزاي الشغل المفروض يتعمل.',
    en: 'A consultant shouldn\'t juggle five suppliers and referee the blame when a joint leaks. So under our roof, every stage feeds the next — material, design, fabrication, inspection, transport, install — one team accountable from the drawing to the handover. But an ecosystem like this is only worth building if it proves something bigger: that this is simply how the work should be done.',
  } as L,
  chain: [
    { step: { ar: 'الخامة', en: 'STOCK' } as L, name: { ar: 'المخزون', en: 'Material' } as L, note: { ar: 'أكبر مخزون في مصر، على الرفوف.', en: 'Largest stock in Egypt, on the racks.' } as L },
    { step: { ar: 'التصميم', en: 'DESIGN' } as L, name: { ar: 'المكتب الفني', en: 'Technical office' } as L, note: { ar: 'رسومات وحصر مواد.', en: 'Drawings and material take-off.' } as L },
    { step: { ar: 'التصنيع', en: 'MAKE' } as L, name: { ar: 'التصنيع', en: 'Fabrication' } as L, note: { ar: 'قص، تشكيل، خراطة، لحام، تنكات.', en: 'Cut, form, machine, weld, tanks.' } as L },
    { step: { ar: 'الفحص', en: 'VERIFY' } as L, name: { ar: 'الفحص', en: 'Inspection' } as L, note: { ar: 'أشعة ونافذ وتحليل مواد.', en: 'RT, PT & material testing.' } as L },
    { step: { ar: 'النقل', en: 'DELIVER' } as L, name: { ar: 'الأسطول', en: 'Transport' } as L, note: { ar: 'أسطولنا لموقعك.', en: 'Our own fleet to your site.' } as L },
    { step: { ar: 'التركيب', en: 'COMMISSION' } as L, name: { ar: 'التركيب والتشغيل', en: 'Install' } as L, note: { ar: 'مركّب، مختبَر، شغّال.', en: 'Fitted, tested, running.' } as L },
  ],
  loop: {
    ar: 'كل مرحلة متتبّعة على نظام واحد — والفِرَق المدرّبة اللي بتشغّلها ناس بنبنيها ونرعاها ونحافظ عليها.',
    en: 'Every stage tracked on one system — and the trained crews that run it are people we build, house and keep.',
  } as L,
};

// ---------------------------------------------------------------------------
// CULTURE SIGNATURE
// ---------------------------------------------------------------------------
export const signature = {
  lead: { ar: 'عقيدتنا', en: 'Our creed' } as L,
  signHtml: {
    ar: 'إحنا مش بنجري ورا النجاح.<br/>إحنا بنشتغل عشان ده يبقى <em>ثقافة</em>.',
    en: 'We\'re not chasing success.<br/>We\'re working to make this a <em>culture</em>.',
  } as L,
  by: {
    ar: 'ده معنى تعميق الصناعة المصرية: مش مصنع واحد عملها صح، لكن طريقة شغل غيرنا يتعلّم منها.',
    en: 'That\'s what deepening Egyptian industry means: not one factory that got it right, but a way of working that others learn from.',
  } as L,
};

// ---------------------------------------------------------------------------
// CTA
// ---------------------------------------------------------------------------
export const cta = {
  title: { ar: 'عندك مواصفة، رسمة، أو حتى مشكلة؟', en: 'Have a spec, a drawing, or just a problem?' } as L,
  body: {
    ar: 'ابعتها. المكتب الفني يراجعها ويرجعلك بنطاق عمل وسعر — مش مكالمة مبيعات.',
    en: 'Send it over. The technical office reviews it and comes back with a scope and a price — not a sales call.',
  } as L,
  primary: { ar: 'اطلب عرض سعر', en: 'Request a quote' } as L,
  secondary: { ar: 'حمّل الكتالوج', en: 'Download catalogue' } as L,
};

// ---------------------------------------------------------------------------
// FOOTER
// ---------------------------------------------------------------------------
export const footer = {
  blurb: {
    ar: 'تصنيع معدني صحي لقطاعات الأغذية والأدوية والكيماويات — قص ولحام وتحليل وتوثيق مطابق للكود. فروع في القاهرة الكبرى وشمال الصعيد.',
    en: 'Hygienic metal fabrication for food, pharmaceutical and chemical industries — cut, welded, tested and documented to code. Branches in Greater Cairo and Northern Upper Egypt.',
  } as L,
  cols: [
    {
      head: { ar: 'الخدمات', en: 'Services' } as L,
      links: [
        { label: { ar: 'تنكات وخزانات', en: 'Tanks & vessels' } as L, href: '/catalog/tanks' },
        { label: { ar: 'قص ليزر', en: 'Laser cutting' } as L, href: '/services' },
        { label: { ar: 'لحام أوربيتال', en: 'Orbital welding' } as L, href: '/services' },
        { label: { ar: 'مواسير صحية', en: 'Sanitary piping' } as L, href: '/services' },
        { label: { ar: 'مشاريع تسليم مفتاح', en: 'Turnkey projects' } as L, href: '/services' },
      ],
    },
    {
      head: { ar: 'الشركة', en: 'Company' } as L,
      links: [
        { label: { ar: 'من نحن', en: 'About' } as L, href: '/about' },
        { label: { ar: 'المعايير والجودة', en: 'Standards & QA' } as L, href: '/standards' },
        { label: { ar: 'العاملون', en: 'Our people' } as L, href: '/about' },
        { label: { ar: 'الكتالوج', en: 'Catalogue' } as L, href: '/contact' },
      ],
    },
    {
      head: { ar: 'تواصل', en: 'Contact' } as L,
      links: [
        { label: { ar: 'اطلب عرض سعر', en: 'Request a quote' } as L, href: '/contact' },
        { label: { ar: 'القاهرة الكبرى · شمال الصعيد', en: 'Greater Cairo · N. Upper Egypt' } as L, href: '/contact' },
      ],
    },
  ],
  rights: { ar: '© 2026 المجموعة المصرية (Hard Steel). جميع الحقوق محفوظة.', en: '© 2026 The Egyptian Group (Hard Steel). All rights reserved.' } as L,
};

// ---------------------------------------------------------------------------
// PER-PAGE SEO METADATA
// ---------------------------------------------------------------------------
export const seo = {
  home: {
    title: { ar: 'المجموعة المصرية (Hard Steel) — تصنيع معدني صحي للأغذية والأدوية والكيماويات', en: 'Egyptian Group (Hard Steel) — Hygienic Metal Fabrication for Food, Pharma & Chemical' } as L,
    desc: {
      ar: 'تصنيع تعاقدي لمصانع الأغذية والأدوية والكيماويات في مصر. قص ليزر حتى 30مم، لحام أوربيتال صحي وفق ASME BPE، تحليل مواد داخلي وفحص NDT. 15 سنة، وأكبر مخزون خامات في مصر.',
      en: 'Contract metal fabrication for food, pharmaceutical and chemical plants in Egypt. Laser cutting to 30mm, orbital sanitary welding to ASME BPE, in-house material testing and NDT. 15 years, largest raw-material stock in Egypt.',
    } as L,
  },
  services: {
    title: { ar: 'الخدمات — تنكات، قص ليزر، لحام أوربيتال، مبادلات | المجموعة المصرية', en: 'Services — Tanks, Laser Cutting, Orbital Welding, Exchangers | Egyptian Group' } as L,
    desc: {
      ar: 'خدمات التصنيع المعدني: تنكات وخزانات، قص ليزر، لحام TIG وليزر وأوربيتال، خطوط مواسير صحية، تشكيل، تشغيل CNC، مبادلات حرارية، مكتب فني، وتسليم مفتاح — تحت سقف واحد.',
      en: 'Metal fabrication services: tanks and vessels, laser cutting, TIG/laser/orbital welding, sanitary piping, forming, CNC machining, heat exchangers, technical office and turnkey — under one roof.',
    } as L,
  },
  standards: {
    title: { ar: 'المعايير والجودة — ASME BPE · ISO 9001 · فحص RT/PT | المجموعة المصرية', en: 'Standards & QA — ASME BPE · ISO 9001 · RT/PT Inspection | Egyptian Group' } as L,
    desc: {
      ar: 'نصنّع ونلحم ونوثّق وفق ASME وASME BPE وISO 9001، مع تحليل مواد كيميائي وميكانيكي داخلي وفحص لحام بالأشعة (RT) والسائل النافذ (PT).',
      en: 'We fabricate, weld and document to ASME, ASME BPE and ISO 9001, with in-house chemical and mechanical material testing and weld inspection by radiography (RT) and dye penetrant (PT).',
    } as L,
  },
  about: {
    title: { ar: 'من نحن — عقيدتنا والعاملون والمنظومة | المجموعة المصرية (Hard Steel)', en: 'About — Our Creed, People & Ecosystem | Egyptian Group (Hard Steel)' } as L,
    desc: {
      ar: 'عقيدتنا: تعميق وتقوية الصناعة المصرية. مصنع بيتدار زي مؤسسة، بيرعى فنّييه ويدرّبهم، وبيبني منظومة تصنيع متكاملة تحت سقف واحد.',
      en: 'Our creed: deepening and strengthening Egyptian industry. A factory run like an institution that cares for and trains its technicians, building an integrated fabrication ecosystem under one roof.',
    } as L,
  },
  contact: {
    title: { ar: 'تواصل — اطلب عرض سعر أو ابعت رسمة | المجموعة المصرية (Hard Steel)', en: 'Contact — Request a Quote or Send a Drawing | Egyptian Group (Hard Steel)' } as L,
    desc: {
      ar: 'ابعت مواصفتك أو رسمتك، والمكتب الفني يراجعها ويرجعلك بنطاق عمل وسعر. فروع في القاهرة الكبرى وشمال الصعيد.',
      en: 'Send your spec or drawing and the technical office reviews it and returns a scope and price. Branches in Greater Cairo and Northern Upper Egypt.',
    } as L,
  },
};

// ---------------------------------------------------------------------------
// STANDARDS PAGE (dedicated QA content)
// ---------------------------------------------------------------------------
export const standardsPage = {
  eyebrow: { ar: 'المعايير والجودة', en: 'Standards & Quality Assurance' } as L,
  title: { ar: 'نصنّع للكود، ونثبته بالورق.', en: 'We build to code — and prove it on paper.' } as L,
  intro: {
    ar: 'الاستشاري مش محتاج يصدّقنا على كلامنا. كل مشروع بيتصنّع ويتلحم ويتوثّق وفق معايير معتمدة، وكل مادة بتتحلّل في معملنا قبل أول شرارة — والملف بيتسلّم معاه.',
    en: 'A consultant doesn\'t have to take our word for it. Every job is fabricated, welded and documented against recognised standards, and every material is tested in our own lab before a spark is struck — and the file is handed over with it.',
  } as L,
  blocks: [
    {
      badge: { ar: 'ISO 9001', en: 'ISO 9001' } as L,
      title: { ar: 'نظام جودة معتمد', en: 'Certified quality management' } as L,
      body: { ar: 'إجراءات موثّقة لكل مرحلة — من استلام الخامة للتسليم — بنظام جودة معتمد يضمن التكرار والتتبّع.', en: 'Documented procedures at every stage — from material receipt to handover — under a certified quality system that ensures repeatability and traceability.' } as L,
    },
    {
      badge: { ar: 'ASME BPE', en: 'ASME BPE' } as L,
      title: { ar: 'تصنيع وفق كود المعالجة الحيوية', en: 'Fabricated to bioprocessing code' } as L,
      body: { ar: 'نصنّع ونلحم وفق إرشادات ASME BPE — كود معدات المعالجة الحيوية للأدوية والأغذية عالية النقاء، بلحام صحي خالٍ من الشقوق.', en: 'We fabricate and weld to ASME BPE guidelines — the bioprocessing equipment code for high-purity pharma and food — with crevice-free sanitary welds.' } as L,
    },
    {
      badge: { ar: 'السلامة', en: 'SAFETY' } as L,
      title: { ar: 'الصحة والسلامة المهنية', en: 'Occupational health & safety' } as L,
      body: { ar: 'التزام بمعايير الصحة والسلامة المهنية في الورشة والموقع — لحماية الفرق واستمرارية العمل.', en: 'Commitment to occupational health and safety standards in the shop and on site — protecting crews and keeping work running.' } as L,
    },
  ],
  qaTitle: { ar: 'التحقق: تحليل داخلي وفحص لا إتلافي', en: 'Verification: in-house testing & NDT' } as L,
  qaItems: [
    { name: { ar: 'تحليل كيميائي', en: 'Chemical analysis' } as L, d: { ar: 'التأكد من تركيب الخامة قبل التصنيع.', en: 'Confirming material composition before fabrication.' } as L },
    { name: { ar: 'اختبار ميكانيكي', en: 'Mechanical testing' } as L, d: { ar: 'خواص المادة الميكانيكية داخل المعمل.', en: 'Mechanical properties, tested in-house.' } as L },
    { name: { ar: 'فحص بالأشعة (RT)', en: 'Radiography (RT)' } as L, d: { ar: 'فحص لا إتلافي لسلامة اللحام الداخلية.', en: 'Non-destructive inspection of internal weld integrity.' } as L },
    { name: { ar: 'سائل نافذ (PT)', en: 'Dye penetrant (PT)' } as L, d: { ar: 'كشف عيوب سطح اللحام.', en: 'Detecting surface weld defects.' } as L },
  ],
  docLine: {
    ar: 'وبيتسلّم مع المشروع ملف توثيق: شهادات المواد، سجلات اللحام، وتقارير الفحص — الملف اللي المدقّق بيطلبه.',
    en: 'And a documentation package ships with the project: material certificates, weld logs, and inspection reports — the file an auditor asks for.',
  } as L,
};

// ---------------------------------------------------------------------------
// CONTACT PAGE
// ---------------------------------------------------------------------------
export const contactPage = {
  eyebrow: { ar: 'تواصل', en: 'Get in touch' } as L,
  title: { ar: 'ابعت رسمتك، والباقي علينا.', en: 'Send your drawing — we\'ll take it from there.' } as L,
  intro: {
    ar: 'المكتب الفني بيراجع المواصفة أو الرسمة ويرجعلك بنطاق عمل وسعر. مش مكالمة مبيعات — ردّ فني.',
    en: 'The technical office reviews the spec or drawing and returns a scope and a price. Not a sales call — a technical response.',
  } as L,
  formLabels: {
    name: { ar: 'الاسم', en: 'Name' } as L,
    company: { ar: 'الشركة', en: 'Company' } as L,
    email: { ar: 'البريد الإلكتروني', en: 'Email' } as L,
    phone: { ar: 'التليفون', en: 'Phone' } as L,
    message: { ar: 'وصف المشروع أو المطلوب', en: 'Project or request' } as L,
    submit: { ar: 'ابعت الطلب', en: 'Send request' } as L,
    note: { ar: 'أو ابعتلنا على البريد مباشرةً.', en: 'Or email us directly.' } as L,
  },
  infoTitle: { ar: 'معلومات التواصل', en: 'Contact details' } as L,
  info: [
    { label: { ar: 'الفروع', en: 'Branches' } as L, value: { ar: 'القاهرة الكبرى · شمال الصعيد', en: 'Greater Cairo · Northern Upper Egypt' } as L },
    { label: { ar: 'التليفون', en: 'Phone' } as L, value: { ar: '[التليفون]', en: '[phone]' } as L },
    { label: { ar: 'البريد', en: 'Email' } as L, value: { ar: '[البريد الإلكتروني]', en: '[email]' } as L },
    { label: { ar: 'الموقع', en: 'Website' } as L, value: { ar: 'egygrouphs.com', en: 'egygrouphs.com' } as L },
  ],
};
