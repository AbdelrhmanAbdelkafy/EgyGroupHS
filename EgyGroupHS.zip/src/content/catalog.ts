// ============================================================================
// CATALOG — Master items (products) with their own option sets.
// Data sources (REAL, not invented):
//   • Specs/materials/thicknesses  → Namasoft ERP (InvItem, section IS0022 "Prod*")
//   • Images                       → Cloudinary library (recovered factory photos)
// Every master item = product + ITS OWN options → "Request a quote" (no fixed price).
// Two families:  'custom'  = industrial, made-to-order (configurator)
//                'standard'= catalogue product (spec sheet + enquiry)
// ============================================================================

export type L = { ar: string; en: string };

export type Option = {
  key: string;
  label: L;
  /** free = customer types a value (e.g. capacity); choice = pick from values */
  kind: 'choice' | 'free';
  values?: L[];
  hint?: L;
};

export type MasterItem = {
  slug: string;
  family: 'custom' | 'standard';
  category: L;
  name: L;
  tagline: L;
  body: L;
  /** Cloudinary URLs — real factory photos */
  images: string[];
  options: Option[];
  /** real, verifiable spec lines pulled from ERP job history */
  facts?: L[];
};

const CL = 'https://res.cloudinary.com/djrskkszi/image/upload';

// Shared option value sets (materials/thicknesses are REAL — from Namasoft item classes)
const MATERIALS: L[] = [
  { ar: 'استانلس 304', en: 'Stainless 304' },
  { ar: 'استانلس 316', en: 'Stainless 316' },
  { ar: 'استانلس 201', en: 'Stainless 201' },
  { ar: 'كربوستيل', en: 'Carbon steel' },
  { ar: 'استيل مدهون', en: 'Painted steel' },
];

const THICKNESS: L[] = [
  { ar: '1.25 مم', en: '1.25 mm' },
  { ar: '1.5 مم', en: '1.5 mm' },
  { ar: '2 مم', en: '2 mm' },
  { ar: '3 مم', en: '3 mm' },
  { ar: '4 مم', en: '4 mm' },
  { ar: 'حسب التصميم', en: 'To design' },
];

const FINISH: L[] = [
  { ar: 'تشطيب صناعي', en: 'Industrial finish' },
  { ar: 'تشطيب صحي (مصقول)', en: 'Sanitary (polished)' },
  { ar: 'مرآة', en: 'Mirror' },
];

// ---------------------------------------------------------------------------
// MASTER ITEMS
// ---------------------------------------------------------------------------
export const masterItems: MasterItem[] = [
  // ======================= 1. TANKS — the flagship =======================
  {
    slug: 'tanks',
    family: 'custom',
    category: { ar: 'صناعي — حسب الطلب', en: 'Industrial — made to order' },
    name: { ar: 'تنكات وخزانات', en: 'Tanks & Vessels' },
    tagline: { ar: 'الجودة بتبدأ قبل أول لحام.', en: 'Quality starts before the first weld.' },
    body: {
      ar: 'بنصنّع كل أنواع التنكات — تخزين، خلط، ضغط، وصحية — للأغذية والأدوية والكيماويات والصناعات الثقيلة. قبل ما نقص أي صاج، بنفهم التنك هيشتغل في إيه، ونختار الخامة والسُمك والتصميم على الأساس ده. والتشطيب النهائي على مستوى عالمي: سطح يعدّي تدقيق النظافة، ويقاوم التآكل. ولأن الخامة موجودة عندنا وكل خطوة تحت سقف واحد — التنفيذ أسرع، التكلفة أقل، والجودة تحت سيطرتنا بالكامل.',
      en: 'We build every type of tank — storage, mixing, pressure and sanitary — for food, pharmaceutical, chemical and heavy industry. Before a single sheet is cut, we understand what the tank has to do, and choose the material, thickness and design around that. The finish is world-class: a surface that clears a hygiene audit and resists corrosion. And because the material is already on our racks and every stage sits under one roof, delivery is faster, cost is lower, and quality stays entirely under our control.',
    },
    images: [
      '/assets/tank-main.jpg',
      `${CL}/v1679734631/IMG_20210717_214715_bf071da224.jpg`,
      `${CL}/v1679741105/Whats_App_Image_2021_07_25_at_5_24_33_PM_960201b5ee.jpg`,
      `${CL}/v1683379935/M1_2ff820ec08.jpg`,
    ],
    facts: [
      { ar: 'تخزين · خلط · ضغط · صحي', en: 'Storage · Mixing · Pressure · Sanitary' },
      { ar: 'استانلس 304 / 316 · كربوستيل', en: 'Stainless 304 / 316 · Carbon steel' },
      { ar: 'أسماك من 1.5 إلى 4 مم حسب التصميم', en: 'Thickness 1.5–4 mm to design' },
      { ar: 'لحام مفحوص RT/PT · توثيق كامل', en: 'RT/PT inspected welds · full documentation' },
    ],
    options: [
      {
        key: 'type',
        label: { ar: 'نوع التنك', en: 'Tank type' },
        kind: 'choice',
        values: [
          { ar: 'تخزين', en: 'Storage' },
          { ar: 'خلط / تقليب', en: 'Mixing' },
          { ar: 'ضغط', en: 'Pressure' },
          { ar: 'صحي (أغذية/أدوية)', en: 'Sanitary (food/pharma)' },
        ],
      },
      { key: 'material', label: { ar: 'الخامة', en: 'Material' }, kind: 'choice', values: MATERIALS.slice(0, 4) },
      { key: 'thickness', label: { ar: 'سُمك الصاج', en: 'Sheet thickness' }, kind: 'choice', values: THICKNESS },
      {
        key: 'capacity',
        label: { ar: 'السعة / المقاس', en: 'Capacity / size' },
        kind: 'free',
        hint: { ar: 'مثال: 5 م³ · أو قطر 150سم × ارتفاع 200سم', en: 'e.g. 5 m³ · or Ø150cm × H200cm' },
      },
      { key: 'finish', label: { ar: 'التشطيب', en: 'Finish' }, kind: 'choice', values: FINISH },
      {
        key: 'extras',
        label: { ar: 'إضافات', en: 'Add-ons' },
        kind: 'free',
        hint: { ar: 'بومبيه، غطاء، أرجل، مقلّب، جاكيت تبريد...', en: 'Dished end, lid, legs, agitator, cooling jacket…' },
      },
    ],
  },

  // ======================= 2. SANITARY PIPING =======================
  {
    slug: 'process-piping',
    family: 'custom',
    category: { ar: 'صناعي — حسب الطلب', en: 'Industrial — made to order' },
    name: { ar: 'خطوط مواسير', en: 'Process Piping' },
    tagline: { ar: 'خط تقدر توثّق كل وصلة فيه.', en: 'A line where every joint is documented.' },
    body: {
      ar: 'خطوط مواسير صحية وصناعية — تُصمَّم وتُصنَّع وتُركَّب وتُختبَر بالموقع. اللحام الأوربيتال بيدّي وصلة متطابقة وقابلة للتكرار، خالية من الشقوق اللي المنتج يستقر فيها. وكل وصلة مفحوصة وموثّقة.',
      en: 'Sanitary and industrial process lines — designed, fabricated, installed and tested on site. Orbital welding gives an identical, repeatable joint with no crevices for product to sit in. Every weld inspected and documented.',
    },
    images: [`${CL}/v1704966153/TB_26j_Djf_O_Qn_BK_Nj_SZ_Fm_X_Xc_Ap_V_Xa_841968353_7ddf0c6203.jpg`, `${CL}/v1699872189/Stainless_Steel_Pipe_8_1f3669574f.jpg`, `${CL}/v1679738568/13_bfdd21487a.jpg`],
    facts: [
      { ar: 'لحام أوربيتال 360° · TIG · ليزر', en: 'Orbital 360° · TIG · Laser welding' },
      { ar: 'استانلس 304 / 316 · كربوستيل جدول 40', en: 'Stainless 304/316 · Carbon steel Sch 40' },
      { ar: 'يُركَّب ويُختبَر بالموقع', en: 'Installed and tested on site' },
    ],
    options: [
      { key: 'material', label: { ar: 'الخامة', en: 'Material' }, kind: 'choice', values: MATERIALS.slice(0, 4) },
      {
        key: 'diameter',
        label: { ar: 'القطر', en: 'Diameter' },
        kind: 'choice',
        values: [
          { ar: '½ بوصة', en: '½"' }, { ar: '1 بوصة', en: '1"' }, { ar: '1½ بوصة', en: '1½"' },
          { ar: '2 بوصة', en: '2"' }, { ar: '3 بوصة', en: '3"' }, { ar: '4 بوصة', en: '4"' },
          { ar: 'أكبر / متنوّع', en: 'Larger / mixed' },
        ],
      },
      {
        key: 'welding',
        label: { ar: 'نوع اللحام', en: 'Welding' },
        kind: 'choice',
        values: [
          { ar: 'أوربيتال (صحي)', en: 'Orbital (sanitary)' },
          { ar: 'TIG', en: 'TIG' },
          { ar: 'حسب المواصفة', en: 'To spec' },
        ],
      },
      { key: 'length', label: { ar: 'الطول التقريبي', en: 'Approx. length' }, kind: 'free', hint: { ar: 'بالمتر', en: 'in metres' } },
      {
        key: 'scope',
        label: { ar: 'نطاق العمل', en: 'Scope' },
        kind: 'choice',
        values: [
          { ar: 'تصنيع فقط', en: 'Fabrication only' },
          { ar: 'تصنيع + تركيب', en: 'Fabrication + installation' },
          { ar: 'تسليم مفتاح', en: 'Turnkey' },
        ],
      },
    ],
  },

  // ======================= 3. STAINLESS TABLES (standard) =======================
  {
    slug: 'stainless-tables',
    family: 'standard',
    category: { ar: 'تجهيزات استانلس', en: 'Stainless fixtures' },
    name: { ar: 'ترابيزات استانلس', en: 'Stainless Tables' },
    tagline: { ar: 'سطح شغل يتنضّف بالكامل.', en: 'A work surface that cleans down fully.' },
    body: {
      ar: 'ترابيزات استانلس لمصانع الأغذية والمعامل والمطابخ الصناعية — لحام أملس بلا شقوق، وأرجل قابلة للضبط، وسطح يتحمّل دورات الغسيل اليومية.',
      en: 'Stainless tables for food plants, laboratories and industrial kitchens — smooth crevice-free welds, adjustable legs, and a surface that stands up to daily wash-down.',
    },
    images: [`${CL}/v1727280000/erbt_astanls_styl_20724b113c.jpg`],
    facts: [
      { ar: 'استانلس 304 · سمك 1.5 مم (قياسي)', en: 'Stainless 304 · 1.5 mm (standard)' },
      { ar: 'مقاسات شائعة: 100×90 سم — وحسب الطلب', en: 'Common: 100×90 cm — or to order' },
    ],
    options: [
      { key: 'material', label: { ar: 'الخامة', en: 'Material' }, kind: 'choice', values: MATERIALS.slice(0, 3) },
      { key: 'thickness', label: { ar: 'السُمك', en: 'Thickness' }, kind: 'choice', values: THICKNESS.slice(0, 4) },
      { key: 'size', label: { ar: 'المقاس', en: 'Size' }, kind: 'free', hint: { ar: 'مثال: 100×90 سم', en: 'e.g. 100×90 cm' } },
      {
        key: 'shelf',
        label: { ar: 'رف سفلي', en: 'Under-shelf' },
        kind: 'choice',
        values: [{ ar: 'بدون', en: 'None' }, { ar: 'رف واحد', en: 'One shelf' }, { ar: 'رفين', en: 'Two shelves' }],
      },
    ],
  },

  // ======================= 4. STAINLESS CHAIRS (standard) =======================
  {
    slug: 'stainless-chairs',
    family: 'standard',
    category: { ar: 'تجهيزات استانلس', en: 'Stainless fixtures' },
    name: { ar: 'كراسي استانلس', en: 'Stainless Chairs' },
    tagline: { ar: 'للبيئات اللي بتتغسل كل يوم.', en: 'For environments washed down daily.' },
    body: {
      ar: 'كراسي ومقاعد استانلس لخطوط الإنتاج والمعامل وغرف النظافة — بتقاوم التآكل ودورات التنظيف، ومصمّمة تتنضّف بالكامل.',
      en: 'Stainless chairs and stools for production lines, laboratories and clean rooms — corrosion-resistant, cleaning-cycle proof, and designed to clean down completely.',
    },
    images: [`${CL}/v1727280001/krsa_astanls_styl_2c8b64e552.jpg`, `${CL}/v1727280002/krsy_astanls_styl_b5e454c7eb.jpg`],
    facts: [{ ar: 'استانلس 304 / 201', en: 'Stainless 304 / 201' }],
    options: [
      { key: 'material', label: { ar: 'الخامة', en: 'Material' }, kind: 'choice', values: MATERIALS.slice(0, 3) },
      {
        key: 'style',
        label: { ar: 'النوع', en: 'Type' },
        kind: 'choice',
        values: [
          { ar: 'كرسي بظهر', en: 'Chair with back' },
          { ar: 'تابوريه (بدون ظهر)', en: 'Stool (backless)' },
          { ar: 'قابل لضبط الارتفاع', en: 'Height-adjustable' },
        ],
      },
      { key: 'qty', label: { ar: 'الكمية', en: 'Quantity' }, kind: 'free', hint: { ar: 'عدد', en: 'pieces' } },
    ],
  },

  // ======================= 5. SAFETY LADDERS & STAIRS =======================
  {
    slug: 'ladders-stairs',
    family: 'custom',
    category: { ar: 'صناعي — حسب الطلب', en: 'Industrial — made to order' },
    name: { ar: 'سلالم ودرج سيفتي', en: 'Safety Ladders & Stairs' },
    tagline: { ar: 'وصول آمن، مصنوع للمصنع.', en: 'Safe access, built for the plant.' },
    body: {
      ar: 'سلالم ودرج ومنصات وصول صناعية — بدرجات مانعة للانزلاق وهندريل مطابق للاشتراطات، محسوبة على الأحمال الفعلية للموقع.',
      en: 'Industrial ladders, stairs and access platforms — anti-slip treads and compliant handrails, engineered to the actual site loads.',
    },
    images: [`${CL}/v1679740196/3_e8c227ccf6.jpg`, `${CL}/v1679740219/1_ba4df86cf6.jpg`],
    facts: [
      { ar: 'استيل مدهون · استانلس 304', en: 'Painted steel · Stainless 304' },
      { ar: 'مثال منفّذ: 450×100 سم، ارتفاع 500 سم، 5 درجات', en: 'Built example: 450×100 cm, H 500 cm, 5 treads' },
    ],
    options: [
      { key: 'material', label: { ar: 'الخامة', en: 'Material' }, kind: 'choice', values: [MATERIALS[0], MATERIALS[4], MATERIALS[3]] },
      {
        key: 'kind',
        label: { ar: 'النوع', en: 'Type' },
        kind: 'choice',
        values: [
          { ar: 'سلم رأسي', en: 'Vertical ladder' },
          { ar: 'درج بدرجات', en: 'Stepped stairs' },
          { ar: 'منصة وصول', en: 'Access platform' },
        ],
      },
      { key: 'height', label: { ar: 'الارتفاع', en: 'Height' }, kind: 'free', hint: { ar: 'بالسنتيمتر', en: 'in cm' } },
      {
        key: 'handrail',
        label: { ar: 'هندريل', en: 'Handrail' },
        kind: 'choice',
        values: [{ ar: 'جانب واحد', en: 'One side' }, { ar: 'الجانبين', en: 'Both sides' }, { ar: 'بدون', en: 'None' }],
      },
    ],
  },

  // ======================= 6. PLATFORMS =======================
  {
    slug: 'platforms',
    family: 'custom',
    category: { ar: 'صناعي — حسب الطلب', en: 'Industrial — made to order' },
    name: { ar: 'منصات وقواعد', en: 'Platforms & Bases' },
    tagline: { ar: 'محسوبة على الحمل، مش على التخمين.', en: 'Engineered to the load, not to a guess.' },
    body: {
      ar: 'منصات عمل وقواعد ماكينات — تُحسب على الأحمال والاهتزاز الفعلي، وتُصنَّع بالسُمك المناسب للخدمة.',
      en: 'Work platforms and machine bases — calculated against real loads and vibration, fabricated at the right thickness for the duty.',
    },
    images: [`${CL}/v1679737824/2_719c6f812a.jpg`],
    facts: [{ ar: 'استيل · استانلس · أسماك حتى 15 مم', en: 'Steel · Stainless · up to 15 mm plate' }],
    options: [
      { key: 'material', label: { ar: 'الخامة', en: 'Material' }, kind: 'choice', values: MATERIALS },
      { key: 'size', label: { ar: 'المقاس', en: 'Size' }, kind: 'free', hint: { ar: 'طول × عرض × ارتفاع', en: 'L × W × H' } },
      { key: 'load', label: { ar: 'الحمل المتوقع', en: 'Expected load' }, kind: 'free', hint: { ar: 'كجم / طن', en: 'kg / tonnes' } },
    ],
  },

  // ═══════════════ INDUSTRIAL — MADE TO ORDER (7-10) ═══════════════
  {
    slug: 'industrial-systems',
    family: 'custom',
    category: { ar: 'صناعي — حسب الطلب', en: 'Industrial — made to order' },
    name: { ar: 'أنظمة صناعية متكاملة', en: 'Integrated Industrial Systems' },
    tagline: { ar: 'نظام كامل، مسؤولية واحدة.', en: 'A whole system, one accountability.' },
    body: {
      ar: 'وحدات ومنظومات صناعية مجمّعة — تُصمَّم وتُصنَّع وتُركَّب كوحدة واحدة. بدل ما تجمّع من خمس موردين وتحكم بينهم لما حاجة تقع، فريق واحد مسؤول من الرسمة للتشغيل.',
      en: 'Skidded industrial systems — designed, fabricated and installed as one unit. Instead of assembling from five suppliers and refereeing the blame when something fails, one team is accountable from drawing to commissioning.',
    },
    images: [`${CL}/v1690703839/D11_c041140370.jpg`, `${CL}/v1727277073/1001727277048_3332398578.jpg`],
    facts: [
      { ar: 'تصميم · تصنيع · تركيب · تشغيل', en: 'Design · fabricate · install · commission' },
      { ar: 'استانلس 304 / 316 · كربوستيل', en: 'Stainless 304/316 · Carbon steel' },
    ],
    options: [
      { key: 'application', label: { ar: 'المجال', en: 'Application' }, kind: 'choice', values: [
        { ar: 'أغذية ومشروبات', en: 'Food & beverage' }, { ar: 'أدوية', en: 'Pharmaceutical' },
        { ar: 'كيماويات', en: 'Chemical' }, { ar: 'صناعة عامة', en: 'General industry' } ] },
      { key: 'material', label: { ar: 'الخامة', en: 'Material' }, kind: 'choice', values: MATERIALS.slice(0, 4) },
      { key: 'scope', label: { ar: 'نطاق العمل', en: 'Scope' }, kind: 'choice', values: [
        { ar: 'تصنيع فقط', en: 'Fabrication only' }, { ar: 'تصنيع + تركيب', en: 'Fabrication + install' }, { ar: 'تسليم مفتاح', en: 'Turnkey' } ] },
      { key: 'brief', label: { ar: 'وصف المطلوب', en: 'Describe the requirement' }, kind: 'free', hint: { ar: 'إيه الوظيفة المطلوبة من النظام؟', en: 'What does the system need to do?' } },
    ],
  },
  {
    slug: 'production-line-install',
    family: 'custom',
    category: { ar: 'صناعي — حسب الطلب', en: 'Industrial — made to order' },
    name: { ar: 'تركيب خطوط إنتاج', en: 'Production Line Installation' },
    tagline: { ar: 'من الصندوق للتشغيل.', en: 'From crate to commissioning.' },
    body: {
      ar: 'تركيب وربط خطوط الإنتاج — الميكانيكا والمواسير والقواعد والمنصات. فِرَق بتلتزم بنافذة التوقف، وبتسلّم الخط شغّال ومختبَر.',
      en: 'Installing and tying in production lines — mechanical, piping, bases and platforms. Crews that hit the shutdown window and hand over a line that runs, tested.',
    },
    images: [`${CL}/v1679738568/13_bfdd21487a.jpg`, `${CL}/v1727280275/1001727280248_392066eca4.jpg`],
    facts: [
      { ar: 'ميكانيكا · مواسير · قواعد · منصات', en: 'Mechanical · piping · bases · platforms' },
      { ar: 'أعمال إيقاف مخطّطة (Shutdown)', en: 'Planned shutdown work' },
    ],
    options: [
      { key: 'lineType', label: { ar: 'نوع الخط', en: 'Line type' }, kind: 'choice', values: [
        { ar: 'تعبئة', en: 'Filling' }, { ar: 'معالجة', en: 'Processing' }, { ar: 'تغليف', en: 'Packaging' }, { ar: 'أخرى', en: 'Other' } ] },
      { key: 'scope', label: { ar: 'المطلوب', en: 'Required' }, kind: 'choice', values: [
        { ar: 'تركيب فقط', en: 'Install only' }, { ar: 'تركيب + مواسير', en: 'Install + piping' }, { ar: 'تسليم مفتاح', en: 'Turnkey' } ] },
      { key: 'window', label: { ar: 'نافذة التنفيذ', en: 'Execution window' }, kind: 'free', hint: { ar: 'مثال: إيقاف 5 أيام', en: 'e.g. 5-day shutdown' } },
    ],
  },
  {
    slug: 'conveyors',
    family: 'custom',
    category: { ar: 'صناعي — حسب الطلب', en: 'Industrial — made to order' },
    name: { ar: 'سيور نقل', en: 'Conveyors' },
    tagline: { ar: 'حركة المنتج، بلا نقطة تلوّث.', en: 'Product movement, with nowhere to hide.' },
    body: {
      ar: 'سيور نقل صناعية وصحية — هياكل استانلس تتنضّف بالكامل، مصمّمة على المنتج والسرعة المطلوبة.',
      en: 'Industrial and sanitary conveyors — stainless frames that clean down completely, engineered around the product and the throughput.',
    },
    images: [`${CL}/v1727347849/1001727347766_02289cf612.jpg`],
    facts: [{ ar: 'استانلس 304 / 316 · هيكل صحي', en: 'Stainless 304/316 · sanitary frame' }],
    options: [
      { key: 'material', label: { ar: 'الخامة', en: 'Material' }, kind: 'choice', values: MATERIALS.slice(0, 3) },
      { key: 'length', label: { ar: 'الطول', en: 'Length' }, kind: 'free', hint: { ar: 'بالمتر', en: 'in metres' } },
      { key: 'width', label: { ar: 'العرض', en: 'Width' }, kind: 'free', hint: { ar: 'بالسنتيمتر', en: 'in cm' } },
      { key: 'product', label: { ar: 'المنتج المنقول', en: 'Product carried' }, kind: 'free', hint: { ar: 'إيه اللي هيتنقل عليه؟', en: 'What will it carry?' } },
    ],
  },
  {
    slug: 'heat-exchangers',
    family: 'custom',
    category: { ar: 'صناعي — حسب الطلب', en: 'Industrial — made to order' },
    name: { ar: 'مبادلات حرارية', en: 'Heat Exchangers' },
    tagline: { ar: 'مختبَرة بالضغط قبل ما تسيب المصنع.', en: 'Pressure-tested before they leave the floor.' },
    body: {
      ar: 'مبادلات حرارية وسربنتينات — تُصنَّع للخدمة الفعلية (الوسط والضغط والحرارة)، وتُختبَر بالضغط ويُوثَّق لحامها قبل التسليم.',
      en: 'Heat exchangers and coils — built for the actual duty (media, pressure, temperature), pressure-tested and weld-documented before handover.',
    },
    images: [`${CL}/v1679741318/IMG_20210429130536_ca4c934155.jpg`],
    facts: [
      { ar: 'استانلس 304 / 316', en: 'Stainless 304 / 316' },
      { ar: 'اختبار ضغط · فحص RT/PT', en: 'Pressure test · RT/PT inspection' },
    ],
    options: [
      { key: 'material', label: { ar: 'الخامة', en: 'Material' }, kind: 'choice', values: MATERIALS.slice(0, 3) },
      { key: 'duty', label: { ar: 'الخدمة', en: 'Duty' }, kind: 'free', hint: { ar: 'الوسط · الضغط · الحرارة', en: 'Media · pressure · temperature' } },
      { key: 'area', label: { ar: 'مساحة التبادل', en: 'Exchange area' }, kind: 'free', hint: { ar: 'م² (لو معروفة)', en: 'm² (if known)' } },
    ],
  },
  // ═══════════════ STOCK / STANDARD (10) ═══════════════
  {
    slug: 'sanitary-fittings',
    family: 'standard',
    category: { ar: 'مخزون — توريد', en: 'Stock — supply' },
    name: { ar: 'وصلات صحية', en: 'Sanitary Fittings' },
    tagline: { ar: 'على الرفوف، مش في انتظار استيراد.', en: 'On the racks, not on an import queue.' },
    body: {
      ar: 'أكواع وتيهات ومسلوب ولاكور وكلامبات — استانلس 304 و316 بمقاسات من ½ لـ 4 بوصة، متوفّرة من المخزون.',
      en: 'Elbows, tees, reducers, ferrules and clamps — stainless 304 and 316 from ½" to 4", available from stock.',
    },
    images: [`${CL}/v1679741596/IMG_20210408125130_1efce9c3ff.jpg`, `${CL}/v1726588066/kwe_astanls_styl_2_2_66e94e8f65.jpg`, `${CL}/v1725540465/ss_90_elbow_1_5in_2_a40a7415dd.jpg`],
    facts: [
      { ar: 'استانلس 304 / 316', en: 'Stainless 304 / 316' },
      { ar: 'مقاسات 12 · 19 · 25 · 32 · 38 · 51 مم وأكبر', en: 'Sizes 12 · 19 · 25 · 32 · 38 · 51 mm and up' },
    ],
    options: [
      { key: 'kind', label: { ar: 'النوع', en: 'Type' }, kind: 'choice', values: [
        { ar: 'كوع', en: 'Elbow' }, { ar: 'تيه', en: 'Tee' }, { ar: 'مسلوب', en: 'Reducer' },
        { ar: 'لاكور', en: 'Ferrule/union' }, { ar: 'كلامب', en: 'Clamp' }, { ar: 'طبة', en: 'End cap' } ] },
      { key: 'material', label: { ar: 'الخامة', en: 'Material' }, kind: 'choice', values: MATERIALS.slice(0, 2) },
      { key: 'size', label: { ar: 'المقاس', en: 'Size' }, kind: 'choice', values: [
        { ar: '12 مم', en: '12 mm' }, { ar: '19 مم', en: '19 mm' }, { ar: '25 مم', en: '25 mm' },
        { ar: '32 مم', en: '32 mm' }, { ar: '38 مم', en: '38 mm' }, { ar: '51 مم', en: '51 mm' } ] },
      { key: 'qty', label: { ar: 'الكمية', en: 'Quantity' }, kind: 'free', hint: { ar: 'عدد', en: 'pieces' } },
    ],
  },
  {
    slug: 'valves',
    family: 'standard',
    category: { ar: 'مخزون — توريد', en: 'Stock — supply' },
    name: { ar: 'محابس', en: 'Valves' },
    tagline: { ar: 'التحكم في الخط، من المخزون.', en: 'Line control, from stock.' },
    body: {
      ar: 'محابس صحية وصناعية — فراشة، كروية، وعدم رجوع — استانلس 304 و316، بمقاسات الخطوط الشائعة.',
      en: 'Sanitary and industrial valves — butterfly, ball and check — in stainless 304 and 316, in the common line sizes.',
    },
    images: [`${CL}/v1699015715/61_l_Hwwq6_PL_AC_SL_1500_7837f99710.jpg`, `${CL}/v1699015716/61df_D461_UNL_AC_SL_1500_68cb5ceb1f.jpg`],
    facts: [{ ar: 'استانلس 304 / 316', en: 'Stainless 304 / 316' }],
    options: [
      { key: 'kind', label: { ar: 'النوع', en: 'Type' }, kind: 'choice', values: [
        { ar: 'فراشة', en: 'Butterfly' }, { ar: 'كروي', en: 'Ball' }, { ar: 'عدم رجوع', en: 'Check' }, { ar: 'أخرى', en: 'Other' } ] },
      { key: 'material', label: { ar: 'الخامة', en: 'Material' }, kind: 'choice', values: MATERIALS.slice(0, 2) },
      { key: 'size', label: { ar: 'المقاس', en: 'Size' }, kind: 'free', hint: { ar: 'بوصة أو مم', en: 'inch or mm' } },
      { key: 'qty', label: { ar: 'الكمية', en: 'Quantity' }, kind: 'free', hint: { ar: 'عدد', en: 'pieces' } },
    ],
  },
  {
    slug: 'stainless-sheet',
    family: 'standard',
    category: { ar: 'مخزون — توريد', en: 'Stock — supply' },
    name: { ar: 'ألواح ولفائف استانلس', en: 'Stainless Sheet & Coil' },
    tagline: { ar: 'أكبر مخزون خامات في مصر.', en: 'The largest raw-material stock in Egypt.' },
    body: {
      ar: 'ألواح ولفائف استانلس — 304 و316 و201 — بأسماك من 1.25 لـ 15 مم، ومقاسات حتى 6×2.5 م. من المخزون، بلا انتظار توريد.',
      en: 'Stainless sheet and coil — 304, 316 and 201 — 1.25 to 15 mm, in sizes up to 6×2.5 m. From stock, with no import wait.',
    },
    images: [`${CL}/v1726587917/lwh_astanls_styl_2_3_14efa01603.jpg`, `${CL}/v1726564253/alwah_astanls_styl_2_ddaba8c2e0.jpg`],
    facts: [
      { ar: 'استانلس 304 / 316 / 201', en: 'Stainless 304 / 316 / 201' },
      { ar: 'أسماك 1.25 · 1.5 · 2 · 3 · 4 · 15 مم', en: 'Thickness 1.25 · 1.5 · 2 · 3 · 4 · 15 mm' },
      { ar: 'ألواح حتى 6 × 2.5 م', en: 'Sheets up to 6 × 2.5 m' },
    ],
    options: [
      { key: 'material', label: { ar: 'الخامة', en: 'Grade' }, kind: 'choice', values: MATERIALS.slice(0, 3) },
      { key: 'thickness', label: { ar: 'السُمك', en: 'Thickness' }, kind: 'choice', values: THICKNESS },
      { key: 'size', label: { ar: 'المقاس', en: 'Size' }, kind: 'free', hint: { ar: 'مثال: 2000×1000 مم', en: 'e.g. 2000×1000 mm' } },
      { key: 'finish', label: { ar: 'التشطيب', en: 'Finish' }, kind: 'choice', values: [
        { ar: '2B', en: '2B' }, { ar: 'No.4 (مصنفر)', en: 'No.4 (brushed)' }, { ar: 'مرآة', en: 'Mirror' } ] },
      { key: 'qty', label: { ar: 'الكمية', en: 'Quantity' }, kind: 'free', hint: { ar: 'عدد ألواح / طن', en: 'sheets / tonnes' } },
    ],
  },
  {
    slug: 'stainless-pipe',
    family: 'standard',
    category: { ar: 'مخزون — توريد', en: 'Stock — supply' },
    name: { ar: 'مواسير استانلس', en: 'Stainless Pipe & Tube' },
    tagline: { ar: 'صحية وصناعية، جاهزة.', en: 'Sanitary and industrial, ready.' },
    body: {
      ar: 'مواسير استانلس صحية وصناعية — 304 و316، بمقاسات الخطوط الشائعة، متوفّرة من المخزون للتصنيع أو التوريد.',
      en: 'Sanitary and industrial stainless pipe — 304 and 316, in the common line sizes, from stock for fabrication or supply.',
    },
    images: [`${CL}/v1726562924/mwasyr_astanls_styl_3_6fa64810ee.jpg`, `${CL}/v1727279288/1001727279247_5ee447b1b1.jpg`],
    facts: [{ ar: 'استانلس 304 / 316 · صحي وصناعي', en: 'Stainless 304 / 316 · sanitary & industrial' }],
    options: [
      { key: 'material', label: { ar: 'الخامة', en: 'Grade' }, kind: 'choice', values: MATERIALS.slice(0, 2) },
      { key: 'diameter', label: { ar: 'القطر', en: 'Diameter' }, kind: 'choice', values: [
        { ar: '½ بوصة', en: '½"' }, { ar: '1 بوصة', en: '1"' }, { ar: '1½ بوصة', en: '1½"' },
        { ar: '2 بوصة', en: '2"' }, { ar: '3 بوصة', en: '3"' }, { ar: '4 بوصة', en: '4"' } ] },
      { key: 'wall', label: { ar: 'سُمك الجدار', en: 'Wall thickness' }, kind: 'free', hint: { ar: 'مم أو Schedule', en: 'mm or schedule' } },
      { key: 'qty', label: { ar: 'الكمية', en: 'Quantity' }, kind: 'free', hint: { ar: 'متر طولي', en: 'linear metres' } },
    ],
  },
  {
    slug: 'flanges',
    family: 'standard',
    category: { ar: 'مخزون — توريد', en: 'Stock — supply' },
    name: { ar: 'فلنجات', en: 'Flanges' },
    tagline: { ar: 'وصلة محكمة، بمواصفة.', en: 'A tight joint, to spec.' },
    body: {
      ar: 'فلنجات استانلس وكربوستيل بالمقاسات والضغوط الشائعة — للخطوط الصناعية والصحية.',
      en: 'Stainless and carbon steel flanges in the common sizes and pressure classes — for industrial and sanitary lines.',
    },
    images: [`${CL}/v1679735631/Whats_App_Image_2021_07_01_at_11_03_04_AM_76e1e99efc.jpg`, `${CL}/v1705313325/Whats_App_Image_2024_01_15_at_9_51_02_AM_77ddf9300b.jpg`],
    facts: [{ ar: 'استانلس 304 / 316 · كربوستيل', en: 'Stainless 304/316 · Carbon steel' }],
    options: [
      { key: 'material', label: { ar: 'الخامة', en: 'Material' }, kind: 'choice', values: [MATERIALS[0], MATERIALS[1], MATERIALS[3]] },
      { key: 'size', label: { ar: 'المقاس', en: 'Size' }, kind: 'free', hint: { ar: 'بوصة', en: 'inch' } },
      { key: 'rating', label: { ar: 'درجة الضغط', en: 'Pressure class' }, kind: 'free', hint: { ar: 'مثال: 150# / PN16', en: 'e.g. 150# / PN16' } },
      { key: 'qty', label: { ar: 'الكمية', en: 'Quantity' }, kind: 'free', hint: { ar: 'عدد', en: 'pieces' } },
    ],
  },
  {
    slug: 'sections-bars',
    family: 'standard',
    category: { ar: 'مخزون — توريد', en: 'Stock — supply' },
    name: { ar: 'قطاعات وبارات', en: 'Sections & Bars' },
    tagline: { ar: 'مبروم، خوصة، زوايا — من الرف.', en: 'Round bar, flat bar, angle — off the rack.' },
    body: {
      ar: 'قطاعات استانلس — مبروم وخوصة وزوايا ومربعات — 304 و316، للتصنيع أو التوريد المباشر.',
      en: 'Stainless sections — round bar, flat bar, angle and square — 304 and 316, for fabrication or direct supply.',
    },
    images: [`${CL}/v1727279512/1001727279459_7bc15f7b52.jpg`, `${CL}/v1727346804/1001727346629_f273c9887b.jpg`],
    facts: [{ ar: 'استانلس 304 / 316 · مبروم · خوصة · زوايا', en: 'Stainless 304/316 · round · flat · angle' }],
    options: [
      { key: 'kind', label: { ar: 'النوع', en: 'Type' }, kind: 'choice', values: [
        { ar: 'مبروم (دائري)', en: 'Round bar' }, { ar: 'خوصة (مسطح)', en: 'Flat bar' },
        { ar: 'زاوية', en: 'Angle' }, { ar: 'مربع', en: 'Square' } ] },
      { key: 'material', label: { ar: 'الخامة', en: 'Grade' }, kind: 'choice', values: MATERIALS.slice(0, 3) },
      { key: 'size', label: { ar: 'المقاس', en: 'Size' }, kind: 'free', hint: { ar: 'مثال: قطر 20 مم', en: 'e.g. Ø20 mm' } },
      { key: 'qty', label: { ar: 'الكمية', en: 'Quantity' }, kind: 'free', hint: { ar: 'متر / عدد', en: 'metres / pieces' } },
    ],
  },
  {
    slug: 'fasteners',
    family: 'standard',
    category: { ar: 'مخزون — توريد', en: 'Stock — supply' },
    name: { ar: 'مسامير ومثبتات', en: 'Fasteners' },
    tagline: { ar: 'التفصيلة اللي بتوقف الخط.', en: 'The detail that stops a line.' },
    body: {
      ar: 'مسامير وصواميل وأسياخ قلاووظ استانلس — 304 و316 — بالمقاسات الشائعة، متوفّرة من المخزون.',
      en: 'Stainless bolts, nuts and threaded rod — 304 and 316 — in the common sizes, available from stock.',
    },
    images: [`${CL}/v1704963740/Threaded_Rod_1_e1a3cd6f85.jpg`, `${CL}/v1704964078/51_Jthx8e_PWL_AC_SL_1500_1e026cd9d5.jpg`],
    facts: [{ ar: 'استانلس 304 / 316', en: 'Stainless 304 / 316' }],
    options: [
      { key: 'kind', label: { ar: 'النوع', en: 'Type' }, kind: 'choice', values: [
        { ar: 'مسمار', en: 'Bolt' }, { ar: 'صامولة', en: 'Nut' }, { ar: 'سيخ قلاووظ', en: 'Threaded rod' }, { ar: 'وردة', en: 'Washer' } ] },
      { key: 'material', label: { ar: 'الخامة', en: 'Grade' }, kind: 'choice', values: MATERIALS.slice(0, 2) },
      { key: 'size', label: { ar: 'المقاس', en: 'Size' }, kind: 'free', hint: { ar: 'مثال: M10 × 50', en: 'e.g. M10 × 50' } },
      { key: 'qty', label: { ar: 'الكمية', en: 'Quantity' }, kind: 'free', hint: { ar: 'عدد', en: 'pieces' } },
    ],
  },
  {
    slug: 'stainless-shelving',
    family: 'standard',
    category: { ar: 'تجهيزات استانلس', en: 'Stainless fixtures' },
    name: { ar: 'أرفف واستاندات استانلس', en: 'Stainless Shelving & Stands' },
    tagline: { ar: 'تخزين يتغسل مع الخط.', en: 'Storage that washes down with the line.' },
    body: {
      ar: 'أرفف واستاندات استانلس لمصانع الأغذية والمخازن والمعامل — تتحمّل التنظيف اليومي، وبتتعمل بالمقاس اللي محتاجه.',
      en: 'Stainless shelving and stands for food plants, stores and laboratories — built for daily cleaning, made to the size you need.',
    },
    images: [`${CL}/v1727277073/1001727277048_3332398578.jpg`],
    facts: [
      { ar: 'استانلس 304 · استيل مدهون', en: 'Stainless 304 · painted steel' },
      { ar: 'مثال منفّذ: 245×92 سم، عمق 30، 6 أرفف', en: 'Built example: 245×92 cm, D30, 6 shelves' },
    ],
    options: [
      { key: 'material', label: { ar: 'الخامة', en: 'Material' }, kind: 'choice', values: [MATERIALS[0], MATERIALS[2], MATERIALS[4]] },
      { key: 'size', label: { ar: 'المقاس', en: 'Size' }, kind: 'free', hint: { ar: 'طول × عرض × عمق', en: 'L × W × D' } },
      { key: 'shelves', label: { ar: 'عدد الأرفف', en: 'Shelves' }, kind: 'choice', values: [
        { ar: '2', en: '2' }, { ar: '3', en: '3' }, { ar: '4', en: '4' }, { ar: '5 أو أكتر', en: '5 or more' } ] },
      { key: 'qty', label: { ar: 'الكمية', en: 'Quantity' }, kind: 'free', hint: { ar: 'عدد', en: 'units' } },
    ],
  },
  {
    slug: 'sinks-basins',
    family: 'standard',
    category: { ar: 'تجهيزات استانلس', en: 'Stainless fixtures' },
    name: { ar: 'أحواض استانلس', en: 'Stainless Sinks & Basins' },
    tagline: { ar: 'مصمّمة تتنضّف، مش تتشطف.', en: 'Designed to clean, not just to rinse.' },
    body: {
      ar: 'أحواض غسيل ومعالجة استانلس — لحام أملس بلا شقوق، وزوايا مدوّرة تتنضّف بالكامل. لمصانع الأغذية والمعامل.',
      en: 'Stainless wash and process basins — smooth crevice-free welds and radiused corners that clean down completely. For food plants and laboratories.',
    },
    images: [`${CL}/v1727280275/1001727280248_392066eca4.jpg`],
    facts: [
      { ar: 'استانلس 304 / 316', en: 'Stainless 304 / 316' },
      { ar: 'مثال منفّذ: 133×40 سم، عمق 25', en: 'Built example: 133×40 cm, D25' },
    ],
    options: [
      { key: 'material', label: { ar: 'الخامة', en: 'Material' }, kind: 'choice', values: MATERIALS.slice(0, 2) },
      { key: 'size', label: { ar: 'المقاس', en: 'Size' }, kind: 'free', hint: { ar: 'طول × عرض × عمق', en: 'L × W × D' } },
      { key: 'bowls', label: { ar: 'عدد الأحواض', en: 'Bowls' }, kind: 'choice', values: [
        { ar: 'واحد', en: 'One' }, { ar: 'اتنين', en: 'Two' }, { ar: 'تلاتة', en: 'Three' } ] },
    ],
  },
  {
    slug: 'covers-guards',
    family: 'standard',
    category: { ar: 'تجهيزات استانلس', en: 'Stainless fixtures' },
    name: { ar: 'أغطية وكفرات', en: 'Covers & Guards' },
    tagline: { ar: 'حماية المنتج وحماية الفريق.', en: 'Protecting the product and the crew.' },
    body: {
      ar: 'أغطية وكفرات استانلس للمعدات والخطوط — حماية للمنتج من التلوّث، وللعاملين من الأجزاء المتحرّكة.',
      en: 'Stainless covers and guards for equipment and lines — protecting product from contamination and people from moving parts.',
    },
    images: [`${CL}/v1727346804/1001727346629_f273c9887b.jpg`],
    facts: [
      { ar: 'استانلس 304 · سمك 1.5 مم (قياسي)', en: 'Stainless 304 · 1.5 mm (standard)' },
      { ar: 'مثال منفّذ: 180×76 سم', en: 'Built example: 180×76 cm' },
    ],
    options: [
      { key: 'material', label: { ar: 'الخامة', en: 'Material' }, kind: 'choice', values: MATERIALS.slice(0, 3) },
      { key: 'thickness', label: { ar: 'السُمك', en: 'Thickness' }, kind: 'choice', values: THICKNESS.slice(0, 4) },
      { key: 'size', label: { ar: 'المقاس', en: 'Size' }, kind: 'free', hint: { ar: 'طول × عرض', en: 'L × W' } },
    ],
  },
  {
    slug: 'handrails',
    family: 'standard',
    category: { ar: 'تجهيزات استانلس', en: 'Stainless fixtures' },
    name: { ar: 'هندريل ودرابزين', en: 'Handrails & Guardrails' },
    tagline: { ar: 'مطابق للاشتراطات، ومتشطّب.', en: 'Compliant, and finished properly.' },
    body: {
      ar: 'هندريل ودرابزين استانلس للسلالم والمنصات والممرات — مواسير 51 مم، لحام متشطّب ومصقول.',
      en: 'Stainless handrails and guardrails for stairs, platforms and walkways — 51 mm tube, welds dressed and polished.',
    },
    images: [`${CL}/v1679741303/IMG_20210215_135018_84aceb2c36.jpg`],
    facts: [{ ar: 'استانلس 304 · مواسير 51 مم', en: 'Stainless 304 · 51 mm tube' }],
    options: [
      { key: 'material', label: { ar: 'الخامة', en: 'Material' }, kind: 'choice', values: [MATERIALS[0], MATERIALS[1], MATERIALS[4]] },
      { key: 'length', label: { ar: 'الطول', en: 'Length' }, kind: 'free', hint: { ar: 'بالمتر', en: 'in metres' } },
      { key: 'rails', label: { ar: 'عدد المواسير', en: 'Rails' }, kind: 'choice', values: [
        { ar: 'ماسورة واحدة', en: 'Single rail' }, { ar: 'ماسورتين', en: 'Two rails' }, { ar: 'مع لوح قدم', en: 'With toe board' } ] },
    ],
  },
  {
    slug: 'filters-strainers',
    family: 'standard',
    category: { ar: 'تجهيزات استانلس', en: 'Stainless fixtures' },
    name: { ar: 'فلاتر ومصافي', en: 'Filters & Strainers' },
    tagline: { ar: 'اللي بيمسك اللي مالوش لازمة.', en: 'What catches what shouldn’t pass.' },
    body: {
      ar: 'فلاتر ومصافي وشبك استانلس — بمقاسات ودرجات ترشيح حسب الخط والمنتج.',
      en: 'Stainless filters, strainers and mesh — sized and rated to the line and the product.',
    },
    images: [`${CL}/v1727347650/1001727347539_d162feaf8a.jpg`],
    facts: [{ ar: 'استانلس 304 / 316 · شبك حسب الطلب', en: 'Stainless 304/316 · mesh to order' }],
    options: [
      { key: 'material', label: { ar: 'الخامة', en: 'Material' }, kind: 'choice', values: MATERIALS.slice(0, 2) },
      { key: 'diameter', label: { ar: 'القطر', en: 'Diameter' }, kind: 'free', hint: { ar: 'بالسنتيمتر', en: 'in cm' } },
      { key: 'mesh', label: { ar: 'درجة الترشيح', en: 'Filtration' }, kind: 'free', hint: { ar: 'ميكرون / مقاس الشبك', en: 'micron / mesh size' } },
    ],
  },
];

export const catalogPage = {
  eyebrow: { ar: 'الكتالوج', en: 'Catalogue' } as L,
  title: { ar: 'اللي بنصنّعه.', en: 'What we build.' } as L,
  intro: {
    ar: 'كل منتج هنا اتنفّذ فعلاً في مصنعنا. اختار المواصفات اللي محتاجها واطلب عرض سعر — المكتب الفني يراجعها ويرجعلك بنطاق وسعر.',
    en: 'Every product here has actually been built in our shop. Pick the specification you need and request a quote — the technical office reviews it and returns a scope and a price.',
  } as L,
  filters: {
    all: { ar: 'الكل', en: 'All' } as L,
    custom: { ar: 'صناعي — حسب الطلب', en: 'Industrial — made to order' } as L,
    standard: { ar: 'مخزون وتجهيزات', en: 'Stock & fixtures' } as L,
  },
  quoteCta: { ar: 'اطلب عرض سعر', en: 'Request a quote' } as L,
  optionsTitle: { ar: 'حدّد مواصفاتك', en: 'Specify what you need' } as L,
  factsTitle: { ar: 'المواصفات', en: 'Specifications' } as L,
  sendTitle: { ar: 'ابعت الطلب', en: 'Send request' } as L,
  backToCatalog: { ar: 'كل المنتجات', en: 'All products' } as L,
};
