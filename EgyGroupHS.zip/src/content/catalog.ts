// ============================================================================
// CATALOG — Master items (products) with their own option sets.
// Data sources (REAL, not invented):
//   • Specs/materials/thicknesses  → Namasoft ERP (InvItem, section IS0022 "Prod*")
//   • Images                       → Cloudinary library (recovered factory photos)
// Every master item = product + ITS OWN options → "Request a quote" (no fixed price).
// Two families:  'custom'  = industrial, made-to-order (configurator)
//                'standard'= catalogue product (spec sheet + enquiry)
// ============================================================================

export type L = { ar: string; en: string };

export type Option = {
  key: string;
  label: L;
  /** free = customer types a value (e.g. capacity); choice = pick from values */
  kind: 'choice' | 'free';
  values?: L[];
  hint?: L;
};

/** Hand-written search metadata. Falls back to name/body when absent. */
export type Seo = {
  /** <title> — lead with the term people actually type */
  title: L;
  /** meta description — a reason to click, not a keyword dump */
  desc: L;
  /** synonyms and spellings customers use (Arabic + transliterations) */
  terms?: string[];
};

export type MasterItem = {
  slug: string;
  seo?: Seo;
  family: 'custom' | 'standard';
  category: L;
  name: L;
  tagline: L;
  body: L;
  /** Cloudinary URLs — real factory photos */
  images: string[];
  options: Option[];
  /** real, verifiable spec lines pulled from ERP job history */
  facts?: L[];
};

const CL = 'https://res.cloudinary.com/djrskkszi/image/upload';

// Shared option value sets (materials/thicknesses are REAL — from Namasoft item classes)
const MATERIALS: L[] = [
  { ar: 'استانلس 304', en: 'Stainless 304' },
  { ar: 'استانلس 316', en: 'Stainless 316' },
  { ar: 'استانلس 201', en: 'Stainless 201' },
  { ar: 'كربوستيل', en: 'Carbon steel' },
  { ar: 'استيل مدهون', en: 'Painted steel' },
];

const THICKNESS: L[] = [
  { ar: '1.25 مم', en: '1.25 mm' },
  { ar: '1.5 مم', en: '1.5 mm' },
  { ar: '2 مم', en: '2 mm' },
  { ar: '3 مم', en: '3 mm' },
  { ar: '4 مم', en: '4 mm' },
  { ar: 'حسب التصميم', en: 'To design' },
];

/** Pipe sizing the way the trade orders it. */
const DN: L[] = [
  { ar: 'DN15 (½")', en: 'DN15 (½")' },
  { ar: 'DN20 (¾")', en: 'DN20 (¾")' },
  { ar: 'DN25 (1")', en: 'DN25 (1")' },
  { ar: 'DN32 (1¼")', en: 'DN32 (1¼")' },
  { ar: 'DN40 (1½")', en: 'DN40 (1½")' },
  { ar: 'DN50 (2")', en: 'DN50 (2")' },
  { ar: 'DN65 (2½")', en: 'DN65 (2½")' },
  { ar: 'DN80 (3")', en: 'DN80 (3")' },
  { ar: 'DN100 (4")', en: 'DN100 (4")' },
  { ar: 'أكبر', en: 'Larger' },
];

/** Wall thickness by schedule — the other half of a pipe spec. */
const SCHEDULE: L[] = [
  { ar: 'جدول 5S', en: 'Sch 5S' },
  { ar: 'جدول 10S', en: 'Sch 10S' },
  { ar: 'جدول 40', en: 'Sch 40' },
  { ar: 'جدول 80', en: 'Sch 80' },
  { ar: 'حسب المواصفة', en: 'To spec' },
];

/** Cold rolled vs hot rolled — decides surface and tolerance. */
const ROLLED: L[] = [
  { ar: 'بارد (Cold rolled)', en: 'Cold rolled' },
  { ar: 'ساخن (Hot rolled)', en: 'Hot rolled' },
];

/** Internal surface finish — the number the auditor asks for. */
const RA: L[] = [
  { ar: 'Ra ≤ 0.8 ميكرون (غذائي)', en: 'Ra ≤ 0.8 µm (food)' },
  { ar: 'Ra ≤ 0.4 ميكرون — مصقول (أدوية)', en: 'Ra ≤ 0.4 µm — polished (pharma)' },
  { ar: 'مرآة', en: 'Mirror' },
  { ar: 'صناعي عام', en: 'General industrial' },
];

/** Food-grade build: the alloy, finish and weld that let a machine touch food. */
const GRADE: L[] = [
  { ar: 'غذائي (Food grade)', en: 'Food grade' },
  { ar: 'صحي — أدوية', en: 'Sanitary — pharmaceutical' },
  { ar: 'صناعي عام', en: 'General industrial' },
];

/**
 * Welding processes on the floor.
 *
 * Back purging ("حقن") matters more than it sounds: without argon flooding the
 * bore, the root side of a stainless weld oxidises into chromium-oxide sugar.
 * That kills the corrosion resistance exactly where the product flows, leaves a
 * surface bacteria can colonise, and cannot be cleaned out afterwards.
 * On food and pharmaceutical work it isn't optional.
 */
const WELDING: L[] = [
  { ar: 'أوربيتال (صحي)', en: 'Orbital (sanitary)' },
  { ar: 'لحام حقن — TIG بأرجون داخلي', en: 'Back-purged TIG' },
  { ar: 'أرجون / TIG', en: 'Argon / TIG' },
  { ar: 'CO₂ / MAG', en: 'CO₂ / MAG' },
  { ar: 'ليزر', en: 'Laser' },
  { ar: 'حسب المواصفة', en: 'To spec' },
];

const FINISH: L[] = [
  { ar: 'تشطيب صناعي', en: 'Industrial finish' },
  { ar: 'تشطيب صحي (مصقول)', en: 'Sanitary (polished)' },
  { ar: 'مرآة', en: 'Mirror' },
];

// ---------------------------------------------------------------------------
// MASTER ITEMS
// ---------------------------------------------------------------------------
export const masterItems: MasterItem[] = [
  // ======================= 1. TANKS — the flagship =======================
  {
    slug: 'tanks',
    seo: {
      title: { ar: 'تنكات وخزانات استانلس — تصنيع تنكات في مصر | المجموعة المصرية', en: 'Stainless Steel Tanks & Vessels — Manufacturer in Egypt | Egyptian Group' },
      desc: { ar: 'تصنيع تنكات وخزانات استانلس 304 و316 — تخزين وخلط وضغط وصحية، للأغذية والأدوية والكيماويات. بالمقاس، بلحام مفحوص وتوثيق كامل. اطلب معاينة.', en: 'Stainless 304/316 tank and vessel fabrication — storage, mixing, pressure and sanitary, for food, pharma and chemicals. Made to size, inspected welds, full documentation.' },
      terms: ['تنكات', 'تنك', 'خزانات', 'خزان', 'تانك', 'تانكات', 'تصنيع تنكات', 'تنكات استانلس', 'خزانات استانلس', 'stainless tank', 'tank manufacturer egypt'],
    },
    family: 'custom',
    category: { ar: 'صناعي — حسب الطلب', en: 'Industrial — made to order' },
    name: { ar: 'تنكات وخزانات', en: 'Tanks & Vessels' },
    tagline: { ar: 'الجودة بتبدأ قبل أول لحام.', en: 'Quality starts before the first weld.' },
    body: {
      ar: 'بنصنّع كل أنواع التنكات — تخزين، خلط، ضغط، وصحية — للأغذية والأدوية والكيماويات والصناعات الثقيلة. قبل ما نقص أي صاج، بنفهم التنك هيشتغل في إيه، ونختار الخامة والسُمك والتصميم على الأساس ده. والتشطيب النهائي على مستوى عالمي: سطح يعدّي تدقيق النظافة، ويقاوم التآكل. ولأن الخامة موجودة عندنا وكل خطوة تحت سقف واحد — التنفيذ أسرع، التكلفة أقل، والجودة تحت سيطرتنا بالكامل.',
      en: 'We build every type of tank — storage, mixing, pressure and sanitary — for food, pharmaceutical, chemical and heavy industry. Before a single sheet is cut, we understand what the tank has to do, and choose the material, thickness and design around that. The finish is world-class: a surface that clears a hygiene audit and resists corrosion. And because the material is already on our racks and every stage sits under one roof, delivery is faster, cost is lower, and quality stays entirely under our control.',
    },
    images: [
      '/assets/tank-main.jpg',
      `${CL}/v1679734631/IMG_20210717_214715_bf071da224.jpg`,
      `${CL}/v1679741105/Whats_App_Image_2021_07_25_at_5_24_33_PM_960201b5ee.jpg`,
      `${CL}/v1683379935/M1_2ff820ec08.jpg`,
    ],
    facts: [
      { ar: 'لحام حقن على الوصلات الصحية — بلا أكسدة داخلية', en: 'Back-purged sanitary welds — no internal oxidation' },
      { ar: 'غذائي: سطوح 316 · تشطيب صحي · لحام بلا شقوق · قابل للـ CIP', en: 'Food grade: 316 contact surfaces · sanitary finish · crevice-free welds · CIP-ready' },
      { ar: 'تخزين · خلط · ضغط · صحي', en: 'Storage · Mixing · Pressure · Sanitary' },
      { ar: 'استانلس 304 / 316 · كربوستيل', en: 'Stainless 304 / 316 · Carbon steel' },
      { ar: 'أسماك من 1.5 إلى 4 مم حسب التصميم', en: 'Thickness 1.5–4 mm to design' },
      { ar: 'لحام مفحوص RT/PT · توثيق كامل', en: 'RT/PT inspected welds · full documentation' },
    ],
    options: [
      { key: 'grade', label: { ar: 'درجة التصنيع', en: 'Build grade' }, kind: 'choice', values: GRADE },
      {
        key: 'type',
        label: { ar: 'نوع التنك', en: 'Tank type' },
        kind: 'choice',
        values: [
          { ar: 'تخزين', en: 'Storage' },
          { ar: 'خلط / تقليب', en: 'Mixing' },
          { ar: 'ضغط', en: 'Pressure' },
          { ar: 'صحي (أغذية/أدوية)', en: 'Sanitary (food/pharma)' },
        ],
      },
      { key: 'material', label: { ar: 'الخامة', en: 'Material' }, kind: 'choice', values: MATERIALS.slice(0, 4) },
      { key: 'thickness', label: { ar: 'سُمك الصاج', en: 'Sheet thickness' }, kind: 'choice', values: THICKNESS },
      {
        key: 'capacity',
        label: { ar: 'السعة / المقاس', en: 'Capacity / size' },
        kind: 'free',
        hint: { ar: 'مثال: 5 م³ · أو قطر 150سم × ارتفاع 200سم', en: 'e.g. 5 m³ · or Ø150cm × H200cm' },
      },
      { key: 'finish', label: { ar: 'التشطيب', en: 'Finish' }, kind: 'choice', values: FINISH },
      {
        key: 'extras',
        label: { ar: 'إضافات', en: 'Add-ons' },
        kind: 'free',
        hint: { ar: 'بومبيه، غطاء، أرجل، مقلّب، جاكيت تبريد...', en: 'Dished end, lid, legs, agitator, cooling jacket…' },
      },
    ],
  },

  // ======================= 2. SANITARY PIPING =======================
  {
    slug: 'process-piping',
    seo: {
      title: { ar: 'خطوط مواسير استانلس — تصنيع وتركيب بلحام أوربيتال | المجموعة المصرية', en: 'Stainless Process Piping — Orbital Welded Lines | Egyptian Group' },
      desc: { ar: 'تصميم وتصنيع وتركيب خطوط مواسير صحية وصناعية — لحام أوربيتال 360°، فحص وتوثيق كل وصلة، واختبار بالموقع.', en: 'Sanitary and industrial process lines designed, fabricated, installed and tested — 360° orbital welding, every joint inspected and documented.' },
      terms: ['خطوط مواسير', 'خط مواسير', 'مواسير صحية', 'لحام أوربيتال', 'تركيب خطوط', 'process piping', 'orbital welding', 'sanitary piping'],
    },
    family: 'custom',
    category: { ar: 'صناعي — حسب الطلب', en: 'Industrial — made to order' },
    name: { ar: 'خطوط مواسير', en: 'Process Piping' },
    tagline: { ar: 'خط تقدر توثّق كل وصلة فيه.', en: 'A line where every joint is documented.' },
    body: {
      ar: 'خطوط مواسير صحية وصناعية — تُصمَّم وتُصنَّع وتُركَّب وتُختبَر بالموقع. اللحام الأوربيتال بيدّي وصلة متطابقة وقابلة للتكرار، خالية من الشقوق اللي المنتج يستقر فيها. وكل وصلة مفحوصة وموثّقة.',
      en: 'Sanitary and industrial process lines — designed, fabricated, installed and tested on site. Orbital welding gives an identical, repeatable joint with no crevices for product to sit in. Every weld inspected and documented.',
    },
    images: [`${CL}/v1704966153/TB_26j_Djf_O_Qn_BK_Nj_SZ_Fm_X_Xc_Ap_V_Xa_841968353_7ddf0c6203.jpg`, `${CL}/v1699872189/Stainless_Steel_Pipe_8_1f3669574f.jpg`, `${CL}/v1679738568/13_bfdd21487a.jpg`],
    facts: [
      { ar: 'لحام حقن (back purge): الوش الداخلي يفضل نضيف — من غيره الماسورة معيبة من جوّه', en: 'Back-purged welds: the root side stays clean — without it the bore is compromised' },
      { ar: 'لحام أوربيتال 360° · TIG · ليزر', en: 'Orbital 360° · TIG · Laser welding' },
      { ar: 'استانلس 304 / 316 · كربوستيل جدول 40', en: 'Stainless 304/316 · Carbon steel Sch 40' },
      { ar: 'يُركَّب ويُختبَر بالموقع', en: 'Installed and tested on site' },
    ],
    options: [
      { key: 'grade', label: { ar: 'درجة التصنيع', en: 'Build grade' }, kind: 'choice', values: GRADE },
      { key: 'material', label: { ar: 'الخامة', en: 'Material' }, kind: 'choice', values: MATERIALS.slice(0, 4) },
      { key: 'dn', label: { ar: 'المقاس (DN)', en: 'Size (DN)' }, kind: 'choice', values: DN },
      { key: 'welding', label: { ar: 'نوع اللحام', en: 'Welding' }, kind: 'choice', values: WELDING },
      { key: 'schedule', label: { ar: 'الجدول', en: 'Schedule' }, kind: 'choice', values: SCHEDULE },
      { key: 'length', label: { ar: 'الطول التقريبي', en: 'Approx. length' }, kind: 'free', hint: { ar: 'بالمتر', en: 'in metres' } },
      {
        key: 'scope',
        label: { ar: 'نطاق العمل', en: 'Scope' },
        kind: 'choice',
        values: [
          { ar: 'تصنيع فقط', en: 'Fabrication only' },
          { ar: 'تصنيع + تركيب', en: 'Fabrication + installation' },
          { ar: 'تسليم مفتاح', en: 'Turnkey' },
        ],
      },
    ],
  },

  // ======================= 3. STAINLESS TABLES (standard) =======================
  {
    slug: 'stainless-tables',
    seo: {
      title: { ar: 'ترابيزات استانلس — تصنيع بالمقاس للمصانع والمطابخ | المجموعة المصرية', en: 'Stainless Steel Tables — Made to Size | Egyptian Group' },
      desc: { ar: 'ترابيزات استانلس 304 لمصانع الأغذية والمعامل والمطابخ الصناعية — لحام أملس بلا شقوق، أرجل قابلة للضبط، سطح يتحمّل الغسيل اليومي. بالمقاس.', en: 'Stainless 304 tables for food plants, laboratories and industrial kitchens — smooth crevice-free welds, adjustable legs, built for daily wash-down.' },
      terms: ['ترابيزات استانلس', 'ترابيزة استانلس', 'ترابيزات مطابخ', 'ترابيزة عمل', 'ترابيزات مصانع', 'stainless table', 'work table'],
    },
    family: 'standard',
    category: { ar: 'تجهيزات استانلس', en: 'Stainless fixtures' },
    name: { ar: 'ترابيزات استانلس', en: 'Stainless Tables' },
    tagline: { ar: 'سطح شغل يتنضّف بالكامل.', en: 'A work surface that cleans down fully.' },
    body: {
      ar: 'ترابيزات استانلس لمصانع الأغذية والمعامل والمطابخ الصناعية — لحام أملس بلا شقوق، وأرجل قابلة للضبط، وسطح يتحمّل دورات الغسيل اليومية.',
      en: 'Stainless tables for food plants, laboratories and industrial kitchens — smooth crevice-free welds, adjustable legs, and a surface that stands up to daily wash-down.',
    },
    images: [`${CL}/v1726987847/erbt_astanls_styl_20724b113c.jpg`],
    facts: [
      { ar: 'استانلس 304 · سمك 1.5 مم (قياسي)', en: 'Stainless 304 · 1.5 mm (standard)' },
      { ar: 'مقاسات شائعة: 100×90 سم — وحسب الطلب', en: 'Common: 100×90 cm — or to order' },
    ],
    options: [
      { key: 'grade', label: { ar: 'درجة التصنيع', en: 'Build grade' }, kind: 'choice', values: GRADE },
      { key: 'material', label: { ar: 'الخامة', en: 'Material' }, kind: 'choice', values: MATERIALS.slice(0, 3) },
      { key: 'thickness', label: { ar: 'السُمك', en: 'Thickness' }, kind: 'choice', values: THICKNESS.slice(0, 4) },
      { key: 'size', label: { ar: 'المقاس', en: 'Size' }, kind: 'free', hint: { ar: 'مثال: 100×90 سم', en: 'e.g. 100×90 cm' } },
      {
        key: 'shelf',
        label: { ar: 'رف سفلي', en: 'Under-shelf' },
        kind: 'choice',
        values: [{ ar: 'بدون', en: 'None' }, { ar: 'رف واحد', en: 'One shelf' }, { ar: 'رفين', en: 'Two shelves' }],
      },
    ],
  },

  // ======================= 4. STAINLESS CHAIRS (standard) =======================
  {
    slug: 'stainless-chairs',
    family: 'standard',
    category: { ar: 'تجهيزات استانلس', en: 'Stainless fixtures' },
    name: { ar: 'كراسي استانلس', en: 'Stainless Chairs' },
    tagline: { ar: 'للبيئات اللي بتتغسل كل يوم.', en: 'For environments washed down daily.' },
    body: {
      ar: 'كراسي ومقاعد استانلس لخطوط الإنتاج والمعامل وغرف النظافة — بتقاوم التآكل ودورات التنظيف، ومصمّمة تتنضّف بالكامل.',
      en: 'Stainless chairs and stools for production lines, laboratories and clean rooms — corrosion-resistant, cleaning-cycle proof, and designed to clean down completely.',
    },
    images: [`${CL}/v1726578986/krsa_astanls_styl_2c8b64e552.jpg`, `${CL}/v1726580817/krsa_astanls_styl_1_ff6870a062.jpg`],
    facts: [{ ar: 'استانلس 304 / 201', en: 'Stainless 304 / 201' }],
    options: [
      { key: 'grade', label: { ar: 'درجة التصنيع', en: 'Build grade' }, kind: 'choice', values: GRADE },
      { key: 'material', label: { ar: 'الخامة', en: 'Material' }, kind: 'choice', values: MATERIALS.slice(0, 3) },
      {
        key: 'style',
        label: { ar: 'النوع', en: 'Type' },
        kind: 'choice',
        values: [
          { ar: 'كرسي بظهر', en: 'Chair with back' },
          { ar: 'تابوريه (بدون ظهر)', en: 'Stool (backless)' },
          { ar: 'قابل لضبط الارتفاع', en: 'Height-adjustable' },
        ],
      },
      { key: 'qty', label: { ar: 'الكمية', en: 'Quantity' }, kind: 'free', hint: { ar: 'عدد', en: 'pieces' } },
    ],
  },

  // ======================= 5. SAFETY LADDERS & STAIRS =======================
  {
    slug: 'ladders-stairs',
    seo: {
      title: { ar: 'سلالم سيفتي ودرج صناعي — تصنيع بالمقاس | المجموعة المصرية', en: 'Safety Ladders & Industrial Stairs — Made to Size | Egyptian Group' },
      desc: { ar: 'تصنيع سلالم سيفتي ودرج ومنصات وصول صناعية — درجات مانعة للانزلاق، هندريل مطابق للاشتراطات، محسوبة على الأحمال الفعلية للموقع.', en: 'Safety ladders, stairs and access platforms — anti-slip treads, compliant handrails, engineered to the real site loads.' },
      terms: ['سلالم سيفتي', 'سلم سيفتي', 'سلالم أمان', 'درج صناعي', 'سلالم مصانع', 'منصات وصول', 'safety ladder', 'industrial stairs'],
    },
    family: 'custom',
    category: { ar: 'صناعي — حسب الطلب', en: 'Industrial — made to order' },
    name: { ar: 'سلالم ودرج سيفتي', en: 'Safety Ladders & Stairs' },
    tagline: { ar: 'وصول آمن، مصنوع للمصنع.', en: 'Safe access, built for the plant.' },
    body: {
      ar: 'سلالم ودرج ومنصات وصول صناعية — بدرجات مانعة للانزلاق وهندريل مطابق للاشتراطات، محسوبة على الأحمال الفعلية للموقع.',
      en: 'Industrial ladders, stairs and access platforms — anti-slip treads and compliant handrails, engineered to the actual site loads.',
    },
    images: [`${CL}/v1679740196/3_e8c227ccf6.jpg`, `${CL}/v1679740219/1_ba4df86cf6.jpg`],
    facts: [
      { ar: 'استيل مدهون · استانلس 304', en: 'Painted steel · Stainless 304' },
      { ar: 'مثال منفّذ: 450×100 سم، ارتفاع 500 سم، 5 درجات', en: 'Built example: 450×100 cm, H 500 cm, 5 treads' },
    ],
    options: [
      { key: 'material', label: { ar: 'الخامة', en: 'Material' }, kind: 'choice', values: [MATERIALS[0], MATERIALS[4], MATERIALS[3]] },
      {
        key: 'kind',
        label: { ar: 'النوع', en: 'Type' },
        kind: 'choice',
        values: [
          { ar: 'سلم رأسي', en: 'Vertical ladder' },
          { ar: 'درج بدرجات', en: 'Stepped stairs' },
          { ar: 'منصة وصول', en: 'Access platform' },
        ],
      },
      { key: 'height', label: { ar: 'الارتفاع', en: 'Height' }, kind: 'free', hint: { ar: 'بالسنتيمتر', en: 'in cm' } },
      {
        key: 'handrail',
        label: { ar: 'هندريل', en: 'Handrail' },
        kind: 'choice',
        values: [{ ar: 'جانب واحد', en: 'One side' }, { ar: 'الجانبين', en: 'Both sides' }, { ar: 'بدون', en: 'None' }],
      },
    ],
  },

  // ======================= 6. PLATFORMS =======================
  {
    slug: 'platforms',
    family: 'custom',
    category: { ar: 'صناعي — حسب الطلب', en: 'Industrial — made to order' },
    name: { ar: 'منصات وقواعد', en: 'Platforms & Bases' },
    tagline: { ar: 'محسوبة على الحمل، مش على التخمين.', en: 'Engineered to the load, not to a guess.' },
    body: {
      ar: 'منصات عمل وقواعد ماكينات — تُحسب على الأحمال والاهتزاز الفعلي، وتُصنَّع بالسُمك المناسب للخدمة.',
      en: 'Work platforms and machine bases — calculated against real loads and vibration, fabricated at the right thickness for the duty.',
    },
    images: [`${CL}/v1679737824/2_719c6f812a.jpg`],
    facts: [{ ar: 'استيل · استانلس · أسماك حتى 15 مم', en: 'Steel · Stainless · up to 15 mm plate' }],
    options: [
      { key: 'material', label: { ar: 'الخامة', en: 'Material' }, kind: 'choice', values: MATERIALS },
      { key: 'size', label: { ar: 'المقاس', en: 'Size' }, kind: 'free', hint: { ar: 'طول × عرض × ارتفاع', en: 'L × W × H' } },
      { key: 'load', label: { ar: 'الحمل المتوقع', en: 'Expected load' }, kind: 'free', hint: { ar: 'كجم / طن', en: 'kg / tonnes' } },
    ],
  },

  // ═══════════════ INDUSTRIAL — MADE TO ORDER (7-10) ═══════════════
  {
    slug: 'industrial-systems',
    family: 'custom',
    category: { ar: 'صناعي — حسب الطلب', en: 'Industrial — made to order' },
    name: { ar: 'أنظمة صناعية متكاملة', en: 'Integrated Industrial Systems' },
    tagline: { ar: 'نظام كامل، مسؤولية واحدة.', en: 'A whole system, one accountability.' },
    body: {
      ar: 'وحدات ومنظومات صناعية مجمّعة — تُصمَّم وتُصنَّع وتُركَّب كوحدة واحدة. بدل ما تجمّع من خمس موردين وتحكم بينهم لما حاجة تقع، فريق واحد مسؤول من الرسمة للتشغيل.',
      en: 'Skidded industrial systems — designed, fabricated and installed as one unit. Instead of assembling from five suppliers and refereeing the blame when something fails, one team is accountable from drawing to commissioning.',
    },
    images: [`${CL}/v1690703839/D11_c041140370.jpg`, `${CL}/v1727277073/1001727277048_3332398578.jpg`],
    facts: [
      { ar: 'تصميم · تصنيع · تركيب · تشغيل', en: 'Design · fabricate · install · commission' },
      { ar: 'استانلس 304 / 316 · كربوستيل', en: 'Stainless 304/316 · Carbon steel' },
    ],
    options: [
      { key: 'grade', label: { ar: 'درجة التصنيع', en: 'Build grade' }, kind: 'choice', values: GRADE },
      { key: 'application', label: { ar: 'المجال', en: 'Application' }, kind: 'choice', values: [
        { ar: 'أغذية ومشروبات', en: 'Food & beverage' }, { ar: 'أدوية', en: 'Pharmaceutical' },
        { ar: 'كيماويات', en: 'Chemical' }, { ar: 'صناعة عامة', en: 'General industry' } ] },
      { key: 'material', label: { ar: 'الخامة', en: 'Material' }, kind: 'choice', values: MATERIALS.slice(0, 4) },
      { key: 'scope', label: { ar: 'نطاق العمل', en: 'Scope' }, kind: 'choice', values: [
        { ar: 'تصنيع فقط', en: 'Fabrication only' }, { ar: 'تصنيع + تركيب', en: 'Fabrication + install' }, { ar: 'تسليم مفتاح', en: 'Turnkey' } ] },
      { key: 'brief', label: { ar: 'وصف المطلوب', en: 'Describe the requirement' }, kind: 'free', hint: { ar: 'إيه الوظيفة المطلوبة من النظام؟', en: 'What does the system need to do?' } },
    ],
  },
  {
    slug: 'production-line-install',
    family: 'custom',
    category: { ar: 'صناعي — حسب الطلب', en: 'Industrial — made to order' },
    name: { ar: 'تركيب خطوط إنتاج', en: 'Production Line Installation' },
    tagline: { ar: 'من الصندوق للتشغيل.', en: 'From crate to commissioning.' },
    body: {
      ar: 'تركيب وربط خطوط الإنتاج — الميكانيكا والمواسير والقواعد والمنصات. فِرَق بتلتزم بنافذة التوقف، وبتسلّم الخط شغّال ومختبَر.',
      en: 'Installing and tying in production lines — mechanical, piping, bases and platforms. Crews that hit the shutdown window and hand over a line that runs, tested.',
    },
    images: [`${CL}/v1679738568/13_bfdd21487a.jpg`, `${CL}/v1727280275/1001727280248_392066eca4.jpg`],
    facts: [
      { ar: 'ميكانيكا · مواسير · قواعد · منصات', en: 'Mechanical · piping · bases · platforms' },
      { ar: 'أعمال إيقاف مخطّطة (Shutdown)', en: 'Planned shutdown work' },
    ],
    options: [
      { key: 'lineType', label: { ar: 'نوع الخط', en: 'Line type' }, kind: 'choice', values: [
        { ar: 'تعبئة', en: 'Filling' }, { ar: 'معالجة', en: 'Processing' }, { ar: 'تغليف', en: 'Packaging' }, { ar: 'أخرى', en: 'Other' } ] },
      { key: 'scope', label: { ar: 'المطلوب', en: 'Required' }, kind: 'choice', values: [
        { ar: 'تركيب فقط', en: 'Install only' }, { ar: 'تركيب + مواسير', en: 'Install + piping' }, { ar: 'تسليم مفتاح', en: 'Turnkey' } ] },
      { key: 'window', label: { ar: 'نافذة التنفيذ', en: 'Execution window' }, kind: 'free', hint: { ar: 'مثال: إيقاف 5 أيام', en: 'e.g. 5-day shutdown' } },
    ],
  },
  {
    slug: 'conveyors',
    family: 'custom',
    category: { ar: 'صناعي — حسب الطلب', en: 'Industrial — made to order' },
    name: { ar: 'سيور نقل', en: 'Conveyors' },
    tagline: { ar: 'حركة المنتج، بلا نقطة تلوّث.', en: 'Product movement, with nowhere to hide.' },
    body: {
      ar: 'سيور نقل صناعية وصحية — هياكل استانلس تتنضّف بالكامل، مصمّمة على المنتج والسرعة المطلوبة.',
      en: 'Industrial and sanitary conveyors — stainless frames that clean down completely, engineered around the product and the throughput.',
    },
    images: [`${CL}/v1727347849/1001727347766_02289cf612.jpg`],
    facts: [{ ar: 'استانلس 304 / 316 · هيكل صحي', en: 'Stainless 304/316 · sanitary frame' }],
    options: [
      { key: 'grade', label: { ar: 'درجة التصنيع', en: 'Build grade' }, kind: 'choice', values: GRADE },
      { key: 'material', label: { ar: 'الخامة', en: 'Material' }, kind: 'choice', values: MATERIALS.slice(0, 3) },
      { key: 'length', label: { ar: 'الطول', en: 'Length' }, kind: 'free', hint: { ar: 'بالمتر', en: 'in metres' } },
      { key: 'width', label: { ar: 'العرض', en: 'Width' }, kind: 'free', hint: { ar: 'بالسنتيمتر', en: 'in cm' } },
      { key: 'product', label: { ar: 'المنتج المنقول', en: 'Product carried' }, kind: 'free', hint: { ar: 'إيه اللي هيتنقل عليه؟', en: 'What will it carry?' } },
    ],
  },
  {
    slug: 'heat-exchangers',
    family: 'custom',
    category: { ar: 'صناعي — حسب الطلب', en: 'Industrial — made to order' },
    name: { ar: 'مبادلات حرارية', en: 'Heat Exchangers' },
    tagline: { ar: 'مختبَرة بالضغط قبل ما تسيب المصنع.', en: 'Pressure-tested before they leave the floor.' },
    body: {
      ar: 'مبادلات حرارية وسربنتينات — تُصنَّع للخدمة الفعلية (الوسط والضغط والحرارة)، وتُختبَر بالضغط ويُوثَّق لحامها قبل التسليم.',
      en: 'Heat exchangers and coils — built for the actual duty (media, pressure, temperature), pressure-tested and weld-documented before handover.',
    },
    images: [`${CL}/v1679741318/IMG_20210429130536_ca4c934155.jpg`],
    facts: [
      { ar: 'استانلس 304 / 316', en: 'Stainless 304 / 316' },
      { ar: 'اختبار ضغط · فحص RT/PT', en: 'Pressure test · RT/PT inspection' },
    ],
    options: [
      { key: 'grade', label: { ar: 'درجة التصنيع', en: 'Build grade' }, kind: 'choice', values: GRADE },
      { key: 'material', label: { ar: 'الخامة', en: 'Material' }, kind: 'choice', values: MATERIALS.slice(0, 3) },
      { key: 'duty', label: { ar: 'الخدمة', en: 'Duty' }, kind: 'free', hint: { ar: 'الوسط · الضغط · الحرارة', en: 'Media · pressure · temperature' } },
      { key: 'area', label: { ar: 'مساحة التبادل', en: 'Exchange area' }, kind: 'free', hint: { ar: 'م² (لو معروفة)', en: 'm² (if known)' } },
    ],
  },
  // ═══════════════ STOCK / STANDARD (10) ═══════════════
  {
    slug: 'sanitary-fittings',
    family: 'standard',
    category: { ar: 'مخزون — توريد', en: 'Stock — supply' },
    name: { ar: 'وصلات صحية', en: 'Sanitary Fittings' },
    tagline: { ar: 'على الرفوف، مش في انتظار استيراد.', en: 'On the racks, not on an import queue.' },
    body: {
      ar: 'أكواع وتيهات ومسلوب ولاكور وكلامبات — استانلس 304 و316 بمقاسات من ½ لـ 4 بوصة، متوفّرة من المخزون.',
      en: 'Elbows, tees, reducers, ferrules and clamps — stainless 304 and 316 from ½" to 4", available from stock.',
    },
    images: [`${CL}/v1726588066/kwe_astanls_styl_2_2_66e94e8f65.jpg`, `${CL}/v1725540465/ss_90_elbow_1_5in_2_a40a7415dd.jpg`, `${CL}/v1704965054/1529902395_Cap_9f71ae06af.jpg`],
    facts: [
      { ar: 'استانلس 304 / 316', en: 'Stainless 304 / 316' },
      { ar: 'مقاسات 12 · 19 · 25 · 32 · 38 · 51 مم وأكبر', en: 'Sizes 12 · 19 · 25 · 32 · 38 · 51 mm and up' },
    ],
    options: [
      { key: 'grade', label: { ar: 'درجة التصنيع', en: 'Build grade' }, kind: 'choice', values: GRADE },
      { key: 'kind', label: { ar: 'النوع', en: 'Type' }, kind: 'choice', values: [
        { ar: 'كوع', en: 'Elbow' }, { ar: 'تيه', en: 'Tee' }, { ar: 'مسلوب', en: 'Reducer' },
        { ar: 'لاكور', en: 'Ferrule/union' }, { ar: 'كلامب', en: 'Clamp' }, { ar: 'طبة', en: 'End cap' } ] },
      { key: 'material', label: { ar: 'الخامة', en: 'Material' }, kind: 'choice', values: MATERIALS.slice(0, 2) },
      { key: 'size', label: { ar: 'المقاس', en: 'Size' }, kind: 'choice', values: [
        { ar: '12 مم', en: '12 mm' }, { ar: '19 مم', en: '19 mm' }, { ar: '25 مم (DN25)', en: '25 mm (DN25)' },
        { ar: '32 مم (DN32)', en: '32 mm (DN32)' }, { ar: '38 مم (DN40)', en: '38 mm (DN40)' }, { ar: '51 مم (DN50)', en: '51 mm (DN50)' } ] },
      { key: 'qty', label: { ar: 'الكمية', en: 'Quantity' }, kind: 'free', hint: { ar: 'عدد', en: 'pieces' } },
    ],
  },
  {
    slug: 'valves',
    family: 'standard',
    category: { ar: 'مخزون — توريد', en: 'Stock — supply' },
    name: { ar: 'محابس', en: 'Valves' },
    tagline: { ar: 'التحكم في الخط، من المخزون.', en: 'Line control, from stock.' },
    body: {
      ar: 'محابس صحية وصناعية — فراشة، كروية، وعدم رجوع — استانلس 304 و316، بمقاسات الخطوط الشائعة.',
      en: 'Sanitary and industrial valves — butterfly, ball and check — in stainless 304 and 316, in the common line sizes.',
    },
    images: [`${CL}/v1726584996/mhbs_krt_astanls_styl_3_6ccd60e0af.jpg`, `${CL}/v1726581802/mhbs_krt_astanls_styl_3_1533e8d10c.jpg`, `${CL}/v1705136812/1_1_5_stainless_steel_gate_valve_01b_f5ad96559a.jpg`],
    facts: [{ ar: 'استانلس 304 / 316', en: 'Stainless 304 / 316' }],
    options: [
      { key: 'kind', label: { ar: 'النوع', en: 'Type' }, kind: 'choice', values: [
        { ar: 'فراشة', en: 'Butterfly' }, { ar: 'كروي', en: 'Ball' }, { ar: 'عدم رجوع', en: 'Check' }, { ar: 'أخرى', en: 'Other' } ] },
      { key: 'material', label: { ar: 'الخامة', en: 'Material' }, kind: 'choice', values: MATERIALS.slice(0, 2) },
      { key: 'size', label: { ar: 'المقاس', en: 'Size' }, kind: 'free', hint: { ar: 'بوصة أو مم', en: 'inch or mm' } },
      { key: 'qty', label: { ar: 'الكمية', en: 'Quantity' }, kind: 'free', hint: { ar: 'عدد', en: 'pieces' } },
    ],
  },
  {
    slug: 'stainless-sheet',
    family: 'standard',
    category: { ar: 'مخزون — توريد', en: 'Stock — supply' },
    name: { ar: 'ألواح ولفائف استانلس', en: 'Stainless Sheet & Coil' },
    tagline: { ar: 'أكبر مخزون خامات في مصر.', en: 'The largest raw-material stock in Egypt.' },
    body: {
      ar: 'ألواح ولفائف استانلس — 304 و316 و201 — بأسماك من 1.25 لـ 15 مم، ومقاسات حتى 6×2.5 م. من المخزون، بلا انتظار توريد.',
      en: 'Stainless sheet and coil — 304, 316 and 201 — 1.25 to 15 mm, in sizes up to 6×2.5 m. From stock, with no import wait.',
    },
    images: [`${CL}/v1726587917/lwh_astanls_styl_2_3_14efa01603.jpg`, `${CL}/v1726564253/alwah_astanls_styl_2_ddaba8c2e0.jpg`, `${CL}/v1699874448/Stainless_Steel_Coil_1_0ddf314193.jpg`],
    facts: [
      { ar: 'استانلس 304 / 316 / 201', en: 'Stainless 304 / 316 / 201' },
      { ar: 'أسماك 1.25 · 1.5 · 2 · 3 · 4 · 15 مم', en: 'Thickness 1.25 · 1.5 · 2 · 3 · 4 · 15 mm' },
      { ar: 'ألواح حتى 6 × 2.5 م', en: 'Sheets up to 6 × 2.5 m' },
    ],
    options: [
      { key: 'material', label: { ar: 'الخامة', en: 'Grade' }, kind: 'choice', values: MATERIALS.slice(0, 3) },
      { key: 'thickness', label: { ar: 'السُمك', en: 'Thickness' }, kind: 'choice', values: THICKNESS },
      { key: 'size', label: { ar: 'المقاس', en: 'Size' }, kind: 'free', hint: { ar: 'مثال: 2000×1000 مم', en: 'e.g. 2000×1000 mm' } },
      { key: 'rolled', label: { ar: 'بارد / ساخن', en: 'Cold / hot rolled' }, kind: 'choice', values: ROLLED },
      { key: 'finish', label: { ar: 'التشطيب', en: 'Finish' }, kind: 'choice', values: [
        { ar: '2B', en: '2B' }, { ar: 'No.4 (مصنفر)', en: 'No.4 (brushed)' }, { ar: 'مرآة', en: 'Mirror' } ] },
      { key: 'qty', label: { ar: 'الكمية', en: 'Quantity' }, kind: 'free', hint: { ar: 'عدد ألواح / طن', en: 'sheets / tonnes' } },
    ],
  },
  {
    slug: 'stainless-pipe',
    seo: {
      title: { ar: 'مواسير استانلس 304 و316 — توريد من المخزون | المجموعة المصرية', en: 'Stainless Steel Pipe & Tube 304/316 — From Stock | Egyptian Group' },
      desc: { ar: 'مواسير استانلس صحية وصناعية 304 و316 — من ½ لـ 4 بوصة وأكبر، متوفّرة من المخزون للتوريد أو التصنيع. أكبر مخزون خامات في مصر.', en: 'Sanitary and industrial stainless pipe in 304 and 316 — half-inch to 4-inch and larger, from stock for supply or fabrication. The largest raw-material stock in Egypt.' },
      terms: ['مواسير استانلس', 'ماسورة استانلس', 'مواسير 304', 'مواسير 316', 'مواسير صحية', 'مواسير صناعية', 'stainless pipe', 'stainless tube'],
    },
    family: 'standard',
    category: { ar: 'مخزون — توريد', en: 'Stock — supply' },
    name: { ar: 'مواسير استانلس', en: 'Stainless Pipe & Tube' },
    tagline: { ar: 'صحية وصناعية، جاهزة.', en: 'Sanitary and industrial, ready.' },
    body: {
      ar: 'مواسير استانلس صحية وصناعية — 304 و316، بمقاسات الخطوط الشائعة، متوفّرة من المخزون للتصنيع أو التوريد.',
      en: 'Sanitary and industrial stainless pipe — 304 and 316, in the common line sizes, from stock for fabrication or supply.',
    },
    images: [`${CL}/v1726562924/mwasyr_astanls_styl_3_6fa64810ee.jpg`, `${CL}/v1699872188/Stainless_Steel_Pipe_10_af008d0bcd.jpg`, `${CL}/v1699872188/Stainless_Steel_Pipe_11_ace6e00a29.jpg`],
    facts: [{ ar: 'استانلس 304 / 316 · صحي وصناعي', en: 'Stainless 304 / 316 · sanitary & industrial' }],
    options: [
      { key: 'material', label: { ar: 'الخامة', en: 'Grade' }, kind: 'choice', values: MATERIALS.slice(0, 2) },
      { key: 'dn', label: { ar: 'المقاس (DN)', en: 'Size (DN)' }, kind: 'choice', values: DN },
      { key: 'schedule', label: { ar: 'الجدول', en: 'Schedule' }, kind: 'choice', values: SCHEDULE },
      { key: 'qty', label: { ar: 'الكمية', en: 'Quantity' }, kind: 'free', hint: { ar: 'متر طولي', en: 'linear metres' } },
    ],
  },
  {
    slug: 'flanges',
    family: 'standard',
    category: { ar: 'مخزون — توريد', en: 'Stock — supply' },
    name: { ar: 'فلنجات', en: 'Flanges' },
    tagline: { ar: 'وصلة محكمة، بمواصفة.', en: 'A tight joint, to spec.' },
    body: {
      ar: 'فلنجات استانلس وكربوستيل بالمقاسات والضغوط الشائعة — للخطوط الصناعية والصحية.',
      en: 'Stainless and carbon steel flanges in the common sizes and pressure classes — for industrial and sanitary lines.',
    },
    images: [`${CL}/v1679735631/Whats_App_Image_2021_07_01_at_11_03_04_AM_76e1e99efc.jpg`, `${CL}/v1705313325/Whats_App_Image_2024_01_15_at_9_51_02_AM_77ddf9300b.jpg`],
    facts: [{ ar: 'استانلس 304 / 316 · كربوستيل', en: 'Stainless 304/316 · Carbon steel' }],
    options: [
      { key: 'material', label: { ar: 'الخامة', en: 'Material' }, kind: 'choice', values: [MATERIALS[0], MATERIALS[1], MATERIALS[3]] },
      { key: 'size', label: { ar: 'المقاس', en: 'Size' }, kind: 'free', hint: { ar: 'بوصة', en: 'inch' } },
      { key: 'rating', label: { ar: 'درجة الضغط', en: 'Pressure class' }, kind: 'free', hint: { ar: 'مثال: 150# / PN16', en: 'e.g. 150# / PN16' } },
      { key: 'qty', label: { ar: 'الكمية', en: 'Quantity' }, kind: 'free', hint: { ar: 'عدد', en: 'pieces' } },
    ],
  },
  {
    slug: 'sections-bars',
    family: 'standard',
    category: { ar: 'مخزون — توريد', en: 'Stock — supply' },
    name: { ar: 'قطاعات وبارات', en: 'Sections & Bars' },
    tagline: { ar: 'مبروم، خوصة، زوايا — من الرف.', en: 'Round bar, flat bar, angle — off the rack.' },
    body: {
      ar: 'قطاعات استانلس — مبروم وخوصة وزوايا ومربعات — 304 و316، للتصنيع أو التوريد المباشر.',
      en: 'Stainless sections — round bar, flat bar, angle and square — 304 and 316, for fabrication or direct supply.',
    },
    images: [`${CL}/v1727279512/1001727279459_7bc15f7b52.jpg`, `${CL}/v1727346804/1001727346629_f273c9887b.jpg`],
    facts: [{ ar: 'استانلس 304 / 316 · مبروم · خوصة · زوايا', en: 'Stainless 304/316 · round · flat · angle' }],
    options: [
      { key: 'kind', label: { ar: 'النوع', en: 'Type' }, kind: 'choice', values: [
        { ar: 'مبروم (دائري)', en: 'Round bar' }, { ar: 'خوصة (مسطح)', en: 'Flat bar' },
        { ar: 'زاوية', en: 'Angle' }, { ar: 'مربع', en: 'Square' } ] },
      { key: 'material', label: { ar: 'الخامة', en: 'Grade' }, kind: 'choice', values: MATERIALS.slice(0, 3) },
      { key: 'size', label: { ar: 'المقاس', en: 'Size' }, kind: 'free', hint: { ar: 'مثال: قطر 20 مم', en: 'e.g. Ø20 mm' } },
      { key: 'qty', label: { ar: 'الكمية', en: 'Quantity' }, kind: 'free', hint: { ar: 'متر / عدد', en: 'metres / pieces' } },
    ],
  },
  {
    slug: 'fasteners',
    family: 'standard',
    category: { ar: 'مخزون — توريد', en: 'Stock — supply' },
    name: { ar: 'مسامير ومثبتات', en: 'Fasteners' },
    tagline: { ar: 'التفصيلة اللي بتوقف الخط.', en: 'The detail that stops a line.' },
    body: {
      ar: 'مسامير وصواميل وأسياخ قلاووظ استانلس — 304 و316 — بالمقاسات الشائعة، متوفّرة من المخزون.',
      en: 'Stainless bolts, nuts and threaded rod — 304 and 316 — in the common sizes, available from stock.',
    },
    images: [`${CL}/v1704963740/Threaded_Rod_1_e1a3cd6f85.jpg`],
    facts: [{ ar: 'استانلس 304 / 316', en: 'Stainless 304 / 316' }],
    options: [
      { key: 'kind', label: { ar: 'النوع', en: 'Type' }, kind: 'choice', values: [
        { ar: 'مسمار', en: 'Bolt' }, { ar: 'صامولة', en: 'Nut' }, { ar: 'سيخ قلاووظ', en: 'Threaded rod' }, { ar: 'وردة', en: 'Washer' } ] },
      { key: 'material', label: { ar: 'الخامة', en: 'Grade' }, kind: 'choice', values: MATERIALS.slice(0, 2) },
      { key: 'size', label: { ar: 'المقاس', en: 'Size' }, kind: 'free', hint: { ar: 'مثال: M10 × 50', en: 'e.g. M10 × 50' } },
      { key: 'qty', label: { ar: 'الكمية', en: 'Quantity' }, kind: 'free', hint: { ar: 'عدد', en: 'pieces' } },
    ],
  },
  {
    slug: 'stainless-shelving',
    family: 'standard',
    category: { ar: 'تجهيزات استانلس', en: 'Stainless fixtures' },
    name: { ar: 'أرفف واستاندات استانلس', en: 'Stainless Shelving & Stands' },
    tagline: { ar: 'تخزين يتغسل مع الخط.', en: 'Storage that washes down with the line.' },
    body: {
      ar: 'أرفف واستاندات استانلس لمصانع الأغذية والمخازن والمعامل — تتحمّل التنظيف اليومي، وبتتعمل بالمقاس اللي محتاجه.',
      en: 'Stainless shelving and stands for food plants, stores and laboratories — built for daily cleaning, made to the size you need.',
    },
    images: [`${CL}/v1727277073/1001727277048_3332398578.jpg`],
    facts: [
      { ar: 'استانلس 304 · استيل مدهون', en: 'Stainless 304 · painted steel' },
      { ar: 'مثال منفّذ: 245×92 سم، عمق 30، 6 أرفف', en: 'Built example: 245×92 cm, D30, 6 shelves' },
    ],
    options: [
      { key: 'grade', label: { ar: 'درجة التصنيع', en: 'Build grade' }, kind: 'choice', values: GRADE },
      { key: 'material', label: { ar: 'الخامة', en: 'Material' }, kind: 'choice', values: [MATERIALS[0], MATERIALS[2], MATERIALS[4]] },
      { key: 'size', label: { ar: 'المقاس', en: 'Size' }, kind: 'free', hint: { ar: 'طول × عرض × عمق', en: 'L × W × D' } },
      { key: 'shelves', label: { ar: 'عدد الأرفف', en: 'Shelves' }, kind: 'choice', values: [
        { ar: '2', en: '2' }, { ar: '3', en: '3' }, { ar: '4', en: '4' }, { ar: '5 أو أكتر', en: '5 or more' } ] },
      { key: 'qty', label: { ar: 'الكمية', en: 'Quantity' }, kind: 'free', hint: { ar: 'عدد', en: 'units' } },
    ],
  },
  {
    slug: 'sinks-basins',
    family: 'standard',
    category: { ar: 'تجهيزات استانلس', en: 'Stainless fixtures' },
    name: { ar: 'أحواض استانلس', en: 'Stainless Sinks & Basins' },
    tagline: { ar: 'مصمّمة تتنضّف، مش تتشطف.', en: 'Designed to clean, not just to rinse.' },
    body: {
      ar: 'أحواض غسيل ومعالجة استانلس — لحام أملس بلا شقوق، وزوايا مدوّرة تتنضّف بالكامل. لمصانع الأغذية والمعامل.',
      en: 'Stainless wash and process basins — smooth crevice-free welds and radiused corners that clean down completely. For food plants and laboratories.',
    },
    images: [`${CL}/v1727280275/1001727280248_392066eca4.jpg`],
    facts: [
      { ar: 'استانلس 304 / 316', en: 'Stainless 304 / 316' },
      { ar: 'مثال منفّذ: 133×40 سم، عمق 25', en: 'Built example: 133×40 cm, D25' },
    ],
    options: [
      { key: 'grade', label: { ar: 'درجة التصنيع', en: 'Build grade' }, kind: 'choice', values: GRADE },
      { key: 'material', label: { ar: 'الخامة', en: 'Material' }, kind: 'choice', values: MATERIALS.slice(0, 2) },
      { key: 'size', label: { ar: 'المقاس', en: 'Size' }, kind: 'free', hint: { ar: 'طول × عرض × عمق', en: 'L × W × D' } },
      { key: 'bowls', label: { ar: 'عدد الأحواض', en: 'Bowls' }, kind: 'choice', values: [
        { ar: 'واحد', en: 'One' }, { ar: 'اتنين', en: 'Two' }, { ar: 'تلاتة', en: 'Three' } ] },
    ],
  },
  {
    slug: 'covers-guards',
    family: 'standard',
    category: { ar: 'تجهيزات استانلس', en: 'Stainless fixtures' },
    name: { ar: 'أغطية وكفرات', en: 'Covers & Guards' },
    tagline: { ar: 'حماية المنتج وحماية الفريق.', en: 'Protecting the product and the crew.' },
    body: {
      ar: 'أغطية وكفرات استانلس للمعدات والخطوط — حماية للمنتج من التلوّث، وللعاملين من الأجزاء المتحرّكة.',
      en: 'Stainless covers and guards for equipment and lines — protecting product from contamination and people from moving parts.',
    },
    images: [`${CL}/v1727346804/1001727346629_f273c9887b.jpg`],
    facts: [
      { ar: 'استانلس 304 · سمك 1.5 مم (قياسي)', en: 'Stainless 304 · 1.5 mm (standard)' },
      { ar: 'مثال منفّذ: 180×76 سم', en: 'Built example: 180×76 cm' },
    ],
    options: [
      { key: 'material', label: { ar: 'الخامة', en: 'Material' }, kind: 'choice', values: MATERIALS.slice(0, 3) },
      { key: 'thickness', label: { ar: 'السُمك', en: 'Thickness' }, kind: 'choice', values: THICKNESS.slice(0, 4) },
      { key: 'size', label: { ar: 'المقاس', en: 'Size' }, kind: 'free', hint: { ar: 'طول × عرض', en: 'L × W' } },
    ],
  },
  {
    slug: 'handrails',
    family: 'standard',
    category: { ar: 'تجهيزات استانلس', en: 'Stainless fixtures' },
    name: { ar: 'هندريل ودرابزين', en: 'Handrails & Guardrails' },
    tagline: { ar: 'مطابق للاشتراطات، ومتشطّب.', en: 'Compliant, and finished properly.' },
    body: {
      ar: 'هندريل ودرابزين استانلس للسلالم والمنصات والممرات — مواسير 51 مم، لحام متشطّب ومصقول.',
      en: 'Stainless handrails and guardrails for stairs, platforms and walkways — 51 mm tube, welds dressed and polished.',
    },
    images: [`${CL}/v1679741303/IMG_20210215_135018_84aceb2c36.jpg`],
    facts: [{ ar: 'استانلس 304 · مواسير 51 مم', en: 'Stainless 304 · 51 mm tube' }],
    options: [
      { key: 'material', label: { ar: 'الخامة', en: 'Material' }, kind: 'choice', values: [MATERIALS[0], MATERIALS[1], MATERIALS[4]] },
      { key: 'length', label: { ar: 'الطول', en: 'Length' }, kind: 'free', hint: { ar: 'بالمتر', en: 'in metres' } },
      { key: 'rails', label: { ar: 'عدد المواسير', en: 'Rails' }, kind: 'choice', values: [
        { ar: 'ماسورة واحدة', en: 'Single rail' }, { ar: 'ماسورتين', en: 'Two rails' }, { ar: 'مع لوح قدم', en: 'With toe board' } ] },
    ],
  },
  {
    slug: 'filters-strainers',
    family: 'standard',
    category: { ar: 'تجهيزات استانلس', en: 'Stainless fixtures' },
    name: { ar: 'فلاتر ومصافي', en: 'Filters & Strainers' },
    tagline: { ar: 'اللي بيمسك اللي مالوش لازمة.', en: 'What catches what shouldn’t pass.' },
    body: {
      ar: 'فلاتر ومصافي وشبك استانلس — بمقاسات ودرجات ترشيح حسب الخط والمنتج.',
      en: 'Stainless filters, strainers and mesh — sized and rated to the line and the product.',
    },
    images: [`${CL}/v1727347650/1001727347539_d162feaf8a.jpg`],
    facts: [{ ar: 'استانلس 304 / 316 · شبك حسب الطلب', en: 'Stainless 304/316 · mesh to order' }],
    options: [
      { key: 'material', label: { ar: 'الخامة', en: 'Material' }, kind: 'choice', values: MATERIALS.slice(0, 2) },
      { key: 'diameter', label: { ar: 'القطر', en: 'Diameter' }, kind: 'free', hint: { ar: 'بالسنتيمتر', en: 'in cm' } },
      { key: 'mesh', label: { ar: 'درجة الترشيح', en: 'Filtration' }, kind: 'free', hint: { ar: 'ميكرون / مقاس الشبك', en: 'micron / mesh size' } },
    ],
  },

  // ═══════════ SEO-TARGETED: terms customers actually search ═══════════
  {
    slug: 'double-jacketed-tanks',
    seo: {
      title: { ar: 'تنك دبل جاكت — تصنيع تنكات دبل جاكتيد استانلس | المجموعة المصرية', en: 'Double Jacketed Tanks — Steam & Water Jacketed Vessels | Egyptian Group' },
      desc: { ar: 'تصنيع تنكات دبل جاكت (double jacketed) للشيكولاتة والصلصة والألبان — جاكت بخار أو مياه ساخنة أو مثلجة، جاكت كامل أو هاف بايب، استانلس 304/316 باختبار ضغط موثّق.', en: 'Double jacketed tank fabrication for chocolate, sauces and dairy — steam, hot-water or chilled jackets, full jacket or half-pipe coil, stainless 304/316, pressure-tested.' },
      terms: ['دبل جاكت', 'دبل جاكتيد', 'تنك دبل جاكت', 'خزان دبل جاكت', 'double jacketed', 'double jacket tank', 'جاكت بخار', 'هاف بايب', 'نص جاكت'],
    },
    family: 'custom',
    category: { ar: 'صناعي — حسب الطلب', en: 'Industrial — made to order' },
    name: { ar: 'تنكات دبل جاكت', en: 'Double Jacketed Tanks' },
    tagline: { ar: 'تسخين وتبريد في نفس الجسم.', en: 'Heating and cooling in the same shell.' },
    body: {
      ar: 'تنك دبل جاكت (double jacketed) هو تنك بجدار مزدوج — الوسط الحراري بيمشي في الجاكت الخارجي، والمنتج جوه. بنصنّع الدبل جاكت للشيكولاتة والصلصة والألبان والمربى والكيماويات — بجاكت بخار أو مياه ساخنة أو مياه مثلجة، بحسب المطلوب. الجاكت بيتصمّم على ضغط التشغيل ودرجة الحرارة، وبيتختبر بالضغط ويُوثَّق قبل التسليم. الخيارات: جاكت كامل، جاكت نص، أو هاف بايب (half-pipe coil) للضغوط العالية — وممكن يتعمل بعزل حراري وتغليف استانلس.',
      en: 'A double jacketed tank has a twin wall — the heating or cooling medium runs in the outer jacket, the product sits inside. We build double jacketed vessels for chocolate, sauces, dairy, jam and chemicals — steam, hot-water or chilled-water jacket to suit. The jacket is designed to the working pressure and temperature, pressure-tested and documented before handover. Options: full jacket, half jacket, or half-pipe coil for higher pressures — with thermal insulation and a stainless cladding if needed.',
    },
    images: [`${CL}/v1679734631/IMG_20210717_214715_bf071da224.jpg`, `${CL}/v1683379935/M1_2ff820ec08.jpg`],
    facts: [
      { ar: 'جاكت بخار · مياه ساخنة · مياه مثلجة', en: 'Steam · hot water · chilled water jacket' },
      { ar: 'جاكت كامل · نص جاكت · هاف بايب', en: 'Full jacket · half jacket · half-pipe coil' },
      { ar: 'استانلس 304 / 316 · اختبار ضغط موثّق', en: 'Stainless 304/316 · documented pressure test' },
      { ar: 'عزل حراري وتغليف استانلس (اختياري)', en: 'Thermal insulation and stainless cladding (optional)' },
    ],
    options: [
      { key: 'medium', label: { ar: 'وسط الجاكت', en: 'Jacket medium' }, kind: 'choice', values: [
        { ar: 'بخار', en: 'Steam' }, { ar: 'مياه ساخنة', en: 'Hot water' },
        { ar: 'مياه مثلجة', en: 'Chilled water' }, { ar: 'زيت حراري', en: 'Thermal oil' } ] },
      { key: 'jacket', label: { ar: 'نوع الجاكت', en: 'Jacket type' }, kind: 'choice', values: [
        { ar: 'جاكت كامل', en: 'Full jacket' }, { ar: 'نص جاكت', en: 'Half jacket' }, { ar: 'هاف بايب', en: 'Half-pipe coil' } ] },
      { key: 'product', label: { ar: 'المنتج جوه التنك', en: 'Product inside' }, kind: 'free', hint: { ar: 'شيكولاتة، صلصة، ألبان…', en: 'Chocolate, sauce, dairy…' } },
      { key: 'capacity', label: { ar: 'السعة', en: 'Capacity' }, kind: 'free', hint: { ar: 'مثال: 2 م³', en: 'e.g. 2 m³' } },
      { key: 'material', label: { ar: 'الخامة', en: 'Material' }, kind: 'choice', values: MATERIALS.slice(0, 2) },
      { key: 'extras', label: { ar: 'إضافات', en: 'Add-ons' }, kind: 'free', hint: { ar: 'مقلّب، عزل، حساس حرارة…', en: 'Agitator, insulation, temperature probe…' } },
    ],
  },
  {
    slug: 'chocolate-lines',
    seo: {
      title: { ar: 'خطوط شيكولاتة — تصنيع وتركيب خطوط الشيكولاتة | المجموعة المصرية', en: 'Chocolate Processing Lines — Jacketed Tanks & Pipework | Egyptian Group' },
      desc: { ar: 'تصنيع وتركيب خطوط شيكولاتة كاملة — تنكات دبل جاكت بتقليب، مواسير مجاكتة تحافظ على الحرارة، لحام أوربيتال صحي، وميول محسوبة للتفريغ الكامل.', en: 'Complete chocolate lines — double jacketed tanks with agitation, temperature-holding jacketed pipework, sanitary orbital welds, and falls calculated for full drainage.' },
      terms: ['خطوط شيكولاتة', 'خط شيكولاتة', 'خطوط الشيكولاته', 'مصنع شيكولاتة', 'تنك شيكولاتة', 'مواسير مجاكتة', 'chocolate line', 'chocolate tank'],
    },
    family: 'custom',
    category: { ar: 'صناعي — حسب الطلب', en: 'Industrial — made to order' },
    name: { ar: 'خطوط شيكولاتة', en: 'Chocolate Lines' },
    tagline: { ar: 'خط بيمشي سخن، وبيتنضّف بالكامل.', en: 'A line that runs warm and cleans out fully.' },
    body: {
      ar: 'خطوط شيكولاتة كاملة — تنكات دبل جاكت مع تقليب، ومواسير مجاكتة تحافظ على درجة الحرارة على طول الخط، وبمبات ومصافي وصمامات صحية. الشيكولاتة بتحتاج حرارة ثابتة: أي نقطة باردة في الخط بتتجمّد وتسدّ. عشان كده كل ماسورة بتتعمل بجاكت أو تريس، والميول بتتحسب عشان الخط يفضى بالكامل. اللحام أوربيتال صحي بلا شقوق — عشان الغسيل يوصل لكل نقطة، ومفيش دهون بتستقر في وصلة.',
      en: 'Complete chocolate lines — double jacketed tanks with agitation, jacketed pipework that holds temperature the whole way, plus sanitary pumps, strainers and valves. Chocolate needs a steady temperature: one cold spot and the line sets solid and blocks. So every run is jacketed or traced, and falls are calculated so the line drains completely. Welds are sanitary orbital and crevice-free — so the wash reaches everywhere and no fat sits in a joint.',
    },
    images: [`${CL}/v1679738568/13_bfdd21487a.jpg`, `${CL}/v1679738739/14_2533049ffb.jpg`],
    facts: [
      { ar: 'تنكات دبل جاكت + مواسير مجاكتة', en: 'Double jacketed tanks + jacketed pipework' },
      { ar: 'لحام أوربيتال صحي · بلا شقوق', en: 'Sanitary orbital welds · crevice-free' },
      { ar: 'ميول محسوبة للتفريغ الكامل', en: 'Calculated falls for full drainage' },
      { ar: 'استانلس 304 / 316', en: 'Stainless 304 / 316' },
    ],
    options: [
      { key: 'scope', label: { ar: 'المطلوب', en: 'Scope' }, kind: 'choice', values: [
        { ar: 'خط كامل', en: 'Complete line' }, { ar: 'تنكات بس', en: 'Tanks only' },
        { ar: 'مواسير بس', en: 'Pipework only' }, { ar: 'توسعة خط قائم', en: 'Extend an existing line' } ] },
      { key: 'heating', label: { ar: 'التسخين', en: 'Heating' }, kind: 'choice', values: [
        { ar: 'مياه ساخنة', en: 'Hot water' }, { ar: 'بخار', en: 'Steam' }, { ar: 'تريس كهربائي', en: 'Electric trace' } ] },
      { key: 'capacity', label: { ar: 'الإنتاجية', en: 'Throughput' }, kind: 'free', hint: { ar: 'كجم/ساعة أو طن/يوم', en: 'kg/h or tonnes/day' } },
      { key: 'brief', label: { ar: 'وصف الخط', en: 'Describe the line' }, kind: 'free', hint: { ar: 'من فين لفين؟ فيه إيه؟', en: 'From where to where? What is on it?' } },
    ],
  },
  {
    slug: 'boiler-connections',
    seo: {
      title: { ar: 'توصيل غلايات وخطوط بخار — تركيب وصيانة | المجموعة المصرية', en: 'Boiler Connections & Steam Piping — Installation | Egyptian Group' },
      desc: { ar: 'توصيل الغلايات وخطوط البخار والكوندنسيت — مواسير وفلنجات ومصائد بضغط مناسب، حساب التمدد الحراري والشدادات، وفحص لحام موثّق قبل التشغيل.', en: 'Boiler hook-ups, steam mains and condensate return — pressure-rated pipe, flanges and traps, thermal expansion and supports calculated, welds inspected before start-up.' },
      terms: ['توصيل غلايات', 'غلايات', 'غلاية', 'خطوط بخار', 'خط بخار', 'كوندنسيت', 'مصائد بخار', 'boiler connection', 'steam piping', 'steam line'],
    },
    family: 'custom',
    category: { ar: 'صناعي — حسب الطلب', en: 'Industrial — made to order' },
    name: { ar: 'توصيل غلايات', en: 'Boiler Connections' },
    tagline: { ar: 'بخار موصّل صح من أول يوم.', en: 'Steam piped right, from day one.' },
    body: {
      ar: 'توصيل الغلايات وخطوط البخار والكوندنسيت — من الغلاية للخط للماكينة. الشغل ده مالوش هامش خطأ: الضغط عالي، والحرارة عالية، وأي وصلة ضعيفة بتبقى خطر على اللي واقف جنبها. بنعمل الخط بالمواسير والفلنجات والمصائد والصمامات المناسبة للضغط، ونحسب التمدد الحراري ونحط الشدادات في مكانها، ونعزل الخط. واللحام بيتفحص ويتوثّق قبل التشغيل.',
      en: 'Boiler hook-ups, steam mains and condensate return — from boiler to line to machine. There is no margin here: high pressure, high temperature, and a weak joint is a danger to whoever stands next to it. We build with pipe, flanges, traps and valves rated for the pressure, calculate thermal expansion, place the supports properly, and lag the line. Welds are inspected and documented before it runs.',
    },
    images: [`${CL}/v1679741318/IMG_20210429130536_ca4c934155.jpg`, `${CL}/v1679738715/16_6937d14a1f.jpg`],
    facts: [
      { ar: 'خطوط بخار · كوندنسيت · مصائد بخار', en: 'Steam mains · condensate · steam traps' },
      { ar: 'كربوستيل جدول 40 · استانلس', en: 'Carbon steel Sch 40 · stainless' },
      { ar: 'حساب التمدد الحراري والشدادات', en: 'Thermal expansion and supports calculated' },
      { ar: 'فحص لحام موثّق قبل التشغيل', en: 'Documented weld inspection before start-up' },
    ],
    options: [
      { key: 'scope', label: { ar: 'المطلوب', en: 'Scope' }, kind: 'choice', values: [
        { ar: 'توصيل غلاية جديدة', en: 'New boiler hook-up' }, { ar: 'خط بخار', en: 'Steam main' },
        { ar: 'خط كوندنسيت', en: 'Condensate return' }, { ar: 'صيانة/تعديل خط قائم', en: 'Modify an existing line' } ] },
      { key: 'pressure', label: { ar: 'ضغط التشغيل', en: 'Working pressure' }, kind: 'free', hint: { ar: 'بار', en: 'bar' } },
      { key: 'material', label: { ar: 'الخامة', en: 'Material' }, kind: 'choice', values: [MATERIALS[3], MATERIALS[0], MATERIALS[1]] },
      { key: 'length', label: { ar: 'الطول التقريبي', en: 'Approx. length' }, kind: 'free', hint: { ar: 'بالمتر', en: 'in metres' } },
    ],
  },
  {
    slug: 'marine-ladders',
    seo: {
      title: { ar: 'سلالم بحري — تصنيع سلم بحري استانلس بالمقاس | المجموعة المصرية', en: 'Marine Ladders — Vertical Access Ladders Made to Size | Egyptian Group' },
      desc: { ar: 'تصنيع سلالم بحري (رأسية) للتنكات والسايلوهات وحيطان المصانع — درجات مانعة للانزلاق، قفص حماية للارتفاعات فوق 3 متر، استانلس أو استيل مدهون.', en: 'Marine (vertical) ladders for tanks, silos and plant walls — anti-slip rungs, safety cage above 3 m, stainless or painted steel, fixings calculated to the structure.' },
      terms: ['سلالم بحري', 'سلم بحري', 'سلالم بحاري', 'سلم بحاري', 'سلم رأسي', 'سلالم تنكات', 'marine ladder', 'vertical ladder', 'cat ladder'],
    },
    family: 'custom',
    category: { ar: 'صناعي — حسب الطلب', en: 'Industrial — made to order' },
    name: { ar: 'سلالم بحري', en: 'Marine Ladders' },
    tagline: { ar: 'وصول رأسي، في أضيق مكان.', en: 'Vertical access, in the tightest spot.' },
    body: {
      ar: 'السلم البحري (marine ladder) هو السلم الرأسي أو شديد الميل اللي بيتحط في الأماكن الضيقة — على التنكات، والسايلوهات، وفتحات الأسطح، وحيطان المصانع. بيتعمل باستانلس أو استيل مدهون، بدرجات مانعة للانزلاق، وقفص حماية (safety cage) للارتفاعات اللي فوق 3 متر، وتثبيت محسوب على الحيطة أو الجسم. بنعمله بالمقاس على الارتفاع الفعلي بعد المعاينة.',
      en: 'A marine ladder is the vertical (or steeply raked) ladder that goes where nothing else fits — on tanks, silos, roof hatches and plant walls. Built in stainless or painted steel, with anti-slip rungs, a safety cage above 3 metres, and fixings calculated for the wall or the shell. Made to the actual height after a site visit.',
    },
    images: [`${CL}/v1679741340/IMG_20210429130552_5945176dda.jpg`, `${CL}/v1679741318/IMG_20210429130536_ca4c934155.jpg`],
    facts: [
      { ar: 'سلم رأسي · درجات مانعة للانزلاق', en: 'Vertical ladder · anti-slip rungs' },
      { ar: 'قفص حماية للارتفاعات فوق 3 م', en: 'Safety cage above 3 m' },
      { ar: 'استانلس 304 · استيل مدهون', en: 'Stainless 304 · painted steel' },
      { ar: 'تثبيت محسوب على الحيطة أو التنك', en: 'Fixings calculated to the wall or shell' },
    ],
    options: [
      { key: 'material', label: { ar: 'الخامة', en: 'Material' }, kind: 'choice', values: [MATERIALS[0], MATERIALS[4], MATERIALS[3]] },
      { key: 'height', label: { ar: 'الارتفاع', en: 'Height' }, kind: 'free', hint: { ar: 'بالمتر', en: 'in metres' } },
      { key: 'cage', label: { ar: 'قفص حماية', en: 'Safety cage' }, kind: 'choice', values: [
        { ar: 'أيوه', en: 'Yes' }, { ar: 'لأ', en: 'No' }, { ar: 'حسب الاشتراطات', en: 'To code' } ] },
      { key: 'mount', label: { ar: 'مكان التركيب', en: 'Mounting' }, kind: 'choice', values: [
        { ar: 'على حيطة', en: 'Wall' }, { ar: 'على تنك/سايلو', en: 'Tank/silo' }, { ar: 'قائم بذاته', en: 'Free-standing' } ] },
    ],
  },
  {
    slug: 'small-tanks',
    seo: {
      title: { ar: 'خزانات استانلس صغيرة — من 50 لتر لـ 2 م³ | المجموعة المصرية', en: 'Small Stainless Tanks — 50 L to 2 m³ | Egyptian Group' },
      desc: { ar: 'خزانات وتنكات استانلس صغيرة من 50 لتر لـ 2 متر مكعب — للمعامل والمطابخ الصناعية والورش. استانلس 304/316، بغطاء أو مفتوح، بأرجل أو عجل ومحبس تصريف.', en: 'Small stainless tanks from 50 litres to 2 m³ — for laboratories, industrial kitchens and workshops. Stainless 304/316, lidded or open, on legs or castors with a drain valve.' },
      terms: ['خزانات صغيرة', 'تنك صغير', 'خزان استانلس صغير', 'تنكات صغيرة', 'خزان 100 لتر', 'خزان 500 لتر', 'small stainless tank'],
    },
    family: 'standard',
    category: { ar: 'مخزون وتجهيزات', en: 'Stock & fixtures' },
    name: { ar: 'خزانات استانلس صغيرة', en: 'Small Stainless Tanks' },
    tagline: { ar: 'أحجام الورشة والمعمل والمطبخ.', en: 'Workshop, lab and kitchen sizes.' },
    body: {
      ar: 'خزانات وتنكات استانلس صغيرة — من 50 لتر لـ 2 متر مكعب — للمعامل والمطابخ الصناعية والورش وخطوط الإنتاج الصغيرة. بتتعمل باستانلس 304 أو 316، بغطاء أو من غير، بأرجل أو عجل، وبمحبس تصريف. اللحام أملس ومصقول والزوايا مدوّرة — تتنضّف بالكامل. متوفّرة بمقاسات جاهزة أو بالمقاس اللي تطلبه.',
      en: 'Small stainless tanks — 50 litres to 2 m³ — for laboratories, industrial kitchens, workshops and small production lines. Built in stainless 304 or 316, with or without a lid, on legs or castors, with a drain valve. Welds smooth and polished, corners radiused — they clean down completely. Available in standard sizes or made to yours.',
    },
    images: [`${CL}/v1679741110/51_669bdd7364.jpg`, '/assets/tank-main.jpg'],
    facts: [
      { ar: 'من 50 لتر لـ 2 م³', en: '50 litres to 2 m³' },
      { ar: 'استانلس 304 / 316 · لحام مصقول', en: 'Stainless 304/316 · polished welds' },
      { ar: 'أرجل أو عجل · محبس تصريف', en: 'Legs or castors · drain valve' },
    ],
    options: [
      { key: 'capacity', label: { ar: 'السعة', en: 'Capacity' }, kind: 'choice', values: [
        { ar: '50 لتر', en: '50 L' }, { ar: '100 لتر', en: '100 L' }, { ar: '250 لتر', en: '250 L' },
        { ar: '500 لتر', en: '500 L' }, { ar: '1000 لتر', en: '1000 L' }, { ar: 'أكبر / حسب الطلب', en: 'Larger / to order' } ] },
      { key: 'material', label: { ar: 'الخامة', en: 'Material' }, kind: 'choice', values: MATERIALS.slice(0, 2) },
      { key: 'lid', label: { ar: 'الغطاء', en: 'Lid' }, kind: 'choice', values: [
        { ar: 'بغطاء', en: 'With lid' }, { ar: 'مفتوح', en: 'Open top' } ] },
      { key: 'base', label: { ar: 'القاعدة', en: 'Base' }, kind: 'choice', values: [
        { ar: 'أرجل', en: 'Legs' }, { ar: 'عجل', en: 'Castors' }, { ar: 'بدون', en: 'None' } ] },
      { key: 'qty', label: { ar: 'الكمية', en: 'Quantity' }, kind: 'free', hint: { ar: 'عدد', en: 'units' } },
    ],
  },

  // ═══════════ PROCESS MACHINERY — food, dairy, confectionery ═══════════
  {
    slug: 'conches',
    family: 'custom',
    category: { ar: 'صناعي — حسب الطلب', en: 'Industrial — made to order' },
    name: { ar: 'كونشات شوكولاتة', en: 'Chocolate Conches' },
    tagline: { ar: 'ساعات التقليب هي اللي بتحدّد الطعم.', en: 'The hours of conching are what decide the taste.' },
    body: {
      ar: 'كونشات لتكرير وتنعيم الشوكولاتة — الجسم والتقليب والجاكيت الحراري بيتصمّموا على الخلطة نفسها ومدة الكونشينج المطلوبة. سطوح ملامسة استانلس بتشطيب صحي، ولحام أملس بلا شقوق يقف فيها منتج. ودي شغلانة بتتحكم في المنتج النهائي — فالتنفيذ فيها مش مجرد تصنيع.',
      en: 'Conches for refining chocolate — the shell, the agitation and the thermal jacket are designed around the actual recipe and the conching time it needs. Stainless product-contact surfaces with a sanitary finish, and smooth crevice-free welds where nothing can sit. This machine shapes the final product, so building it is not just fabrication.',
    },
    images: ['/assets/conche-main.jpg'],
    facts: [
      { ar: 'غذائي بالكامل: كل سطح بيلمس المنتج 304/316 مصقول', en: 'Fully food grade: every product-contact surface is polished 304/316' },
      { ar: 'استانلس 304 / 316 — سطوح ملامسة صحية', en: 'Stainless 304/316 — sanitary contact surfaces' },
      { ar: 'جاكيت حراري · تحكّم في الحرارة والزمن', en: 'Thermal jacket · temperature and time control' },
      { ar: 'تصميم على الخلطة والسعة المطلوبة', en: 'Designed to the recipe and the batch size' },
    ],
    options: [
      { key: 'grade', label: { ar: 'درجة التصنيع', en: 'Build grade' }, kind: 'choice', values: GRADE },
      { key: 'capacity', label: { ar: 'السعة', en: 'Batch size' }, kind: 'free', hint: { ar: 'كجم أو لتر لكل تشغيلة', en: 'kg or litres per batch' } },
      { key: 'material', label: { ar: 'الخامة', en: 'Material' }, kind: 'choice', values: MATERIALS.slice(0, 2) },
      { key: 'jacket', label: { ar: 'الجاكيت الحراري', en: 'Thermal jacket' }, kind: 'choice', values: [
        { ar: 'تسخين', en: 'Heating' }, { ar: 'تسخين وتبريد', en: 'Heating and cooling' }, { ar: 'بدون', en: 'None' } ] },
      { key: 'control', label: { ar: 'لوحة التحكم', en: 'Control panel' }, kind: 'choice', values: [
        { ar: 'يدوي', en: 'Manual' }, { ar: 'PLC', en: 'PLC' }, { ar: 'حسب الطلب', en: 'To order' } ] },
      { key: 'product', label: { ar: 'المنتج والخلطة', en: 'Product and recipe' }, kind: 'free', hint: { ar: 'إيه اللي هيتكونش؟ وبأي لزوجة؟', en: 'What is being conched, and at what viscosity?' } },
    ],
  },
  {
    slug: 'industrial-mixers',
    family: 'custom',
    category: { ar: 'صناعي — حسب الطلب', en: 'Industrial — made to order' },
    name: { ar: 'ميكسرات صناعية', en: 'Industrial Mixers' },
    tagline: { ar: 'الخلط الصح مش قوة — هندسة.', en: 'Good mixing is not force. It is geometry.' },
    body: {
      ar: 'ميكسرات وخلاطات صناعية — الريشة وسرعتها وشكل الحلة بتتحدّد على لزوجة المنتج وسلوكه، مش بقالب جاهز. للأغذية والألبان والكيماويات، بتشطيب صحي على السطوح اللي بتلمس المنتج.',
      en: 'Industrial mixers and agitators — the impeller, its speed and the vessel geometry follow the product\'s viscosity and behaviour, not a standard template. For food, dairy and chemicals, with a sanitary finish on every product-contact surface.',
    },
    images: [`${CL}/v1727277073/1001727277048_3332398578.jpg`],
    facts: [
      { ar: 'غذائي: ريشة وعمود مصقولين · لحام أملس', en: 'Food grade: polished impeller and shaft · smooth welds' },
      { ar: 'استانلس 304 / 316', en: 'Stainless 304 / 316' },
      { ar: 'ريشة وسرعة على حسب اللزوجة', en: 'Impeller and speed matched to viscosity' },
    ],
    options: [
      { key: 'grade', label: { ar: 'درجة التصنيع', en: 'Build grade' }, kind: 'choice', values: GRADE },
      { key: 'capacity', label: { ar: 'السعة', en: 'Capacity' }, kind: 'free', hint: { ar: 'لتر أو م³', en: 'litres or m³' } },
      { key: 'material', label: { ar: 'الخامة', en: 'Material' }, kind: 'choice', values: MATERIALS.slice(0, 3) },
      { key: 'mount', label: { ar: 'التركيب', en: 'Mounting' }, kind: 'choice', values: [
        { ar: 'علوي', en: 'Top-mounted' }, { ar: 'جانبي', en: 'Side-entry' }, { ar: 'محمول', en: 'Portable' } ] },
      { key: 'jacket', label: { ar: 'جاكيت', en: 'Jacket' }, kind: 'choice', values: [
        { ar: 'بدون', en: 'None' }, { ar: 'تسخين', en: 'Heating' }, { ar: 'تبريد', en: 'Cooling' } ] },
      { key: 'product', label: { ar: 'المنتج ولزوجته', en: 'Product and viscosity' }, kind: 'free', hint: { ar: 'سايل؟ كريمي؟ عجينة؟', en: 'Liquid? Cream? Paste?' } },
    ],
  },
  {
    slug: 'cookers',
    family: 'custom',
    category: { ar: 'صناعي — حسب الطلب', en: 'Industrial — made to order' },
    name: { ar: 'طباخات صناعية', en: 'Industrial Cookers' },
    tagline: { ar: 'حرارة متساوية، دفعة ورا دفعة.', en: 'Even heat, batch after batch.' },
    body: {
      ar: 'طباخات وحلل بخارية صناعية — جاكيت بخار أو تسخين مباشر، بتقليب أو من غير. الحرارة بتتوزّع بالتساوي عشان الدفعة تطلع زي اللي قبلها. للأغذية والألبان والصلصات.',
      en: 'Industrial cookers and steam-jacketed kettles — steam jacket or direct heat, with or without agitation. Heat spreads evenly so each batch matches the last. For food, dairy and sauces.',
    },
    images: [`${CL}/v1727280275/1001727280248_392066eca4.jpg`],
    facts: [
      { ar: 'غذائي: زوايا مدوّرة · تصريف كامل · بلا نقطة يستقر فيها منتج', en: 'Food grade: radiused corners · full drainage · nothing sits anywhere' },
      { ar: 'استانلس 304 / 316 · جاكيت بخار', en: 'Stainless 304/316 · steam jacket' },
      { ar: 'تشطيب صحي · لحام بلا شقوق', en: 'Sanitary finish · crevice-free welds' },
    ],
    options: [
      { key: 'grade', label: { ar: 'درجة التصنيع', en: 'Build grade' }, kind: 'choice', values: GRADE },
      { key: 'capacity', label: { ar: 'السعة', en: 'Capacity' }, kind: 'free', hint: { ar: 'لتر لكل دفعة', en: 'litres per batch' } },
      { key: 'material', label: { ar: 'الخامة', en: 'Material' }, kind: 'choice', values: MATERIALS.slice(0, 2) },
      { key: 'heating', label: { ar: 'التسخين', en: 'Heating' }, kind: 'choice', values: [
        { ar: 'جاكيت بخار', en: 'Steam jacket' }, { ar: 'كهرباء', en: 'Electric' }, { ar: 'غاز', en: 'Gas' } ] },
      { key: 'agitator', label: { ar: 'تقليب', en: 'Agitation' }, kind: 'choice', values: [
        { ar: 'بدون', en: 'None' }, { ar: 'مقلّب', en: 'Agitator' }, { ar: 'كاشط للجدار', en: 'Scraped surface' } ] },
      { key: 'product', label: { ar: 'المنتج', en: 'Product' }, kind: 'free', hint: { ar: 'هيتطبخ فيها إيه؟', en: 'What gets cooked in it?' } },
    ],
  },
  {
    slug: 'crushers',
    family: 'custom',
    category: { ar: 'صناعي — حسب الطلب', en: 'Industrial — made to order' },
    name: { ar: 'كسارات', en: 'Crushers & Mills' },
    tagline: { ar: 'الخامة هي اللي بتحدّد التصميم.', en: 'The material decides the design.' },
    body: {
      ar: 'كسارات وطواحين صناعية — بتتصمّم على الخامة نفسها: صلابتها، رطوبتها، والمقاس اللي عايزه بعد الكسر. أجزاء الاحتكاك بتتختار عشان تعيش، لأن قطعة بتتغيّر كل شهر بتوقف الخط.',
      en: 'Industrial crushers and mills — designed around the actual material: its hardness, its moisture, and the size you need coming out. Wear parts are chosen to last, because a component that needs replacing monthly stops the line.',
    },
    images: [`${CL}/v1727347849/1001727347766_02289cf612.jpg`],
    facts: [
      { ar: 'استانلس 304 / 316 · كربوستيل', en: 'Stainless 304/316 · carbon steel' },
      { ar: 'تصميم على صلابة الخامة والمقاس المطلوب', en: 'Designed to material hardness and target size' },
    ],
    options: [
      { key: 'grade', label: { ar: 'درجة التصنيع', en: 'Build grade' }, kind: 'choice', values: GRADE },
      { key: 'material', label: { ar: 'خامة الكسارة', en: 'Build material' }, kind: 'choice', values: MATERIALS.slice(0, 4) },
      { key: 'feed', label: { ar: 'الخامة اللي هتتكسر', en: 'Material to crush' }, kind: 'free', hint: { ar: 'إيه هي؟ وصلابتها إيه؟', en: 'What is it, and how hard?' } },
      { key: 'output', label: { ar: 'المقاس بعد الكسر', en: 'Output size' }, kind: 'free', hint: { ar: 'مم أو ميكرون', en: 'mm or micron' } },
      { key: 'rate', label: { ar: 'المعدّل المطلوب', en: 'Throughput' }, kind: 'free', hint: { ar: 'كجم/ساعة أو طن/ساعة', en: 'kg/h or t/h' } },
    ],
  },
  {
    slug: 'kitchen-equipment',
    family: 'custom',
    category: { ar: 'صناعي — حسب الطلب', en: 'Industrial — made to order' },
    name: { ar: 'معدات مطابخ صناعية', en: 'Industrial Kitchen Equipment' },
    tagline: { ar: 'مطبخ يعدّي التفتيش الصحي.', en: 'A kitchen that clears the hygiene inspection.' },
    body: {
      ar: 'تجهيز مطابخ صناعية بالكامل — أحواض، ترابيزات، أرفف، شفّاطات، وعربات — استانلس بلحام أملس وزوايا مدوّرة. مصمّمة تتنضّف بالكامل وتتحمّل دورات الغسيل اليومية، ومتفصّلة على مساحتك.',
      en: 'Complete industrial kitchen fit-out — sinks, tables, shelving, hoods and trolleys — in stainless with smooth welds and radiused corners. Designed to clean down completely and take a daily wash cycle, and built to your floor plan.',
    },
    images: [`${CL}/v1726987847/erbt_astanls_styl_20724b113c.jpg`, `${CL}/v1727280275/1001727280248_392066eca4.jpg`],
    facts: [
      { ar: 'غذائي: يعدّي تدقيق النظافة · يتحمّل الغسيل اليومي', en: 'Food grade: clears a hygiene audit · takes a daily wash-down' },
      { ar: 'استانلس 304 · تشطيب صحي', en: 'Stainless 304 · sanitary finish' },
      { ar: 'أحواض · ترابيزات · أرفف · شفّاطات · عربات', en: 'Sinks · tables · shelving · hoods · trolleys' },
    ],
    options: [
      { key: 'grade', label: { ar: 'درجة التصنيع', en: 'Build grade' }, kind: 'choice', values: GRADE },
      { key: 'scope', label: { ar: 'المطلوب', en: 'What you need' }, kind: 'free', hint: { ar: 'مثال: 3 ترابيزات + حوضين + شفّاط', en: 'e.g. 3 tables + 2 sinks + a hood' } },
      { key: 'material', label: { ar: 'الخامة', en: 'Material' }, kind: 'choice', values: MATERIALS.slice(0, 3) },
      { key: 'area', label: { ar: 'مساحة المطبخ', en: 'Kitchen area' }, kind: 'free', hint: { ar: 'م² تقريباً', en: 'approx. m²' } },
    ],
  },
  {
    slug: 'gas-lines',
    family: 'custom',
    category: { ar: 'صناعي — حسب الطلب', en: 'Industrial — made to order' },
    name: { ar: 'خطوط غازات', en: 'Gas Lines' },
    tagline: { ar: 'خط غاز مفيش فيه اجتهاد.', en: 'A gas line leaves no room for improvisation.' },
    body: {
      ar: 'تمديد وتوصيل خطوط الغازات الصناعية — أرجون، CO₂، أكسچين، هواء مضغوط. كل وصلة مفحوصة ومختبَرة بالضغط وموثّقة. النوع ده من الشغل بيتحاسب بالتوثيق مش بالكلام.',
      en: 'Installing and connecting industrial gas lines — argon, CO₂, oxygen, compressed air. Every joint inspected, pressure-tested and documented. This is work that is judged on its paperwork, not on assurances.',
    },
    images: [`${CL}/v1679738739/14_2533049ffb.jpg`],
    facts: [
      { ar: 'لحام حقن · اختبار ضغط · توثيق كل وصلة', en: 'Back-purged welds · pressure tested · every joint documented' },
      { ar: 'أرجون · CO₂ · أكسچين · هواء مضغوط', en: 'Argon · CO₂ · oxygen · compressed air' },
      { ar: 'اختبار ضغط · توثيق كامل للحامات', en: 'Pressure tested · full weld documentation' },
    ],
    options: [
      { key: 'gas', label: { ar: 'الغاز', en: 'Gas' }, kind: 'choice', values: [
        { ar: 'أرجون', en: 'Argon' }, { ar: 'CO₂', en: 'CO₂' }, { ar: 'أكسچين', en: 'Oxygen' },
        { ar: 'هواء مضغوط', en: 'Compressed air' }, { ar: 'أخرى', en: 'Other' } ] },
      { key: 'dn', label: { ar: 'المقاس (DN)', en: 'Size (DN)' }, kind: 'choice', values: DN },
      { key: 'length', label: { ar: 'الطول التقريبي', en: 'Approx. length' }, kind: 'free', hint: { ar: 'بالمتر', en: 'in metres' } },
      { key: 'points', label: { ar: 'عدد نقاط السحب', en: 'Outlet points' }, kind: 'free', hint: { ar: 'عدد', en: 'count' } },
    ],
  },
  {
    slug: 'overhaul',
    family: 'custom',
    category: { ar: 'صناعي — حسب الطلب', en: 'Industrial — made to order' },
    name: { ar: 'عمرات صناعية', en: 'Industrial Overhauls' },
    tagline: { ar: 'النافذة ضيّقة — وده بالظبط الشغل.', en: 'The window is tight. That is the job.' },
    body: {
      ar: 'عمرات وإصلاحات للمعدات والخطوط — بتتنفّذ في نافذة الإيقاف المتفق عليها. بنشوف المعدة على الطبيعة، نحدّد اللي محتاج يتغيّر واللي ينفع يتصلّح، ونجهّز القطع قبل ما الخط يقف. الوقت في العمرة تكلفة مباشرة.',
      en: 'Overhauls and repairs of equipment and lines, executed inside the agreed shutdown window. We look at the machine on site, decide what must be replaced and what can be repaired, and have the parts ready before the line stops. In an overhaul, time is a direct cost.',
    },
    images: [`${CL}/v1679738568/13_bfdd21487a.jpg`],
    facts: [
      { ar: 'تشخيص بالموقع · قطع مجهّزة قبل الإيقاف', en: 'On-site diagnosis · parts ready before the stop' },
      { ar: 'الالتزام بنافذة الإيقاف', en: 'Committed to the shutdown window' },
    ],
    options: [
      { key: 'equipment', label: { ar: 'المعدة', en: 'Equipment' }, kind: 'free', hint: { ar: 'إيه اللي محتاج عمرة؟', en: 'What needs overhauling?' } },
      { key: 'window', label: { ar: 'نافذة الإيقاف', en: 'Shutdown window' }, kind: 'free', hint: { ar: 'مثال: 3 أيام في أجازة العيد', en: 'e.g. 3 days over the holiday' } },
      { key: 'scope', label: { ar: 'المطلوب', en: 'Scope' }, kind: 'choice', values: [
        { ar: 'فحص وتشخيص', en: 'Inspection and diagnosis' },
        { ar: 'إصلاح', en: 'Repair' },
        { ar: 'عمرة كاملة', en: 'Full overhaul' } ] },
    ],
  },
  {
    slug: 'engineering-design',
    family: 'custom',
    category: { ar: 'صناعي — حسب الطلب', en: 'Industrial — made to order' },
    name: { ar: 'تصميم هندسي', en: 'Engineering Design' },
    tagline: { ar: 'الغلط على الورق أرخص من الغلط في الورشة.', en: 'A mistake on paper is cheaper than one in the shop.' },
    body: {
      ar: 'تصميم ورسومات تنفيذية وحصر مواد — سواء لشغل هنصنّعه إحنا أو لحاجة إنت هتنفّذها. المكتب الفني بيراجع الفكرة قبل ما تتحوّل لحديد، ودي المرحلة اللي بتتوفّر فيها فلوس حقيقية.',
      en: 'Design, shop drawings and a bill of materials — whether we fabricate it or you do. The technical office reviews the idea before it turns into steel, and that is the stage where real money is saved.',
    },
    images: [`${CL}/v1690703839/D11_c041140370.jpg`],
    facts: [
      { ar: 'رسومات تنفيذية · حصر مواد · مراجعة فنية', en: 'Shop drawings · bill of materials · technical review' },
    ],
    options: [
      { key: 'kind', label: { ar: 'المطلوب', en: 'What you need' }, kind: 'choice', values: [
        { ar: 'تصميم من الصفر', en: 'Design from scratch' },
        { ar: 'رسومات تنفيذية لفكرة عندي', en: 'Shop drawings for my concept' },
        { ar: 'مراجعة تصميم موجود', en: 'Review an existing design' },
        { ar: 'حصر مواد', en: 'Bill of materials' } ] },
      { key: 'brief', label: { ar: 'الفكرة', en: 'The brief' }, kind: 'free', hint: { ar: 'المطلوب يعمل إيه؟', en: 'What does it need to do?' } },
    ],
  },
  {
    slug: 'machining',
    family: 'custom',
    category: { ar: 'صناعي — حسب الطلب', en: 'Industrial — made to order' },
    name: { ar: 'خراطة وتشغيل معادن', en: 'Machining & Turning' },
    tagline: { ar: 'القطعة اللي وقّفت الخط.', en: 'The part that stopped the line.' },
    body: {
      ar: 'خراطة وتفريز CNC — قطع غيار وأجزاء دقيقة حسب الرسم أو حسب العيّنة. غالباً بيبقى المطلوب قطعة واحدة بسرعة، مش إنتاج كمية — وده اللي بيفرّق.',
      en: 'CNC turning and milling — spare parts and precision components to a drawing or to a sample. Usually what is needed is one part, quickly, not a production run — and that is the difference.',
    },
    images: [`${CL}/v1727279512/1001727279459_7bc15f7b52.jpg`],
    facts: [
      { ar: 'خراطة وتفريز CNC · حسب الرسم أو العيّنة', en: 'CNC turning and milling · to drawing or sample' },
      { ar: 'استانلس · كربوستيل · ألومنيوم', en: 'Stainless · carbon steel · aluminium' },
    ],
    options: [
      { key: 'material', label: { ar: 'الخامة', en: 'Material' }, kind: 'choice', values: [
        MATERIALS[0], MATERIALS[1], MATERIALS[3], { ar: 'ألومنيوم', en: 'Aluminium' } ] },
      { key: 'source', label: { ar: 'عندك إيه؟', en: 'What do you have?' }, kind: 'choice', values: [
        { ar: 'رسم هندسي', en: 'A drawing' }, { ar: 'عيّنة من القطعة', en: 'A sample part' }, { ar: 'لا ده ولا ده', en: 'Neither' } ] },
      { key: 'qty', label: { ar: 'الكمية', en: 'Quantity' }, kind: 'free', hint: { ar: 'عدد', en: 'pieces' } },
      { key: 'part', label: { ar: 'القطعة', en: 'The part' }, kind: 'free', hint: { ar: 'إيه هي وبتشتغل فين؟', en: 'What is it and where does it run?' } },
    ],
  },
  {
    slug: 'stainless-coil',
    family: 'standard',
    category: { ar: 'مخزون — توريد', en: 'Stock — supply' },
    name: { ar: 'كويل استانلس', en: 'Stainless Coil' },
    tagline: { ar: 'لفائف من المخزون، بالبارد والساخن.', en: 'Coil from stock, cold and hot rolled.' },
    body: {
      ar: 'لفائف استانلس 304 و316 و201 — بارد وساخن، بأسماك وعروض مختلفة. من المخزون، وبنقصّها على المقاس اللي محتاجه.',
      en: 'Stainless coil in 304, 316 and 201 — cold and hot rolled, in a range of thicknesses and widths. From stock, and cut to the size you need.',
    },
    images: [`${CL}/v1704962141/Stainless_Steel_Coil_1_0ddf314193.jpg`],
    facts: [
      { ar: 'استانلس 304 / 316 / 201', en: 'Stainless 304 / 316 / 201' },
      { ar: 'بارد وساخن · قص على المقاس', en: 'Cold and hot rolled · cut to size' },
    ],
    options: [
      { key: 'material', label: { ar: 'الخامة', en: 'Grade' }, kind: 'choice', values: MATERIALS.slice(0, 3) },
      { key: 'rolled', label: { ar: 'بارد / ساخن', en: 'Cold / hot rolled' }, kind: 'choice', values: ROLLED },
      { key: 'thickness', label: { ar: 'السُمك', en: 'Thickness' }, kind: 'choice', values: THICKNESS },
      { key: 'width', label: { ar: 'العرض', en: 'Width' }, kind: 'free', hint: { ar: 'مم', en: 'mm' } },
      { key: 'qty', label: { ar: 'الكمية', en: 'Quantity' }, kind: 'free', hint: { ar: 'طن أو متر', en: 'tonnes or metres' } },
    ],
  },

  {
    slug: 'powder-filters',
    family: 'custom',
    category: { ar: 'صناعي — حسب الطلب', en: 'Industrial — made to order' },
    name: { ar: 'فلاتر بودر', en: 'Powder Filters & Dust Collectors' },
    tagline: { ar: 'البودر اللي بيهرب فلوس بتتحرق.', en: 'Escaping powder is money burning.' },
    body: {
      ar: 'فلاتر أكياس وخراطيش وفلاتر أعلى الصوامع وسيكلونات — جسم استانلس مفصّل على السحب والمساحة الفلترية اللي محتاجها. بننفّذ منظومة التنظيف بنفث الهواء العكسي كاملة، والداخل بلا شقوق تحبس بودر. الوسط الفلتري نفسه بيتوّرد على حسب المادة والحرارة. لمصانع الألبان والأدوية والبهارات والأسمنت والأسمدة.',
      en: 'Bag and cartridge filters, silo-top bin vents and cyclones — a stainless body sized to your airflow and the filtration area it needs. We build in the full reverse pulse-jet cleaning system, and the inside carries no crevice that can trap powder. The filter media itself is specified against the material and the temperature. For dairy, pharmaceutical, spice, cement and fertiliser plants.',
    },
    images: [`${CL}/v1679741110/51_669bdd7364.jpg`],
    facts: [
      { ar: '304 للبودر الجاف · 316L مع الرطوبة أو المواد الأكّالة أو الدوائي', en: '304 for dry powder · 316L for moisture, corrosives or pharma' },
      { ar: 'تنظيف بنفث الهواء العكسي (reverse pulse-jet)', en: 'Reverse pulse-jet cleaning' },
      { ar: 'داخل بلا شقوق — مفيش بودر بيستقر', en: 'Crevice-free interior — nothing settles' },
      { ar: 'شهادات الألواح EN 10204 3.1', en: 'EN 10204 3.1 mill certificates' },
    ],
    options: [
      { key: 'grade', label: { ar: 'درجة التصنيع', en: 'Build grade' }, kind: 'choice', values: GRADE },
      { key: 'type', label: { ar: 'نوع الفلتر', en: 'Filter type' }, kind: 'choice', values: [
        { ar: 'فلتر أكياس (Baghouse)', en: 'Baghouse' },
        { ar: 'فلتر خراطيش (Cartridge)', en: 'Cartridge' },
        { ar: 'فلتر أعلى صومعة (Bin vent)', en: 'Bin vent / silo top' },
        { ar: 'سيكلون (Cyclone)', en: 'Cyclone separator' },
        { ar: 'منخل دوّار (Sifter)', en: 'Rotary / vibro sifter' },
        { ar: 'مش متأكد', en: 'Not sure' } ] },
      { key: 'material', label: { ar: 'الخامة', en: 'Material' }, kind: 'choice', values: MATERIALS.slice(0, 3) },
      { key: 'ra', label: { ar: 'التشطيب الداخلي', en: 'Internal finish' }, kind: 'choice', values: RA },
      { key: 'powder', label: { ar: 'البودر', en: 'The powder' }, kind: 'free', hint: { ar: 'إيه هو؟ ورطوبته وحرارته؟', en: 'What is it? Moisture and temperature?' } },
      { key: 'airflow', label: { ar: 'معدّل السحب', en: 'Airflow' }, kind: 'free', hint: { ar: 'م³/ساعة لو معروف', en: 'm³/h if known' } },
    ],
  },
  {
    slug: 'blenders',
    family: 'custom',
    category: { ar: 'صناعي — حسب الطلب', en: 'Industrial — made to order' },
    name: { ar: 'بلندرات وخلاطات بودر', en: 'Blenders & Powder Mixers' },
    tagline: { ar: 'الخلطة المتجانسة مش صدفة.', en: 'A homogeneous blend is not luck.' },
    body: {
      ar: 'بلندرات شريطية ومجدافية وV وأقماع مزدوجة وخلاطات رأسية — الشكل نفسه بيتحدّد على المواد اللي بتتخلط وفرق كثافتها وزمن الخلط المطلوب. سطوح داخلية مصقولة، ولحامات كاملة الاختراق ومصنفرة على مستوى السطح — لأن أي شق بيحبس بودر وبيبوّظ الدفعة اللي بعدها.',
      en: 'Ribbon, paddle, V, double-cone and conical screw blenders — the geometry follows the materials being blended, their density difference and the blend time required. Polished internal surfaces, and full-penetration welds ground flush to the surface — because any crevice traps powder and contaminates the next batch.',
    },
    images: [`${CL}/v1727277073/1001727277048_3332398578.jpg`],
    facts: [
      { ar: '316L للغذائي والدوائي · 304 للكيماوي الجاف', en: '316L for food and pharma · 304 for dry chemicals' },
      { ar: 'لحام كامل الاختراق مع حقن، مصنفر على مستوى السطح', en: 'Full-penetration back-purged welds, ground flush' },
      { ar: 'تشطيب داخلي Ra ≤ 0.8 ميكرون', en: 'Internal finish Ra ≤ 0.8 µm' },
    ],
    options: [
      { key: 'grade', label: { ar: 'درجة التصنيع', en: 'Build grade' }, kind: 'choice', values: GRADE },
      { key: 'type', label: { ar: 'نوع البلندر', en: 'Blender type' }, kind: 'choice', values: [
        { ar: 'شريطي (Ribbon)', en: 'Ribbon' },
        { ar: 'مجدافي (Paddle)', en: 'Paddle' },
        { ar: 'V (Twin-shell)', en: 'V / twin-shell' },
        { ar: 'مخروط مزدوج (Double cone)', en: 'Double cone' },
        { ar: 'رأسي بمسمار (Nauta)', en: 'Conical screw (Nauta)' },
        { ar: 'عالي السرعة (High-shear)', en: 'High-shear' },
        { ar: 'مش متأكد', en: 'Not sure' } ] },
      { key: 'material', label: { ar: 'الخامة', en: 'Material' }, kind: 'choice', values: MATERIALS.slice(0, 3) },
      { key: 'ra', label: { ar: 'التشطيب الداخلي', en: 'Internal finish' }, kind: 'choice', values: RA },
      { key: 'capacity', label: { ar: 'السعة', en: 'Capacity' }, kind: 'free', hint: { ar: 'لتر أو كجم لكل دفعة', en: 'litres or kg per batch' } },
      { key: 'materials', label: { ar: 'المواد اللي هتتخلط', en: 'Materials to blend' }, kind: 'free', hint: { ar: 'إيه هي؟ وفيه فرق كثافة كبير؟', en: 'What are they? Big density difference?' } },
    ],
  },
];

export const catalogPage = {
  eyebrow: { ar: 'الكتالوج', en: 'Catalogue' } as L,
  title: { ar: 'اللي بنصنّعه.', en: 'What we build.' } as L,
  intro: {
    ar: 'كل منتج هنا اتنفّذ فعلاً في مصنعنا. اختار المواصفات اللي محتاجها واطلب عرض سعر — المكتب الفني يراجعها ويرجعلك بنطاق وسعر.',
    en: 'Every product here has actually been built in our shop. Pick the specification you need and request a quote — the technical office reviews it and returns a scope and a price.',
  } as L,
  filters: {
    all: { ar: 'الكل', en: 'All' } as L,
    custom: { ar: 'صناعي — حسب الطلب', en: 'Industrial — made to order' } as L,
    standard: { ar: 'مخزون وتجهيزات', en: 'Stock & fixtures' } as L,
  },
  quoteCta: { ar: 'اطلب عرض سعر', en: 'Request a quote' } as L,
  optionsTitle: { ar: 'حدّد مواصفاتك', en: 'Specify what you need' } as L,
  factsTitle: { ar: 'المواصفات', en: 'Specifications' } as L,
  sendTitle: { ar: 'ابعت الطلب', en: 'Send request' } as L,
  backToCatalog: { ar: 'كل المنتجات', en: 'All products' } as L,
};
