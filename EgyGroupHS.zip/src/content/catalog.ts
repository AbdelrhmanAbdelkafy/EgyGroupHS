// ============================================================================
// CATALOG — Master items (products) with their own option sets.
// Data sources (REAL, not invented):
//   • Specs/materials/thicknesses  → Namasoft ERP (InvItem, section IS0022 "Prod*")
//   • Images                       → Cloudinary library (recovered factory photos)
// Every master item = product + ITS OWN options → "Request a quote" (no fixed price).
// Two families:  'custom'  = industrial, made-to-order (configurator)
//                'standard'= catalogue product (spec sheet + enquiry)
// ============================================================================

export type L = { ar: string; en: string };

export type Option = {
  key: string;
  label: L;
  /** free = customer types a value (e.g. capacity); choice = pick from values */
  kind: 'choice' | 'free';
  values?: L[];
  hint?: L;
};

export type MasterItem = {
  slug: string;
  family: 'custom' | 'standard';
  category: L;
  name: L;
  tagline: L;
  body: L;
  /** Cloudinary URLs — real factory photos */
  images: string[];
  options: Option[];
  /** real, verifiable spec lines pulled from ERP job history */
  facts?: L[];
};

const CL = 'https://res.cloudinary.com/djrskkszi/image/upload';

// Shared option value sets (materials/thicknesses are REAL — from Namasoft item classes)
const MATERIALS: L[] = [
  { ar: 'استانلس 304', en: 'Stainless 304' },
  { ar: 'استانلس 316', en: 'Stainless 316' },
  { ar: 'استانلس 201', en: 'Stainless 201' },
  { ar: 'كربوستيل', en: 'Carbon steel' },
  { ar: 'استيل مدهون', en: 'Painted steel' },
];

const THICKNESS: L[] = [
  { ar: '1.25 مم', en: '1.25 mm' },
  { ar: '1.5 مم', en: '1.5 mm' },
  { ar: '2 مم', en: '2 mm' },
  { ar: '3 مم', en: '3 mm' },
  { ar: '4 مم', en: '4 mm' },
  { ar: 'حسب التصميم', en: 'To design' },
];

const FINISH: L[] = [
  { ar: 'تشطيب صناعي', en: 'Industrial finish' },
  { ar: 'تشطيب صحي (مصقول)', en: 'Sanitary (polished)' },
  { ar: 'مرآة', en: 'Mirror' },
];

// ---------------------------------------------------------------------------
// MASTER ITEMS
// ---------------------------------------------------------------------------
export const masterItems: MasterItem[] = [
  // ======================= 1. TANKS — the flagship =======================
  {
    slug: 'tanks',
    family: 'custom',
    category: { ar: 'صناعي — حسب الطلب', en: 'Industrial — made to order' },
    name: { ar: 'تنكات وخزانات', en: 'Tanks & Vessels' },
    tagline: { ar: 'الجودة بتبدأ قبل أول لحام.', en: 'Quality starts before the first weld.' },
    body: {
      ar: 'بنصنّع كل أنواع التنكات — تخزين، خلط، ضغط، وصحية — للأغذية والأدوية والكيماويات والصناعات الثقيلة. قبل ما نقص أي صاج، بنفهم التنك هيشتغل في إيه، ونختار الخامة والسُمك والتصميم على الأساس ده. والتشطيب النهائي على مستوى عالمي: سطح يعدّي تدقيق النظافة، ويقاوم التآكل. ولأن الخامة موجودة عندنا وكل خطوة تحت سقف واحد — التنفيذ أسرع، التكلفة أقل، والجودة تحت سيطرتنا بالكامل.',
      en: 'We build every type of tank — storage, mixing, pressure and sanitary — for food, pharmaceutical, chemical and heavy industry. Before a single sheet is cut, we understand what the tank has to do, and choose the material, thickness and design around that. The finish is world-class: a surface that clears a hygiene audit and resists corrosion. And because the material is already on our racks and every stage sits under one roof, delivery is faster, cost is lower, and quality stays entirely under our control.',
    },
    images: [
      `${CL}/v1679741348/IMG_20210601_151353_648ba1ed96.jpg`,
      `${CL}/v1679741346/IMG_20210602_132238_0f6f0b1a9d.jpg`,
      `${CL}/v1679741303/IMG_20210215_135018_84aceb2c36.jpg`,
      `${CL}/v1679741327/IMG_20210619_170708_b909869125.jpg`,
    ],
    facts: [
      { ar: 'تخزين · خلط · ضغط · صحي', en: 'Storage · Mixing · Pressure · Sanitary' },
      { ar: 'استانلس 304 / 316 · كربوستيل', en: 'Stainless 304 / 316 · Carbon steel' },
      { ar: 'أسماك من 1.5 إلى 4 مم حسب التصميم', en: 'Thickness 1.5–4 mm to design' },
      { ar: 'لحام مفحوص RT/PT · توثيق كامل', en: 'RT/PT inspected welds · full documentation' },
    ],
    options: [
      {
        key: 'type',
        label: { ar: 'نوع التنك', en: 'Tank type' },
        kind: 'choice',
        values: [
          { ar: 'تخزين', en: 'Storage' },
          { ar: 'خلط / تقليب', en: 'Mixing' },
          { ar: 'ضغط', en: 'Pressure' },
          { ar: 'صحي (أغذية/أدوية)', en: 'Sanitary (food/pharma)' },
        ],
      },
      { key: 'material', label: { ar: 'الخامة', en: 'Material' }, kind: 'choice', values: MATERIALS.slice(0, 4) },
      { key: 'thickness', label: { ar: 'سُمك الصاج', en: 'Sheet thickness' }, kind: 'choice', values: THICKNESS },
      {
        key: 'capacity',
        label: { ar: 'السعة / المقاس', en: 'Capacity / size' },
        kind: 'free',
        hint: { ar: 'مثال: 5 م³ · أو قطر 150سم × ارتفاع 200سم', en: 'e.g. 5 m³ · or Ø150cm × H200cm' },
      },
      { key: 'finish', label: { ar: 'التشطيب', en: 'Finish' }, kind: 'choice', values: FINISH },
      {
        key: 'extras',
        label: { ar: 'إضافات', en: 'Add-ons' },
        kind: 'free',
        hint: { ar: 'بومبيه، غطاء، أرجل، مقلّب، جاكيت تبريد...', en: 'Dished end, lid, legs, agitator, cooling jacket…' },
      },
    ],
  },

  // ======================= 2. SANITARY PIPING =======================
  {
    slug: 'process-piping',
    family: 'custom',
    category: { ar: 'صناعي — حسب الطلب', en: 'Industrial — made to order' },
    name: { ar: 'خطوط مواسير', en: 'Process Piping' },
    tagline: { ar: 'خط تقدر توثّق كل وصلة فيه.', en: 'A line where every joint is documented.' },
    body: {
      ar: 'خطوط مواسير صحية وصناعية — تُصمَّم وتُصنَّع وتُركَّب وتُختبَر بالموقع. اللحام الأوربيتال بيدّي وصلة متطابقة وقابلة للتكرار، خالية من الشقوق اللي المنتج يستقر فيها. وكل وصلة مفحوصة وموثّقة.',
      en: 'Sanitary and industrial process lines — designed, fabricated, installed and tested on site. Orbital welding gives an identical, repeatable joint with no crevices for product to sit in. Every weld inspected and documented.',
    },
    images: [`${CL}/v1679738568/13_bfdd21487a.jpg`, `${CL}/v1679738739/14_2533049ffb.jpg`, `${CL}/v1679738715/16_6937d14a1f.jpg`],
    facts: [
      { ar: 'لحام أوربيتال 360° · TIG · ليزر', en: 'Orbital 360° · TIG · Laser welding' },
      { ar: 'استانلس 304 / 316 · كربوستيل جدول 40', en: 'Stainless 304/316 · Carbon steel Sch 40' },
      { ar: 'يُركَّب ويُختبَر بالموقع', en: 'Installed and tested on site' },
    ],
    options: [
      { key: 'material', label: { ar: 'الخامة', en: 'Material' }, kind: 'choice', values: MATERIALS.slice(0, 4) },
      {
        key: 'diameter',
        label: { ar: 'القطر', en: 'Diameter' },
        kind: 'choice',
        values: [
          { ar: '½ بوصة', en: '½"' }, { ar: '1 بوصة', en: '1"' }, { ar: '1½ بوصة', en: '1½"' },
          { ar: '2 بوصة', en: '2"' }, { ar: '3 بوصة', en: '3"' }, { ar: '4 بوصة', en: '4"' },
          { ar: 'أكبر / متنوّع', en: 'Larger / mixed' },
        ],
      },
      {
        key: 'welding',
        label: { ar: 'نوع اللحام', en: 'Welding' },
        kind: 'choice',
        values: [
          { ar: 'أوربيتال (صحي)', en: 'Orbital (sanitary)' },
          { ar: 'TIG', en: 'TIG' },
          { ar: 'حسب المواصفة', en: 'To spec' },
        ],
      },
      { key: 'length', label: { ar: 'الطول التقريبي', en: 'Approx. length' }, kind: 'free', hint: { ar: 'بالمتر', en: 'in metres' } },
      {
        key: 'scope',
        label: { ar: 'نطاق العمل', en: 'Scope' },
        kind: 'choice',
        values: [
          { ar: 'تصنيع فقط', en: 'Fabrication only' },
          { ar: 'تصنيع + تركيب', en: 'Fabrication + installation' },
          { ar: 'تسليم مفتاح', en: 'Turnkey' },
        ],
      },
    ],
  },

  // ======================= 3. STAINLESS TABLES (standard) =======================
  {
    slug: 'stainless-tables',
    family: 'standard',
    category: { ar: 'تجهيزات استانلس', en: 'Stainless fixtures' },
    name: { ar: 'ترابيزات استانلس', en: 'Stainless Tables' },
    tagline: { ar: 'سطح شغل يتنضّف بالكامل.', en: 'A work surface that cleans down fully.' },
    body: {
      ar: 'ترابيزات استانلس لمصانع الأغذية والمعامل والمطابخ الصناعية — لحام أملس بلا شقوق، وأرجل قابلة للضبط، وسطح يتحمّل دورات الغسيل اليومية.',
      en: 'Stainless tables for food plants, laboratories and industrial kitchens — smooth crevice-free welds, adjustable legs, and a surface that stands up to daily wash-down.',
    },
    images: [`${CL}/v1727280000/erbt_astanls_styl_20724b113c.jpg`],
    facts: [
      { ar: 'استانلس 304 · سمك 1.5 مم (قياسي)', en: 'Stainless 304 · 1.5 mm (standard)' },
      { ar: 'مقاسات شائعة: 100×90 سم — وحسب الطلب', en: 'Common: 100×90 cm — or to order' },
    ],
    options: [
      { key: 'material', label: { ar: 'الخامة', en: 'Material' }, kind: 'choice', values: MATERIALS.slice(0, 3) },
      { key: 'thickness', label: { ar: 'السُمك', en: 'Thickness' }, kind: 'choice', values: THICKNESS.slice(0, 4) },
      { key: 'size', label: { ar: 'المقاس', en: 'Size' }, kind: 'free', hint: { ar: 'مثال: 100×90 سم', en: 'e.g. 100×90 cm' } },
      {
        key: 'shelf',
        label: { ar: 'رف سفلي', en: 'Under-shelf' },
        kind: 'choice',
        values: [{ ar: 'بدون', en: 'None' }, { ar: 'رف واحد', en: 'One shelf' }, { ar: 'رفين', en: 'Two shelves' }],
      },
    ],
  },

  // ======================= 4. STAINLESS CHAIRS (standard) =======================
  {
    slug: 'stainless-chairs',
    family: 'standard',
    category: { ar: 'تجهيزات استانلس', en: 'Stainless fixtures' },
    name: { ar: 'كراسي استانلس', en: 'Stainless Chairs' },
    tagline: { ar: 'للبيئات اللي بتتغسل كل يوم.', en: 'For environments washed down daily.' },
    body: {
      ar: 'كراسي ومقاعد استانلس لخطوط الإنتاج والمعامل وغرف النظافة — بتقاوم التآكل ودورات التنظيف، ومصمّمة تتنضّف بالكامل.',
      en: 'Stainless chairs and stools for production lines, laboratories and clean rooms — corrosion-resistant, cleaning-cycle proof, and designed to clean down completely.',
    },
    images: [`${CL}/v1727280001/krsa_astanls_styl_2c8b64e552.jpg`, `${CL}/v1727280002/krsy_astanls_styl_b5e454c7eb.jpg`],
    facts: [{ ar: 'استانلس 304 / 201', en: 'Stainless 304 / 201' }],
    options: [
      { key: 'material', label: { ar: 'الخامة', en: 'Material' }, kind: 'choice', values: MATERIALS.slice(0, 3) },
      {
        key: 'style',
        label: { ar: 'النوع', en: 'Type' },
        kind: 'choice',
        values: [
          { ar: 'كرسي بظهر', en: 'Chair with back' },
          { ar: 'تابوريه (بدون ظهر)', en: 'Stool (backless)' },
          { ar: 'قابل لضبط الارتفاع', en: 'Height-adjustable' },
        ],
      },
      { key: 'qty', label: { ar: 'الكمية', en: 'Quantity' }, kind: 'free', hint: { ar: 'عدد', en: 'pieces' } },
    ],
  },

  // ======================= 5. SAFETY LADDERS & STAIRS =======================
  {
    slug: 'ladders-stairs',
    family: 'custom',
    category: { ar: 'صناعي — حسب الطلب', en: 'Industrial — made to order' },
    name: { ar: 'سلالم ودرج سيفتي', en: 'Safety Ladders & Stairs' },
    tagline: { ar: 'وصول آمن، مصنوع للمصنع.', en: 'Safe access, built for the plant.' },
    body: {
      ar: 'سلالم ودرج ومنصات وصول صناعية — بدرجات مانعة للانزلاق وهندريل مطابق للاشتراطات، محسوبة على الأحمال الفعلية للموقع.',
      en: 'Industrial ladders, stairs and access platforms — anti-slip treads and compliant handrails, engineered to the actual site loads.',
    },
    images: [`${CL}/v1679741340/IMG_20210429130552_5945176dda.jpg`, `${CL}/v1679741318/IMG_20210429130536_ca4c934155.jpg`],
    facts: [
      { ar: 'استيل مدهون · استانلس 304', en: 'Painted steel · Stainless 304' },
      { ar: 'مثال منفّذ: 450×100 سم، ارتفاع 500 سم، 5 درجات', en: 'Built example: 450×100 cm, H 500 cm, 5 treads' },
    ],
    options: [
      { key: 'material', label: { ar: 'الخامة', en: 'Material' }, kind: 'choice', values: [MATERIALS[0], MATERIALS[4], MATERIALS[3]] },
      {
        key: 'kind',
        label: { ar: 'النوع', en: 'Type' },
        kind: 'choice',
        values: [
          { ar: 'سلم رأسي', en: 'Vertical ladder' },
          { ar: 'درج بدرجات', en: 'Stepped stairs' },
          { ar: 'منصة وصول', en: 'Access platform' },
        ],
      },
      { key: 'height', label: { ar: 'الارتفاع', en: 'Height' }, kind: 'free', hint: { ar: 'بالسنتيمتر', en: 'in cm' } },
      {
        key: 'handrail',
        label: { ar: 'هندريل', en: 'Handrail' },
        kind: 'choice',
        values: [{ ar: 'جانب واحد', en: 'One side' }, { ar: 'الجانبين', en: 'Both sides' }, { ar: 'بدون', en: 'None' }],
      },
    ],
  },

  // ======================= 6. PLATFORMS =======================
  {
    slug: 'platforms',
    family: 'custom',
    category: { ar: 'صناعي — حسب الطلب', en: 'Industrial — made to order' },
    name: { ar: 'منصات وقواعد', en: 'Platforms & Bases' },
    tagline: { ar: 'محسوبة على الحمل، مش على التخمين.', en: 'Engineered to the load, not to a guess.' },
    body: {
      ar: 'منصات عمل وقواعد ماكينات — تُحسب على الأحمال والاهتزاز الفعلي، وتُصنَّع بالسُمك المناسب للخدمة.',
      en: 'Work platforms and machine bases — calculated against real loads and vibration, fabricated at the right thickness for the duty.',
    },
    images: [`${CL}/v1679741310/IMG_20210501154446_7269232141.jpg`],
    facts: [{ ar: 'استيل · استانلس · أسماك حتى 15 مم', en: 'Steel · Stainless · up to 15 mm plate' }],
    options: [
      { key: 'material', label: { ar: 'الخامة', en: 'Material' }, kind: 'choice', values: MATERIALS },
      { key: 'size', label: { ar: 'المقاس', en: 'Size' }, kind: 'free', hint: { ar: 'طول × عرض × ارتفاع', en: 'L × W × H' } },
      { key: 'load', label: { ar: 'الحمل المتوقع', en: 'Expected load' }, kind: 'free', hint: { ar: 'كجم / طن', en: 'kg / tonnes' } },
    ],
  },
];

export const catalogPage = {
  eyebrow: { ar: 'الكتالوج', en: 'Catalogue' } as L,
  title: { ar: 'اللي بنصنّعه.', en: 'What we build.' } as L,
  intro: {
    ar: 'كل منتج هنا اتنفّذ فعلاً في مصنعنا. اختار المواصفات اللي محتاجها واطلب عرض سعر — المكتب الفني يراجعها ويرجعلك بنطاق وسعر.',
    en: 'Every product here has actually been built in our shop. Pick the specification you need and request a quote — the technical office reviews it and returns a scope and a price.',
  } as L,
  filters: {
    all: { ar: 'الكل', en: 'All' } as L,
    custom: { ar: 'صناعي — حسب الطلب', en: 'Industrial — made to order' } as L,
    standard: { ar: 'تجهيزات استانلس', en: 'Stainless fixtures' } as L,
  },
  quoteCta: { ar: 'اطلب عرض سعر', en: 'Request a quote' } as L,
  optionsTitle: { ar: 'حدّد مواصفاتك', en: 'Specify what you need' } as L,
  factsTitle: { ar: 'المواصفات', en: 'Specifications' } as L,
  sendTitle: { ar: 'ابعت الطلب', en: 'Send request' } as L,
  backToCatalog: { ar: 'كل المنتجات', en: 'All products' } as L,
};
