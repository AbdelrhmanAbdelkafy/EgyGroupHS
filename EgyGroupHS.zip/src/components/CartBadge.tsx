'use client';

import Link from 'next/link';
import { Locale } from '@/lib/i18n';
import { useCart } from '@/lib/cart';
import { Icon } from '@/components/Icon';

/**
 * Header badge. Stays out of the way until the customer has actually
 * put something in the brief — an empty cart icon is just noise.
 */
export function CartBadge({ locale }: { locale: Locale }) {
  const { count, ready } = useCart();
  if (!ready || count === 0) return null;
  const isAr = locale === 'ar';

  return (
    <Link
      href={`/${locale}/cart`}
      className="relative inline-flex items-center gap-2 rounded-md border border-amber/40 bg-amber/10 px-3 py-2 text-[13.5px] font-semibold text-amber transition hover:bg-amber/20"
      aria-label={isAr ? `طلبك — ${count} صنف` : `Your request — ${count} items`}
    >
      <Icon name="check" className="h-[14px] w-[14px]" strokeWidth={2.6} />
      <span className="hidden sm:inline">{isAr ? 'طلبك' : 'Request'}</span>
      <span className="flex h-[19px] min-w-[19px] items-center justify-center rounded-full bg-amber px-1 font-mono text-[11px] font-bold text-[#161310]">
        {count}
      </span>
    </Link>
  );
}
