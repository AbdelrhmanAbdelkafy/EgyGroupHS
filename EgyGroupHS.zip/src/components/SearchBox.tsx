'use client';

import { useEffect, useMemo, useRef, useState, useCallback } from 'react';
import { useRouter } from 'next/navigation';
import { Locale } from '@/lib/i18n';
import { buildIndex, search, SearchHit } from '@/lib/search';
import { Icon } from '@/components/Icon';

// ============================================================================
// Autocomplete search.
//
// Opens on click or "/" (and ⌘K), filters as you type, and is driven entirely
// by the keyboard: arrows to move, Enter to go, Escape to close. On a phone it
// takes over the screen, because a dropdown on a 380px viewport is unusable.
// ============================================================================

const T = {
  placeholder: { ar: 'دوّر على منتج أو خدمة…', en: 'Search products and services…' },
  short: { ar: 'ابدأ الكتابة…', en: 'Start typing…' },
  none: { ar: 'مفيش نتائج.', en: 'No results.' },
  noneHint: { ar: 'جرّب كلمة تانية — أو اطلب معاينة وإحنا نوصلك.', en: 'Try another word — or request a site visit and we will reach you.' },
  hint: { ar: 'للتنقّل ↑↓ · للفتح ↵ · للخروج esc', en: '↑↓ to move · ↵ to open · esc to close' },
};

export function SearchBox({ locale }: { locale: Locale }) {
  const isAr = locale === 'ar';
  const t = <K extends keyof typeof T>(k: K) => T[k][locale];
  const router = useRouter();

  const [open, setOpen] = useState(false);
  const [q, setQ] = useState('');
  const [active, setActive] = useState(0);
  const inputRef = useRef<HTMLInputElement>(null);
  const boxRef = useRef<HTMLDivElement>(null);

  // built once per locale — the corpus is static
  const index = useMemo(() => buildIndex(locale), [locale]);
  const hits = useMemo(() => search(index, q), [index, q]);

  useEffect(() => setActive(0), [q]);

  // "/" to open — the shortcut people already expect. ⌘K too.
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const el = document.activeElement;
      const typing = el instanceof HTMLInputElement || el instanceof HTMLTextAreaElement;
      if (!open && !typing && (e.key === '/' || ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k'))) {
        e.preventDefault();
        setOpen(true);
      }
      if (e.key === 'Escape') setOpen(false);
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [open]);

  useEffect(() => {
    if (open) setTimeout(() => inputRef.current?.focus(), 20);
    else { setQ(''); setActive(0); }
  }, [open]);

  // click-away
  useEffect(() => {
    if (!open) return;
    const onDown = (e: MouseEvent) => {
      if (boxRef.current && !boxRef.current.contains(e.target as Node)) setOpen(false);
    };
    document.addEventListener('mousedown', onDown);
    return () => document.removeEventListener('mousedown', onDown);
  }, [open]);

  const go = useCallback((hit: SearchHit) => {
    setOpen(false);
    router.push(hit.href);
  }, [router]);

  const onKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'ArrowDown') { e.preventDefault(); setActive((i) => Math.min(i + 1, hits.length - 1)); }
    else if (e.key === 'ArrowUp') { e.preventDefault(); setActive((i) => Math.max(i - 1, 0)); }
    else if (e.key === 'Enter' && hits[active]) { e.preventDefault(); go(hits[active]); }
  };

  const kindColour = (k: SearchHit['kind']) =>
    k === 'product' ? 'text-amber' : k === 'service' ? 'text-steel-lt' : 'text-muted';

  return (
    <>
      <button
        onClick={() => setOpen(true)}
        aria-label={t('placeholder')}
        className="inline-flex items-center gap-2 rounded-md border border-line px-3 py-2 text-[13px] text-muted transition hover:border-steel-lt hover:text-paper"
      >
        <Icon name="search" className="h-[15px] w-[15px]" strokeWidth={2} />
        <span className="hidden lg:inline">{isAr ? 'بحث' : 'Search'}</span>
        <kbd className="hidden rounded border border-line px-1.5 py-0.5 font-mono text-[10px] text-steel-lt lg:inline">/</kbd>
      </button>

      {open && (
        <div className="fixed inset-0 z-[200] bg-ink/80 backdrop-blur-sm" role="dialog" aria-modal="true">
          <div className="mx-auto mt-[12vh] max-w-[620px] px-4 sm:px-7">
            <div ref={boxRef} className="overflow-hidden rounded-xl border border-line bg-ink-2 shadow-2xl">
              <div className="flex items-center gap-3 border-b border-line px-4">
                <Icon name="search" className="h-[17px] w-[17px] shrink-0 text-steel-lt" strokeWidth={2} />
                <input
                  ref={inputRef}
                  value={q}
                  onChange={(e) => setQ(e.target.value)}
                  onKeyDown={onKeyDown}
                  placeholder={t('placeholder')}
                  className="w-full bg-transparent py-4 text-[1rem] text-paper outline-none placeholder:text-muted"
                  autoComplete="off"
                  spellCheck={false}
                />
                <button
                  onClick={() => setOpen(false)}
                  className="shrink-0 rounded border border-line px-2 py-1 font-mono text-[10px] text-steel-lt transition hover:text-paper"
                >
                  esc
                </button>
              </div>

              <div className="max-h-[52vh] overflow-y-auto">
                {q.trim().length < 2 ? (
                  <p className="px-4 py-8 text-center text-[0.9rem] text-muted">{t('short')}</p>
                ) : hits.length === 0 ? (
                  <div className="px-4 py-8 text-center">
                    <p className="text-[0.95rem]">{t('none')}</p>
                    <p className="mt-1.5 text-[0.82rem] text-muted">{t('noneHint')}</p>
                  </div>
                ) : (
                  <ul>
                    {hits.map((h, i) => (
                      <li key={h.href + i}>
                        <button
                          onMouseEnter={() => setActive(i)}
                          onClick={() => go(h)}
                          className={`flex w-full items-start gap-3 border-b border-line/60 px-4 py-3 text-start transition last:border-none ${
                            i === active ? 'bg-amber/[0.08]' : ''
                          }`}
                        >
                          <span className={`mt-[3px] shrink-0 font-mono text-[9.5px] uppercase tracking-[0.12em] ${kindColour(h.kind)}`}>
                            {h.kindLabel}
                          </span>
                          <span className="min-w-0 flex-1">
                            <span className="block text-[0.98rem] text-paper">{h.title}</span>
                            {h.subtitle && (
                              <span className="mt-0.5 block truncate text-[0.8rem] text-muted">{h.subtitle}</span>
                            )}
                          </span>
                          {i === active && (
                            <Icon name="arrow" className="mt-[5px] h-[13px] w-[13px] shrink-0 text-amber flip-x" strokeWidth={2.4} />
                          )}
                        </button>
                      </li>
                    ))}
                  </ul>
                )}
              </div>

              {hits.length > 0 && (
                <div className="hidden border-t border-line px-4 py-2 text-center font-mono text-[10px] text-steel-lt sm:block">
                  {t('hint')}
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </>
  );
}
