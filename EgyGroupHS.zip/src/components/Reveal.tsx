'use client';

import { useEffect } from 'react';

// Attaches IntersectionObserver to all .reveal elements and a scroll bg to header.
export function Reveal() {
  useEffect(() => {
    const io = new IntersectionObserver(
      (entries) => {
        entries.forEach((e) => {
          if (e.isIntersecting) {
            e.target.classList.add('in');
            io.unobserve(e.target);
          }
        });
      },
      { threshold: 0.1 }
    );
    document.querySelectorAll('.reveal').forEach((el) => io.observe(el));

    const header = document.querySelector('header');
    const onScroll = () => {
      if (header) header.style.background = window.scrollY > 40 ? 'rgba(20,22,24,.92)' : 'rgba(20,22,24,.72)';
    };
    window.addEventListener('scroll', onScroll);
    return () => {
      io.disconnect();
      window.removeEventListener('scroll', onScroll);
    };
  }, []);

  return null;
}
