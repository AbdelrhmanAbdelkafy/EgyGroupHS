'use client';

import { useCallback, useEffect, useRef, useState } from 'react';
import { createPortal } from 'react-dom';
import { Locale } from '@/lib/i18n';

// ============================================================================
// Image viewer — zoom, pan, and a slider across a product's photos.
//
// ON PROTECTING THE IMAGES
//
// The measures here — no context menu, no drag, no iOS save sheet — stop the
// casual copy, and that is all they can honestly claim. A browser cannot display
// a photo without first receiving it, so anyone willing to open the network tab
// or press the screenshot key has the file. Canvas tricks and blob URLs only
// move where it sits; they don't keep anyone out.
//
// What actually survives copying is the watermark burnt into the pixels at
// upload time. That's in the content manager, not here. This is the speed bump.
// ============================================================================

import { photoSrc } from '@/lib/photo';

export function Lightbox({
  images,
  index,
  onClose,
  onIndex,
  locale,
  alt,
}: {
  images: string[];
  index: number;
  onClose: () => void;
  onIndex: (i: number) => void;
  locale: Locale;
  alt: string;
}) {
  const isAr = locale === 'ar';
  const [zoom, setZoom] = useState(1);
  const [pan, setPan] = useState({ x: 0, y: 0 });
  const [mounted, setMounted] = useState(false);
  const drag = useRef<{ x: number; y: number; px: number; py: number } | null>(null);
  const pinch = useRef<{ d: number; z: number } | null>(null);
  const swipe = useRef<{ x: number; t: number } | null>(null);

  useEffect(() => setMounted(true), []);

  const reset = useCallback(() => {
    setZoom(1);
    setPan({ x: 0, y: 0 });
  }, []);

  // a new photo starts unzoomed — carrying the previous zoom across is disorienting
  useEffect(() => reset(), [index, reset]);

  const go = useCallback(
    (d: -1 | 1) => {
      if (images.length < 2) return;
      onIndex((index + d + images.length) % images.length);
    },
    [index, images.length, onIndex]
  );

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
      // arrows follow reading order: in RTL, "next" is to the left
      else if (e.key === 'ArrowRight') go(isAr ? -1 : 1);
      else if (e.key === 'ArrowLeft') go(isAr ? 1 : -1);
      else if (e.key === '+' || e.key === '=') setZoom((z) => Math.min(4, z + 0.5));
      else if (e.key === '-') setZoom((z) => Math.max(1, z - 0.5));
      else if (e.key === '0') reset();
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [go, onClose, reset, isAr]);

  useEffect(() => {
    const prev = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    return () => {
      document.body.style.overflow = prev;
    };
  }, []);

  const onWheel = (e: React.WheelEvent) => {
    e.preventDefault();
    setZoom((z) => Math.min(4, Math.max(1, z - e.deltaY * 0.002)));
  };

  const onDown = (e: React.MouseEvent) => {
    if (zoom <= 1) return;
    drag.current = { x: e.clientX, y: e.clientY, px: pan.x, py: pan.y };
  };
  const onMove = (e: React.MouseEvent) => {
    if (!drag.current) return;
    setPan({ x: drag.current.px + (e.clientX - drag.current.x), y: drag.current.py + (e.clientY - drag.current.y) });
  };
  const onUp = () => {
    drag.current = null;
  };

  const onTouchStart = (e: React.TouchEvent) => {
    if (e.touches.length === 2) {
      const [a, b] = [e.touches[0], e.touches[1]];
      pinch.current = { d: Math.hypot(a.clientX - b.clientX, a.clientY - b.clientY), z: zoom };
    } else if (e.touches.length === 1) {
      if (zoom > 1) drag.current = { x: e.touches[0].clientX, y: e.touches[0].clientY, px: pan.x, py: pan.y };
      else swipe.current = { x: e.touches[0].clientX, t: Date.now() };
    }
  };

  const onTouchMove = (e: React.TouchEvent) => {
    if (e.touches.length === 2 && pinch.current) {
      const [a, b] = [e.touches[0], e.touches[1]];
      const d = Math.hypot(a.clientX - b.clientX, a.clientY - b.clientY);
      setZoom(Math.min(4, Math.max(1, pinch.current.z * (d / pinch.current.d))));
    } else if (e.touches.length === 1 && drag.current) {
      setPan({
        x: drag.current.px + (e.touches[0].clientX - drag.current.x),
        y: drag.current.py + (e.touches[0].clientY - drag.current.y),
      });
    }
  };

  const onTouchEnd = (e: React.TouchEvent) => {
    pinch.current = null;
    drag.current = null;
    // swipe only while unzoomed — otherwise panning would flip the photo
    if (swipe.current && zoom <= 1 && e.changedTouches.length === 1) {
      const dx = e.changedTouches[0].clientX - swipe.current.x;
      if (Math.abs(dx) > 60 && Date.now() - swipe.current.t < 600) go(dx > 0 ? (isAr ? 1 : -1) : isAr ? -1 : 1);
    }
    swipe.current = null;
  };

  if (!mounted) return null;

  const btn =
    'grid h-11 w-11 place-items-center rounded-full border border-line bg-ink/80 text-paper backdrop-blur transition hover:border-amber hover:text-amber disabled:opacity-30';

  return createPortal(
    <div
      className="fixed inset-0 z-[300] flex flex-col bg-ink/97 select-none"
      role="dialog"
      aria-modal="true"
      onContextMenu={(e) => e.preventDefault()}
    >
      {/* top bar */}
      <div className="flex shrink-0 items-center justify-between gap-3 px-4 py-3">
        <span className="font-mono text-[12px] text-steel-lt">
          {images.length > 1 ? `${index + 1} / ${images.length}` : ''}
        </span>
        <div className="flex items-center gap-2">
          <button onClick={() => setZoom((z) => Math.max(1, z - 0.5))} disabled={zoom <= 1} aria-label="بعّد" className={btn}>
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" className="h-4 w-4">
              <path d="M5 12h14" />
            </svg>
          </button>
          <span className="w-[46px] text-center font-mono text-[12px] text-muted">{Math.round(zoom * 100)}%</span>
          <button onClick={() => setZoom((z) => Math.min(4, z + 0.5))} disabled={zoom >= 4} aria-label="قرّب" className={btn}>
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" className="h-4 w-4">
              <path d="M12 5v14M5 12h14" />
            </svg>
          </button>
          <button onClick={onClose} aria-label="إغلاق" className={btn}>
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" className="h-4 w-4">
              <path d="M6 6l12 12M18 6L6 18" />
            </svg>
          </button>
        </div>
      </div>

      {/* stage */}
      <div
        className="relative flex-1 overflow-hidden"
        onWheel={onWheel}
        onMouseDown={onDown}
        onMouseMove={onMove}
        onMouseUp={onUp}
        onMouseLeave={onUp}
        onTouchStart={onTouchStart}
        onTouchMove={onTouchMove}
        onTouchEnd={onTouchEnd}
        style={{ cursor: zoom > 1 ? (drag.current ? 'grabbing' : 'grab') : 'zoom-in' }}
        onClick={() => zoom === 1 && setZoom(2)}
      >
        <img
          src={photoSrc(images[index], 1600)}
          alt={alt}
          draggable={false}
          onContextMenu={(e) => e.preventDefault()}
          className="pointer-events-none absolute inset-0 m-auto max-h-full max-w-full object-contain"
          style={{
            transform: `translate(${pan.x}px, ${pan.y}px) scale(${zoom})`,
            transition: drag.current || pinch.current ? 'none' : 'transform 180ms ease-out',
            WebkitTouchCallout: 'none',
            WebkitUserSelect: 'none',
            userSelect: 'none',
          }}
        />

        {images.length > 1 && (
          <>
            <button
              onClick={(e) => {
                e.stopPropagation();
                go(isAr ? 1 : -1);
              }}
              aria-label="السابق"
              className={`absolute start-3 top-1/2 -translate-y-1/2 ${btn}`}
            >
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" className="h-4 w-4">
                <path d={isAr ? 'M9 6l6 6-6 6' : 'M15 6l-6 6 6 6'} />
              </svg>
            </button>
            <button
              onClick={(e) => {
                e.stopPropagation();
                go(isAr ? -1 : 1);
              }}
              aria-label="التالي"
              className={`absolute end-3 top-1/2 -translate-y-1/2 ${btn}`}
            >
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" className="h-4 w-4">
                <path d={isAr ? 'M15 6l-6 6 6 6' : 'M9 6l6 6-6 6'} />
              </svg>
            </button>
          </>
        )}
      </div>

      {/* filmstrip */}
      {images.length > 1 && (
        <div className="flex shrink-0 justify-center gap-2 overflow-x-auto px-4 py-3">
          {images.map((src, i) => (
            <button
              key={i}
              onClick={() => onIndex(i)}
              aria-label={`صورة ${i + 1}`}
              className={`h-[52px] w-[52px] shrink-0 overflow-hidden rounded-md border-2 transition ${
                i === index ? 'border-amber' : 'border-transparent opacity-50 hover:opacity-100'
              }`}
            >
              <img src={photoSrc(src, 400)} alt="" draggable={false} className="h-full w-full object-cover" />
            </button>
          ))}
        </div>
      )}

      <p className="shrink-0 pb-3 text-center font-mono text-[10px] text-steel-lt">
        {isAr ? 'اسحب للتنقّل · قرّب بإصبعين · esc للخروج' : 'Swipe to move · pinch to zoom · esc to close'}
      </p>
    </div>,
    document.body
  );
}
