'use client';

import { useEffect, useState } from 'react';
import { createPortal } from 'react-dom';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { Locale } from '@/lib/i18n';
import { nav, cta } from '@/content/site';
import { Icon } from './Icon';

// ============================================================================
// Mobile navigation.
//
// Below 1024px the header's <nav> is hidden, so without this there is no route
// to the catalogue on a phone at all.
//
// The drawer is portalled to <body>, and that is not a stylistic choice. The
// header carries `backdrop-blur`, and a backdrop-filter makes its element a
// containing block for any fixed-position descendant. A drawer rendered inside
// it resolves `inset-y-0` against the 74px header rather than the viewport, so
// it collapses into a stub and its links get zero height. Portalling puts the
// drawer back in the viewport's coordinate space.
//
// It opens from the inline-end, because that is where the button is: a panel
// that flies in from the opposite side of the control you just pressed reads
// as a glitch.
// ============================================================================

export function MobileNav({ locale }: { locale: Locale }) {
  const t = <T extends { ar: string; en: string }>(x: T) => x[locale];
  const isAr = locale === 'ar';
  const [open, setOpen] = useState(false);
  const [mounted, setMounted] = useState(false);
  const pathname = usePathname();

  useEffect(() => setMounted(true), []);

  // navigating closes it — otherwise the drawer covers the page you asked for
  useEffect(() => setOpen(false), [pathname]);

  // the page behind must not scroll while the drawer is over it
  useEffect(() => {
    if (!open) return;
    const prev = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    return () => {
      document.body.style.overflow = prev;
    };
  }, [open]);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => e.key === 'Escape' && setOpen(false);
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, []);

  // closed: sit just off the end edge. RTL's end is the left, so it leaves left.
  const hidden = isAr ? '-translate-x-full' : 'translate-x-full';

  const drawer = (
    <>
      <div
        onClick={() => setOpen(false)}
        className={`fixed inset-0 z-[190] bg-ink/70 backdrop-blur-sm transition-opacity duration-200 lg:hidden ${
          open ? 'opacity-100' : 'pointer-events-none opacity-0'
        }`}
        aria-hidden="true"
      />

      <aside
        dir={isAr ? 'rtl' : 'ltr'}
        className={`fixed inset-y-0 end-0 z-[195] flex w-[86%] max-w-[340px] flex-col border-s border-line bg-ink-2 shadow-2xl transition-transform duration-300 ease-out lg:hidden ${
          open ? 'translate-x-0' : hidden
        }`}
        role="dialog"
        aria-modal="true"
        aria-hidden={!open}
      >
        <div className="flex h-[74px] shrink-0 items-center justify-between border-b border-line px-5">
          <span className="font-mono text-[11px] uppercase tracking-[0.18em] text-steel-lt">
            {isAr ? 'القائمة' : 'Menu'}
          </span>
          <button
            onClick={() => setOpen(false)}
            aria-label={isAr ? 'إغلاق' : 'Close'}
            className="inline-flex h-[34px] w-[34px] items-center justify-center rounded-md border border-line text-muted transition hover:text-paper"
          >
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" className="h-[15px] w-[15px]">
              <path d="M6 6l12 12M18 6L6 18" />
            </svg>
          </button>
        </div>

        <nav className="min-h-0 flex-1 overflow-y-auto px-3 py-4">
          <ul className="flex flex-col gap-1">
            {nav.map((item) => {
              const href = `/${locale}${item.href}`;
              const active = pathname === href;
              return (
                <li key={item.href}>
                  <Link
                    href={href}
                    className={`flex items-center justify-between rounded-lg px-4 py-[13px] text-[1rem] transition ${
                      active ? 'bg-amber/12 font-semibold text-amber' : 'text-paper hover:bg-ink'
                    }`}
                  >
                    {t(item.label)}
                    <Icon name="arrow" className="h-[13px] w-[13px] opacity-40 flip-x" strokeWidth={2.4} />
                  </Link>
                </li>
              );
            })}
          </ul>

          {/* the catalogue's two halves, reachable in one tap */}
          <div className="mt-5 border-t border-line pt-4">
            <span className="mb-2 block px-4 font-mono text-[10px] uppercase tracking-[0.16em] text-steel-lt">
              {isAr ? 'الكتالوج' : 'Catalogue'}
            </span>
            <ul className="flex flex-col gap-1">
              <li>
                <Link href={`/${locale}/catalog?f=custom`} className="block rounded-lg px-4 py-[11px] text-[0.92rem] text-muted transition hover:bg-ink hover:text-paper">
                  {isAr ? 'صناعي — حسب الطلب' : 'Industrial — made to order'}
                </Link>
              </li>
              <li>
                <Link href={`/${locale}/catalog?f=standard`} className="block rounded-lg px-4 py-[11px] text-[0.92rem] text-muted transition hover:bg-ink hover:text-paper">
                  {isAr ? 'مخزون وتوريد' : 'Stock & supply'}
                </Link>
              </li>
              <li>
                <Link href={`/${locale}/cart`} className="block rounded-lg px-4 py-[11px] text-[0.92rem] text-muted transition hover:bg-ink hover:text-paper">
                  {isAr ? 'السلة' : 'Cart'}
                </Link>
              </li>
            </ul>
          </div>

          <div className="mt-5 border-t border-line pt-4">
            <Link
              href={`/${isAr ? 'en' : 'ar'}`}
              className="block rounded-lg px-4 py-[11px] font-mono text-[0.85rem] tracking-widest text-muted transition hover:bg-ink hover:text-paper"
            >
              {isAr ? 'ENGLISH' : 'عربي'}
            </Link>
          </div>
        </nav>

        <div className="shrink-0 border-t border-line p-4">
          <Link
            href={`/${locale}/site-visit`}
            className="flex w-full items-center justify-center gap-2 rounded-md bg-amber px-5 py-[14px] text-[15px] font-semibold text-[#161310] transition hover:bg-amber-hi"
          >
            {t(cta.primary)}
            <Icon name="arrow" className="h-[15px] w-[15px] flip-x" strokeWidth={2.4} />
          </Link>
        </div>
      </aside>
    </>
  );

  return (
    <>
      <button
        onClick={() => setOpen(true)}
        aria-label={isAr ? 'القائمة' : 'Menu'}
        aria-expanded={open}
        className="inline-flex h-[38px] w-[38px] items-center justify-center rounded-md border border-line text-paper transition hover:border-amber hover:text-amber lg:hidden"
      >
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" className="h-[18px] w-[18px]">
          <path d="M3 6h18M3 12h18M3 18h18" />
        </svg>
      </button>

      {/* out of the header, into the viewport */}
      {mounted && createPortal(drawer, document.body)}
    </>
  );
}
