import Link from 'next/link';
import Image from 'next/image';
import { Locale } from '@/lib/i18n';
import { footer, company } from '@/content/site';

export function Footer({ locale }: { locale: Locale }) {
  const t = <T extends { ar: string; en: string }>(x: T) => x[locale];

  return (
    <footer className="border-t border-line pb-9 pt-[70px]">
      <div className="mx-auto max-w-content px-7">
        <div className="grid grid-cols-1 gap-10 border-b border-line pb-12 md:grid-cols-2 lg:grid-cols-[1.5fr_1fr_1fr_1.1fr]">
          <div>
            <Link href={`/${locale}`} className="mb-[18px] flex items-center gap-3">
              <Image src="/assets/logo.png" alt="" width={44} height={44} className="h-11 w-11 rounded-md object-cover" />
              <span className="leading-tight">
                <span className="block text-[15px] font-extrabold">{t(company.nameShort)}</span>
                <span className="block font-mono text-[10px] font-semibold tracking-[0.24em] text-amber">{company.brandTag}</span>
              </span>
            </Link>
            <p className="max-w-[290px] text-[0.92rem] leading-relaxed text-muted">{t(footer.blurb)}</p>
          </div>

          {footer.cols.map((col, i) => (
            <div key={i}>
              <h5 className="mb-[18px] font-mono text-xs uppercase tracking-[0.16em] text-steel-lt">{t(col.head)}</h5>
              {col.links.map((lnk, j) => (
                <Link key={j} href={`/${locale}${lnk.href}`} className="mb-3 block text-[0.93rem] text-muted transition hover:text-amber">
                  {t(lnk.label)}
                </Link>
              ))}
              {i === 2 && (
                <a href={`https://${company.domain}`} className="mb-3 block text-[0.93rem] text-muted transition hover:text-amber">
                  {company.domain}
                </a>
              )}
            </div>
          ))}
        </div>

        <div className="flex flex-wrap items-center justify-between gap-3 pt-[26px]">
          <p className="text-[0.85rem] text-muted">{t(footer.rights)}</p>
          <p className="font-mono text-[0.8rem] text-steel-lt">ISO 9001 · ASME BPE · {locale === 'ar' ? 'السلامة' : 'SAFETY'}</p>
        </div>
      </div>
    </footer>
  );
}
