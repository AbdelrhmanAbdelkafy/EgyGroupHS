import React from 'react';

const paths: Record<string, React.ReactNode> = {
  drop: <path d="M12 2v20M6 6c0 3 2 4 6 4s6-1 6-4M4 22c0-5 3-8 8-8s8 3 8 8" />,
  flask: <path d="M10 2h4M12 2v6l-5 9a3 3 0 0 0 3 5h4a3 3 0 0 0 3-5l-5-9M8 15h8" />,
  beaker: <path d="M9 3h6v5l4 8a3 3 0 0 1-3 4H8a3 3 0 0 1-3-4l4-8V3zM7 15h10" />,
  wave: <path d="M3 12h7l2-4 3 8 2-4h4" />,
  spark: <path d="M12 2v7M8 9h8l-2 6H10zM10 21h4" />,
  ring: (
    <>
      <circle cx="12" cy="12" r="8" />
      <path d="M12 4a8 8 0 0 1 0 16" />
    </>
  ),
  pipe: <path d="M3 8h14a4 4 0 0 1 0 8H3M6 5v6M10 5v6" />,
  roll: <path d="M4 12c4-6 12-6 16 0M4 12c4 6 12 6 16 0" />,
  bend: (
    <>
      <path d="M3 17L10 6l4 3 7-4" />
      <path d="M3 21h18" />
    </>
  ),
  target: (
    <>
      <circle cx="12" cy="12" r="7" />
      <circle cx="12" cy="12" r="2.5" />
    </>
  ),
  grid: <path d="M4 7h16M4 12h16M4 17h16M8 4v16" />,
  home: <path d="M4 20V8l8-5 8 5v12M9 20v-6h6v6" />,
  bolt: <path d="M14 3l-4 7h5l-4 8M5 14h4M15 14h4" />,
  check: (
    <>
      <path d="M4 12l4 4 12-12" />
      <path d="M4 20h16" />
    </>
  ),
  grad: <path d="M12 3 2 8l10 5 10-5-10-5zM6 10v6l6 3 6-3v-6" />,
  chat: <path d="M4 5h16v11H8l-4 4V5zM8 9h8M8 12h5" />,
  shield: <path d="M12 3l8 4v5c0 5-3.5 7.5-8 9-4.5-1.5-8-4-8-9V7l8-4zM9 12l2 2 4-4" />,
  arrow: <path d="M5 12h14M13 6l6 6-6 6" />,
  tick: <path d="M20 6 9 17l-5-5" />,
  loop: <path d="M4 12a8 8 0 0 1 14-5.3L20 8M20 12a8 8 0 0 1-14 5.3L4 16M20 4v4h-4M4 20v-4h4" />,
};

export function Icon({ name, className, strokeWidth = 1.6 }: { name: string; className?: string; strokeWidth?: number }) {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={strokeWidth} className={className} aria-hidden="true">
      {paths[name] ?? null}
    </svg>
  );
}
