import { Locale } from '@/lib/i18n';
import { company, services } from '@/content/site';

// Organization + Service schema. Fed to search engines and AI answer engines (GEO).
// Uses real, verifiable facts; contact placeholders are omitted until provided.
export function OrganizationJsonLd({ locale }: { locale: Locale }) {
  const data = {
    '@context': 'https://schema.org',
    '@type': 'Organization',
    name: company.nameFull[locale],
    alternateName: locale === 'ar' ? 'Egyptian Group Hard Steel' : 'المجموعة المصرية',
    url: `https://${company.domain}/${locale}`,
    logo: `https://${company.domain}/assets/logo.png`,
    foundingDate: '2011',
    description:
      locale === 'ar'
        ? 'تصنيع معدني صحي لقطاعات الأغذية والأدوية والكيماويات — قص ليزر، لحام أوربيتال صحي وفق ASME BPE، تحليل مواد داخلي وفحص NDT.'
        : 'Hygienic metal fabrication for food, pharmaceutical and chemical industries — laser cutting, orbital sanitary welding to ASME BPE, in-house material testing and NDT.',
    areaServed: { '@type': 'Country', name: 'Egypt' },
    knowsAbout: [
      'orbital welding',
      'ASME BPE fabrication',
      'sanitary stainless steel fabrication',
      'laser cutting',
      'tank fabrication',
      'pressure vessels',
      'heat exchangers',
      'CNC machining',
    ],
    address: {
      '@type': 'PostalAddress',
      addressCountry: 'EG',
      addressRegion: locale === 'ar' ? 'القاهرة الكبرى وشمال الصعيد' : 'Greater Cairo & Northern Upper Egypt',
    },
  };
  return <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(data) }} />;
}

export function ServicesJsonLd({ locale }: { locale: Locale }) {
  const data = {
    '@context': 'https://schema.org',
    '@type': 'ItemList',
    itemListElement: services.items.map((s, i) => ({
      '@type': 'ListItem',
      position: i + 1,
      item: {
        '@type': 'Service',
        name: s.title[locale],
        description: s.desc[locale],
        provider: { '@type': 'Organization', name: company.nameFull[locale] },
        areaServed: { '@type': 'Country', name: 'Egypt' },
      },
    })),
  };
  return <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(data) }} />;
}
