import { Locale } from '@/lib/i18n';
import { company, services } from '@/content/site';

// Organization + Service schema. Fed to search engines and AI answer engines (GEO).
// Uses real, verifiable facts; contact placeholders are omitted until provided.
export function OrganizationJsonLd({ locale }: { locale: Locale }) {
  const data = {
    '@context': 'https://schema.org',
    '@type': 'Organization',
    name: company.nameFull[locale],
    alternateName: locale === 'ar' ? 'Egyptian Group Hard Steel' : 'المجموعة المصرية',
    url: `https://${company.domain}/${locale}`,
    logo: `https://${company.domain}/assets/logo.png`,
    foundingDate: '2011',
    description:
      locale === 'ar'
        ? 'تصنيع معدني صحي لقطاعات الأغذية والأدوية والكيماويات — قص ليزر، لحام أوربيتال صحي وفق ASME BPE، تحليل مواد داخلي وفحص NDT.'
        : 'Hygienic metal fabrication for food, pharmaceutical and chemical industries — laser cutting, orbital sanitary welding to ASME BPE, in-house material testing and NDT.',
    areaServed: { '@type': 'Country', name: 'Egypt' },
    geo: { '@type': 'GeoCoordinates', latitude: 29.9074868, longitude: 30.8990209 },
    hasMap: 'https://maps.app.goo.gl/xtcxjpMjNaTDbX849',
    location: [
      {
        '@type': 'Place',
        name: locale === 'ar' ? 'الإدارة والمصنع' : 'Head office & factory',
        address: {
          '@type': 'PostalAddress',
          streetAddress: locale === 'ar' ? '260، شارع 44، المنطقة الصناعية الثالثة' : '260, Street 44, 3rd Industrial Zone',
          addressLocality: locale === 'ar' ? 'السادس من أكتوبر' : '6th of October City',
          addressRegion: locale === 'ar' ? 'الجيزة' : 'Giza',
          postalCode: '12581',
          addressCountry: 'EG',
        },
        geo: { '@type': 'GeoCoordinates', latitude: 29.9074868, longitude: 30.8990209 },
        hasMap: 'https://maps.app.goo.gl/xtcxjpMjNaTDbX849',
      },
      {
        '@type': 'Place',
        name: locale === 'ar' ? 'المخازن' : 'Warehouses',
        address: {
          '@type': 'PostalAddress',
          streetAddress: locale === 'ar' ? 'شارع 26، المنطقة الصناعية، الحي الثاني عشر' : 'Street 26, Industrial Zone, 12th District',
          addressLocality: locale === 'ar' ? 'السادس من أكتوبر' : '6th of October City',
          addressRegion: locale === 'ar' ? 'الجيزة' : 'Giza',
          postalCode: '12581',
          addressCountry: 'EG',
        },
        geo: { '@type': 'GeoCoordinates', latitude: 29.93747, longitude: 30.88539 },
        hasMap: 'https://maps.app.goo.gl/RsH49YaVCwSpSSsH7',
      },
    ],
    knowsAbout: [
      'orbital welding',
      'ASME BPE fabrication',
      'sanitary stainless steel fabrication',
      'laser cutting',
      'back purge TIG welding',
      'powder filter fabrication',
      'baghouse filter Egypt',
      'ribbon blender Egypt',
      'EN 10204 3.1',
      'orbital welding Egypt',
      'food grade fabrication',
      'food grade stainless steel',
      'sanitary fabrication',
      'tank fabrication',
      'pressure vessels',
      'heat exchangers',
      'CNC machining',
    ],
    address: {
      '@type': 'PostalAddress',
      streetAddress: locale === 'ar' ? '260، شارع 44، المنطقة الصناعية الثالثة' : '260, Street 44, 3rd Industrial Zone',
      addressLocality: locale === 'ar' ? 'السادس من أكتوبر' : '6th of October City',
      addressRegion: locale === 'ar' ? 'الجيزة' : 'Giza',
      postalCode: '12581',
      addressCountry: 'EG',
    },
  };
  return <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(data) }} />;
}

export function ServicesJsonLd({ locale }: { locale: Locale }) {
  const data = {
    '@context': 'https://schema.org',
    '@type': 'ItemList',
    itemListElement: services.items.map((s, i) => ({
      '@type': 'ListItem',
      position: i + 1,
      item: {
        '@type': 'Service',
        name: s.title[locale],
        description: s.desc[locale],
        provider: { '@type': 'Organization', name: company.nameFull[locale] },
        areaServed: { '@type': 'Country', name: 'Egypt' },
      },
    })),
  };
  return <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(data) }} />;
}
