import Link from 'next/link';
import Image from 'next/image';
import { Locale } from '@/lib/i18n';
import { Icon } from './Icon';
import * as C from '@/content/site';

type Props = { locale: Locale };
const pick =
  (locale: Locale) =>
  <T extends { ar: string; en: string }>(x: T) =>
    x[locale];

// ---------- HERO ----------
export function Hero({ locale }: Props) {
  const t = pick(locale);
  return (
    <section className="relative flex min-h-screen items-center overflow-hidden pt-[74px]">
      <div className="absolute inset-0 z-0">
        <Image src="/assets/laser-cutting.jpg" alt="" fill priority className="object-cover object-[center_40%] opacity-[0.34]" />
        <div
          className="absolute inset-0"
          style={{
            background:
              locale === 'ar'
                ? 'linear-gradient(270deg,var(--ink) 12%,rgba(20,22,24,.72) 55%,rgba(20,22,24,.35) 100%)'
                : 'linear-gradient(90deg,var(--ink) 12%,rgba(20,22,24,.72) 55%,rgba(20,22,24,.35) 100%)',
          }}
        />
        <div className="grid-ov absolute inset-0 opacity-50" style={{ maskImage: 'radial-gradient(circle at 30% 50%,#000,transparent 75%)' }} />
      </div>
      <div className="reveal relative z-10 mx-auto w-full max-w-content px-7 py-[60px]">
        <div className="max-w-[780px]">
          <span className="eyebrow">{t(C.hero.eyebrow)}</span>
          <h1
            className="mt-[22px] text-[clamp(2.5rem,5.6vw,4.5rem)] font-black"
            dangerouslySetInnerHTML={{ __html: t(C.hero.titleHtml) }}
          />
          <p
            className="mt-[26px] max-w-[600px] text-[clamp(1.05rem,1.8vw,1.26rem)] leading-[1.62] text-muted [&_b]:font-semibold [&_b]:text-paper"
            dangerouslySetInnerHTML={{ __html: t(C.hero.sub) }}
          />
          <div className="mt-[38px] flex flex-wrap gap-[14px]">
            <Link href={`/${locale}/contact`} className="inline-flex items-center gap-[9px] rounded-md bg-amber px-[26px] py-[14px] text-[15px] font-semibold text-[#161310] transition hover:bg-amber-hi">
              {t(C.hero.ctaPrimary)}
              <Icon name="arrow" className="h-[15px] w-[15px] flip-x" strokeWidth={2.4} />
            </Link>
            <a href="#capabilities" className="inline-flex items-center gap-[9px] rounded-md border border-line px-[26px] py-[14px] text-[15px] font-semibold transition hover:border-steel-lt">
              {t(C.hero.ctaSecondary)}
            </a>
          </div>
        </div>
      </div>
    </section>
  );
}

// ---------- SPEC STRIP ----------
export function SpecStrip({ locale }: Props) {
  const t = pick(locale);
  return (
    <div className="relative z-10 border-t border-line backdrop-blur-sm" style={{ background: 'rgba(20,22,24,.55)' }}>
      <div className="mx-auto grid max-w-content grid-cols-2 md:grid-cols-4">
        {C.specStrip.map((s, i) => (
          <div key={i} className="border-line p-[24px] ltr:border-r rtl:border-l last:border-none [&:nth-child(2)]:md:border-r max-md:[&:nth-child(2)]:border-none">
            <div className="font-mono text-[1.7rem] font-semibold tracking-tight">
              {s.n}
              <span className="ms-[3px] text-[0.88rem] text-amber">{t(s.u)}</span>
            </div>
            <div className="mt-[5px] text-[12.5px] text-muted">{t(s.l)}</div>
          </div>
        ))}
      </div>
    </div>
  );
}

// ---------- SECTION HEAD ----------
function Head({ locale, eyebrow, title, intro }: Props & { eyebrow: C.L; title: C.L; intro?: C.L }) {
  const t = pick(locale);
  return (
    <div className="reveal mb-14 max-w-[680px]">
      <span className="eyebrow">{t(eyebrow)}</span>
      <h2 className="mt-4 text-[clamp(1.9rem,3.6vw,2.9rem)]">{t(title)}</h2>
      {intro && <p className="mt-4 text-[1.05rem] leading-[1.65] text-muted">{t(intro)}</p>}
    </div>
  );
}

// ---------- CREED ----------
export function Creed({ locale }: Props) {
  const t = pick(locale);
  return (
    <section className="relative overflow-hidden border-y border-line bg-ink-2 py-[110px]">
      <div className="absolute inset-0 opacity-[0.05]" style={{ backgroundImage: 'linear-gradient(90deg,var(--amber) 1px,transparent 1px)', backgroundSize: '44px 100%' }} />
      <div className="reveal relative mx-auto max-w-content px-7">
        <div className="max-w-[820px]">
          <span className="eyebrow">{t(C.creed.eyebrow)}</span>
          <p className="mt-[22px] text-[clamp(1.5rem,3vw,2.3rem)] font-extrabold leading-[1.3]" dangerouslySetInnerHTML={{ __html: t(C.creed.bigHtml) }} />
          <p className="mt-5 max-w-[640px] text-[1.05rem] leading-[1.7] text-muted">{t(C.creed.body)}</p>
        </div>
      </div>
    </section>
  );
}

// ---------- SECTORS ----------
export function Sectors({ locale }: Props) {
  const t = pick(locale);
  return (
    <section id="sectors" className="py-[110px]">
      <div className="mx-auto max-w-content px-7">
        <Head locale={locale} eyebrow={C.sectors.eyebrow} title={C.sectors.title} intro={C.sectors.intro} />
        <div className="grid grid-cols-1 gap-5 md:grid-cols-3">
          {C.sectors.items.map((s, i) => (
            <div key={i} className="reveal group relative rounded-xl border border-line p-[34px_30px] transition hover:-translate-y-[3px] hover:border-steel" style={{ background: 'linear-gradient(180deg,rgba(255,255,255,.015),transparent)' }}>
              <span className="absolute top-[22px] font-mono text-[11px] tracking-widest text-steel-lt opacity-70 ltr:right-[22px] rtl:left-[22px]">{String(i + 1).padStart(2, '0')}</span>
              <Icon name={s.icon} className="mb-5 h-11 w-11 text-amber" />
              <h3 className="text-[1.35rem]">{t(s.title)}</h3>
              <p className="mt-3 text-[0.95rem] leading-[1.6] text-muted">{t(s.body)}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

// ---------- WELDING ----------
export function Welding({ locale }: Props) {
  const t = pick(locale);
  return (
    <section id="welding" className="border-y border-line bg-ink-2 py-[110px]">
      <div className="mx-auto grid max-w-content grid-cols-1 items-center gap-[60px] px-7 lg:grid-cols-2">
        <div className="reveal flex flex-col gap-3">
          {C.welding.images.map((im, i) => (
            <div key={i} className="relative overflow-hidden rounded-xl border border-line" style={{ aspectRatio: i === 0 ? '16/10' : '16/7' }}>
              <Image src={im.src} alt={t(im.cap)} fill className="object-cover" />
              <div className="absolute inset-x-0 bottom-0 p-[12px_16px] font-mono text-[11px] tracking-wide text-steel-lt" style={{ background: 'linear-gradient(0deg,rgba(20,22,24,.92),transparent)' }}>
                {t(im.cap)}
              </div>
            </div>
          ))}
        </div>
        <div className="reveal">
          <span className="eyebrow">{t(C.welding.eyebrow)}</span>
          <h2 className="mt-4 text-[clamp(1.8rem,3.2vw,2.6rem)]">{t(C.welding.title)}</h2>
          <p className="mt-[18px] text-[1.05rem] leading-[1.7] text-muted">{t(C.welding.body)}</p>
          <div className="mt-6 flex flex-col gap-[14px]">
            {C.welding.bullets.map((b, i) => (
              <div key={i} className="flex items-start gap-[13px] text-[0.98rem]">
                <Icon name="tick" className="mt-[2px] h-[19px] w-[19px] shrink-0 text-amber flip-x" strokeWidth={2} />
                <span>{t(b)}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}

// ---------- CAPABILITIES ----------
export function Capabilities({ locale }: Props) {
  const t = pick(locale);
  return (
    <section id="capabilities" className="py-[110px]">
      <div className="mx-auto max-w-content px-7">
        <Head locale={locale} eyebrow={C.capabilities.eyebrow} title={C.capabilities.title} />
        <div className="grid grid-cols-1 items-start gap-14 lg:grid-cols-[1.15fr_0.85fr]">
          <div className="reveal border-t border-line">
            {C.capabilities.rows.map((r, i) => (
              <div key={i} className="grid grid-cols-[38px_1fr_auto] items-baseline gap-5 border-b border-line px-1 py-[22px] transition hover:bg-white/[0.015]">
                <span className="font-mono text-[13px] text-steel-lt">{String(i + 1).padStart(2, '0')}</span>
                <span className="text-[1.06rem] font-semibold">
                  {t(r.name)}
                  <span className="mt-[3px] block text-[0.88rem] font-normal text-muted">{t(r.sub)}</span>
                </span>
                <span className="whitespace-nowrap font-mono text-[0.92rem] text-amber">{t(r.val)}</span>
              </div>
            ))}
          </div>
          <aside className="reveal rounded-2xl border border-line bg-ink-2 p-[34px] lg:sticky lg:top-[100px]">
            <h3 className="mb-2 text-[1.15rem]">{t(C.capabilities.asideTitle)}</h3>
            <p className="text-[0.94rem] leading-[1.6] text-muted">{t(C.capabilities.asideBody)}</p>
            <div className="mt-6 flex flex-col gap-[14px]">
              {C.capabilities.standards.map((s, i) => (
                <div key={i} className="flex items-center gap-[14px] border-b border-line pb-[14px] last:border-none last:pb-0">
                  <span className="min-w-[104px] rounded-md border border-amber/25 bg-amber/[0.12] px-[10px] py-[7px] text-center font-mono text-[12.5px] font-semibold text-amber">{t(s.badge)}</span>
                  <span className="text-[0.88rem] text-muted">{t(s.d)}</span>
                </div>
              ))}
            </div>
          </aside>
        </div>
      </div>
    </section>
  );
}

// ---------- SERVICES ----------
export function Services({ locale }: Props) {
  const t = pick(locale);
  return (
    <section id="services" className="border-t border-line bg-ink-2 py-[110px]">
      <div className="mx-auto max-w-content px-7">
        <Head locale={locale} eyebrow={C.services.eyebrow} title={C.services.title} intro={C.services.intro} />
        <div className="reveal grid grid-cols-1 gap-px overflow-hidden rounded-2xl border border-line bg-line md:grid-cols-3">
          {C.services.items.map((s, i) => {
            const img = (s as { img?: string }).img;
            return (
              <div key={s.slug} className="group relative min-h-[180px] overflow-hidden bg-ink p-[30px_26px] transition hover:bg-ink-3">
                {img && (
                  <>
                    <Image src={img} alt="" fill sizes="(max-width:768px) 100vw, 33vw" className="object-cover opacity-[0.78] transition duration-500 group-hover:opacity-100 group-hover:scale-105" />
                    <div className="absolute inset-0 bg-gradient-to-t from-ink/95 via-ink/55 to-ink/10" />
                  </>
                )}
                <div className="relative">
                  <div className="font-mono text-[12px] tracking-widest text-steel-lt">{String(i + 1).padStart(2, '0')}</div>
                  <Icon name={s.icon} className="absolute top-0 h-6 w-6 text-amber opacity-90 ltr:right-0 rtl:left-0" />
                  <h3 className="mb-[9px] mt-[14px] text-[1.18rem]">{t(s.title)}</h3>
                  <p className="text-[0.9rem] leading-[1.5] text-muted">{t(s.desc)}</p>
                </div>
              </div>
            );
          })}
          {/* send-drawing tile */}
          <Link href={`/${locale}/contact`} className="relative min-h-[180px] p-[30px_26px] transition hover:brightness-125" style={{ background: 'linear-gradient(135deg,rgba(243,161,53,.08),var(--ink))' }}>
            <div className="font-mono text-[12px] text-amber">→</div>
            <h3 className="mb-[9px] mt-[14px] text-[1.18rem]">{t(C.services.drawingTile.title)}</h3>
            <p className="text-[0.9rem] leading-[1.5] text-muted">{t(C.services.drawingTile.desc)}</p>
          </Link>
        </div>
      </div>
    </section>
  );
}

// ---------- STOCK ----------
export function Stock({ locale }: Props) {
  const t = pick(locale);
  return (
    <section id="stock" className="border-t border-line py-[110px]">
      <div className="mx-auto grid max-w-content grid-cols-1 items-center gap-14 px-7 lg:grid-cols-[0.8fr_1.2fr]">
        <div className="reveal max-h-[480px] overflow-hidden rounded-2xl border border-line" style={{ aspectRatio: '3/4' }}>
          <Image src={C.stock.image} alt="" width={605} height={807} className="h-full w-full object-cover" />
        </div>
        <div className="reveal">
          <span className="eyebrow">{t(C.stock.eyebrow)}</span>
          <h2 className="mt-4 text-[clamp(1.8rem,3.2vw,2.6rem)]">{t(C.stock.title)}</h2>
          {C.stock.bodyHtml.map((p, i) => (
            <p key={i} className="mt-[18px] text-[1.05rem] leading-[1.7] text-muted [&_b]:text-paper" dangerouslySetInnerHTML={{ __html: t(p) }} />
          ))}
        </div>
      </div>
    </section>
  );
}

// ---------- PEOPLE ----------
export function People({ locale }: Props) {
  const t = pick(locale);
  return (
    <section id="people" className="border-y border-line bg-ink-2 py-[110px]">
      <div className="mx-auto max-w-content px-7">
        <Head locale={locale} eyebrow={C.people.eyebrow} title={C.people.title} intro={C.people.intro} />
        <div className="mt-2 grid grid-cols-1 gap-5 lg:grid-cols-2">
          {C.people.cards.map((c, i) => (
            <div key={i} className="reveal rounded-xl border border-line p-[30px]" style={{ background: 'linear-gradient(180deg,rgba(255,255,255,.015),transparent)' }}>
              <Icon name={c.icon} className="mb-4 h-[38px] w-[38px] text-amber" />
              <h4 className="text-[1.2rem]">{t(c.title)}</h4>
              <p className="mt-[10px] text-[0.95rem] leading-[1.6] text-muted">{t(c.body)}</p>
              <div className="mt-4 flex flex-wrap gap-2">
                {c.chips.map((ch, j) => (
                  <span key={j} className="rounded-full border border-line px-[10px] py-[5px] font-mono text-[12px] text-steel-lt">{t(ch)}</span>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

// ---------- INSTITUTION ----------
export function Institution({ locale }: Props) {
  const t = pick(locale);
  return (
    <section id="institution" className="py-[110px]">
      <div className="mx-auto max-w-content px-7">
        <Head locale={locale} eyebrow={C.institution.eyebrow} title={C.institution.title} intro={C.institution.intro} />
        <div className="grid grid-cols-1 gap-5 lg:grid-cols-2">
          {C.institution.cards.map((c, i) => (
            <div key={i} className="reveal rounded-xl border border-line p-[30px]" style={{ background: 'linear-gradient(180deg,rgba(255,255,255,.015),transparent)' }}>
              <Icon name={c.icon} className="mb-4 h-[38px] w-[38px] text-amber" />
              <h4 className="text-[1.2rem]">{t(c.title)}</h4>
              <p className="mt-[10px] text-[0.95rem] leading-[1.6] text-muted">{t(c.body)}</p>
              <div className="mt-4 flex flex-wrap gap-2">
                {c.chips.map((ch, j) => (
                  <span key={j} className="rounded-full border border-line px-[10px] py-[5px] font-mono text-[12px] text-steel-lt">{t(ch)}</span>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

// ---------- ECOSYSTEM ----------
export function Ecosystem({ locale }: Props) {
  const t = pick(locale);
  return (
    <section id="ecosystem" className="relative overflow-hidden border-t border-line py-[110px]">
      <div className="grid-ov absolute inset-0 opacity-50" style={{ maskImage: 'radial-gradient(circle at 70% 20%,#000,transparent 70%)' }} />
      <div className="relative mx-auto max-w-content px-7">
        <div className="reveal mb-[52px] max-w-[720px]">
          <span className="eyebrow">{t(C.ecosystem.eyebrow)}</span>
          <h2 className="mt-4 text-[clamp(1.9rem,3.6vw,2.9rem)]" dangerouslySetInnerHTML={{ __html: t(C.ecosystem.titleHtml) }} />
          <p className="mt-4 text-[1.05rem] leading-[1.65] text-muted">{t(C.ecosystem.intro)}</p>
        </div>
        <div className="reveal flex flex-wrap overflow-hidden rounded-2xl border border-line bg-ink-2">
          {C.ecosystem.chain.map((n, i) => (
            <div key={i} className="relative min-w-[150px] flex-1 border-line p-[26px_22px] transition hover:bg-ink-3 ltr:border-r rtl:border-l last:border-none max-lg:basis-[40%] max-lg:border-b max-md:basis-full">
              <span className="mb-3 block font-mono text-[11px] tracking-wider text-amber">{t(n.step)}</span>
              <h4 className="text-[1.05rem] font-bold">{t(n.name)}</h4>
              <p className="mt-[7px] text-[0.82rem] leading-[1.45] text-muted">{t(n.note)}</p>
              {i < C.ecosystem.chain.length - 1 && (
                <span className="absolute top-1/2 z-[2] flex h-[18px] w-[18px] -translate-y-1/2 items-center justify-center rounded-full border border-line bg-ink ltr:-right-[9px] rtl:-left-[9px] max-lg:hidden">
                  <Icon name="arrow" className="h-[10px] w-[10px] text-amber flip-x" strokeWidth={2.5} />
                </span>
              )}
            </div>
          ))}
        </div>
        <div className="reveal mt-[26px] flex items-center gap-[13px] text-[0.95rem] text-steel-lt">
          <Icon name="loop" className="h-5 w-5 shrink-0 text-amber" strokeWidth={1.8} />
          <span>{t(C.ecosystem.loop)}</span>
        </div>
      </div>
    </section>
  );
}

// ---------- SIGNATURE ----------
export function Signature({ locale }: Props) {
  const t = pick(locale);
  return (
    <section className="relative overflow-hidden border-t border-line bg-ink py-[96px] text-center">
      <div className="absolute inset-0 opacity-[0.06]" style={{ background: 'radial-gradient(circle at 50% 0%,var(--amber),transparent 60%)' }} />
      <div className="reveal relative mx-auto max-w-[900px] px-7">
        <div className="mb-[26px] font-mono text-[12px] uppercase tracking-[0.22em] text-steel-lt">{t(C.signature.lead)}</div>
        <p className="text-[clamp(1.7rem,4vw,2.9rem)] font-extrabold leading-[1.25]" dangerouslySetInnerHTML={{ __html: t(C.signature.signHtml) }} />
        <p className="mt-[28px] text-[0.92rem] text-muted">{t(C.signature.by)}</p>
      </div>
    </section>
  );
}

// ---------- CTA ----------
export function CTA({ locale }: Props) {
  const t = pick(locale);
  return (
    <section id="contact-cta" className="relative overflow-hidden border-y border-line bg-ink-2 py-[84px]">
      <div className="absolute inset-0 opacity-[0.06]" style={{ backgroundImage: 'linear-gradient(90deg,var(--amber) 1px,transparent 1px)', backgroundSize: '40px 100%' }} />
      <div className="reveal relative mx-auto flex max-w-content flex-wrap items-center justify-between gap-10 px-7 max-md:flex-col max-md:items-start">
        <div>
          <h2 className="max-w-[600px] text-[clamp(1.8rem,3.4vw,2.7rem)]">{t(C.cta.title)}</h2>
          <p className="mt-[14px] max-w-[520px] text-muted">{t(C.cta.body)}</p>
        </div>
        <div className="flex flex-wrap gap-[14px]">
          <Link href={`/${locale}/contact`} className="inline-flex items-center gap-[9px] rounded-md bg-amber px-[28px] py-[15px] text-[15px] font-semibold text-[#161310] transition hover:bg-amber-hi">
            {t(C.cta.primary)}
            <Icon name="arrow" className="h-[15px] w-[15px] flip-x" strokeWidth={2.4} />
          </Link>
          <Link href={`/${locale}/contact`} className="inline-flex items-center gap-[9px] rounded-md border border-line px-[28px] py-[15px] text-[15px] font-semibold transition hover:border-steel-lt">
            {t(C.cta.secondary)}
          </Link>
        </div>
      </div>
    </section>
  );
}
