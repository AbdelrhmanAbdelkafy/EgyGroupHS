'use client';

import { useEffect } from 'react';

/**
 * Registers the service worker once the page is idle, so it never competes
 * with the first paint. Failures are silent by design: a missing SW should
 * degrade the site to "a normal website", not break it.
 */
export function RegisterSW() {
  useEffect(() => {
    if (typeof window === 'undefined' || !('serviceWorker' in navigator)) return;
    const reg = () =>
      navigator.serviceWorker.register('/sw.js').catch(() => {
        /* unsupported browser, private mode, or http — fine, carry on */
      });
    if (document.readyState === 'complete') reg();
    else window.addEventListener('load', reg, { once: true });
  }, []);
  return null;
}
