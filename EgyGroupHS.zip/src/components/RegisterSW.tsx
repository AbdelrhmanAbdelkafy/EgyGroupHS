'use client';

import { useEffect } from 'react';

// ============================================================================
// Registers the service worker — and, more importantly, rescues anyone already
// holding a poisoned cache from the previous version.
//
// The old worker cached HTML. After a deploy those cached pages referenced
// build chunks that no longer existed, so the browser 404'd every asset and
// painted raw unstyled HTML. Reloading didn't help: the cache answered first.
//
// Recovery, in order:
//   1. Unregister any worker that isn't the current /sw.js.
//   2. Delete every cache left by an earlier build.
//   3. Register the new worker, which claims control immediately.
//
// All best-effort and silent: a failure here should leave a plain, working
// website — never a broken one.
// ============================================================================

const SW_URL = '/sw.js';

export function RegisterSW() {
  useEffect(() => {
    if (typeof window === 'undefined' || !('serviceWorker' in navigator)) return;

    let cancelled = false;

    const run = async () => {
      try {
        // 1) drop workers registered under a different script
        const regs = await navigator.serviceWorker.getRegistrations();
        await Promise.all(
          regs.map(async (r) => {
            const script = r.active?.scriptURL || r.installing?.scriptURL || r.waiting?.scriptURL || '';
            if (script && !script.endsWith(SW_URL)) await r.unregister().catch(() => {});
          })
        );

        // 2) purge caches from earlier builds — this is what actually unbreaks the page
        if ('caches' in window) {
          navigator.serviceWorker.controller?.postMessage('clear-caches');
          const keys = await caches.keys();
          await Promise.all(
            keys
              .filter((k) => k.startsWith('shell-') || /^static-v\d/.test(k) || /^photos-v\d/.test(k))
              .map((k) => caches.delete(k))
          );
        }

        if (cancelled) return;

        // 3) register the current worker
        const reg = await navigator.serviceWorker.register(SW_URL);

        // check for a new build whenever the tab regains focus
        const onFocus = () => reg.update().catch(() => {});
        window.addEventListener('focus', onFocus);
      } catch {
        /* unsupported browser, private mode, or plain http — carry on as a normal site */
      }
    };

    if (document.readyState === 'complete') run();
    else window.addEventListener('load', run, { once: true });

    return () => {
      cancelled = true;
    };
  }, []);

  return null;
}
