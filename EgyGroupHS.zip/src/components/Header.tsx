import Link from 'next/link';
import Image from 'next/image';
import { Locale, other } from '@/lib/i18n';
import { nav, company, cta } from '@/content/site';
import { Icon } from './Icon';
import { CartBadge } from './CartBadge';

export function Header({ locale, path = '' }: { locale: Locale; path?: string }) {
  const t = <T extends { ar: string; en: string }>(x: T) => x[locale];
  const alt = other(locale);
  // Preserve current sub-path when switching language
  const switchHref = `/${alt}${path}`;

  return (
    <header
      className="fixed inset-x-0 top-0 z-50 border-b border-line backdrop-blur-md"
      style={{ background: 'rgba(20,22,24,.72)' }}
    >
      <div className="mx-auto flex h-[74px] max-w-content items-center justify-between px-7">
        <Link href={`/${locale}`} className="flex items-center gap-3">
          <Image src="/assets/logo.png" alt={t(company.nameShort)} width={44} height={44} className="h-11 w-11 rounded-md object-cover" />
          <span className="leading-tight">
            <span className="block text-[15px] font-extrabold">{t(company.nameShort)}</span>
            <span className="block font-mono text-[10px] font-semibold tracking-[0.24em] text-amber">{company.brandTag}</span>
          </span>
        </Link>

        <nav className="hidden items-center gap-7 lg:flex">
          {nav.map((item) => (
            <Link
              key={item.href}
              href={`/${locale}${item.href}`}
              className="text-[14.5px] font-medium opacity-80 transition hover:text-amber hover:opacity-100"
            >
              {t(item.label)}
            </Link>
          ))}
        </nav>

        <div className="flex items-center gap-3">
          <CartBadge locale={locale} />
          <Link
            href={switchHref}
            className="rounded-md border border-line px-3 py-2 font-mono text-[12.5px] font-semibold tracking-widest transition hover:border-amber hover:text-amber"
          >
            {locale === 'ar' ? 'EN' : 'عربي'}
          </Link>
          <Link
            href={`/${locale}/site-visit`}
            className="hidden items-center gap-2 rounded-md bg-amber px-5 py-[11px] text-[14.5px] font-semibold text-[#161310] transition hover:bg-amber-hi sm:inline-flex"
          >
            {t(cta.primary)}
            <Icon name="arrow" className="h-[15px] w-[15px] flip-x" strokeWidth={2.4} />
          </Link>
        </div>
      </div>
    </header>
  );
}
