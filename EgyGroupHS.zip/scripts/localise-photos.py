#!/usr/bin/env python3
"""
Copy the product photo library off Cloudinary and onto this machine.

Why: the catalogue's photos are the business's own work, but they were being
served from a third party's free tier. Exceed the quota or let the account
lapse and every photo on the site vanishes at once. After this runs, the site
serves its own photos from its own disk and Cloudinary can go away entirely.

Run once, from the project root:

    python3 scripts/localise-photos.py

Then add NEXT_PUBLIC_LOCAL_PHOTOS=1 to .env.local, rebuild, restart.

Safe to re-run: photos already present are skipped, so an interrupted run can
just be started again.
"""
import json, os, io, sys, urllib.request
from concurrent.futures import ThreadPoolExecutor

try:
    from PIL import Image, ImageOps
except ImportError:
    sys.exit("محتاج Pillow:  pip3 install Pillow   (أو: apt install -y python3-pil)")

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
LIB = os.path.join(ROOT, 'src', 'content', 'photo-library.json')
OUT = os.path.join(ROOT, '.data', 'photos')
SIZES = [400, 800, 1600]
BG = (233, 235, 238)   # the same grey the cards sit on, for transparent PNGs


def photo_id(url):
    """Mirror of photoId() in src/lib/photo.ts — the two must agree exactly."""
    i = url.find('/upload/')
    if i < 0:
        return None
    tail = url[i + 8:]
    parts = tail.split('/', 1)
    if len(parts) == 2 and parts[0].startswith('v') and parts[0][1:].isdigit():
        tail = parts[1]
    return os.path.splitext(tail)[0].replace('/', '_')


def fetch(p):
    url = p['url']
    name = photo_id(url)
    if not name:
        return ('skip', url)
    if all(os.path.exists(os.path.join(OUT, str(s), name + '.jpg')) for s in SIZES):
        return ('have', name)
    try:
        with urllib.request.urlopen(url, timeout=45) as r:
            im = Image.open(io.BytesIO(r.read()))
        im = ImageOps.exif_transpose(im)          # honour how the camera was held
        if im.mode in ('RGBA', 'LA', 'P'):
            im = im.convert('RGBA')
            flat = Image.new('RGB', im.size, BG)  # JPEG has no alpha; unpainted = black
            flat.paste(im, mask=im.split()[-1])
            im = flat
        else:
            im = im.convert('RGB')
        for s in SIZES:
            w = min(s, im.width)                  # never upscale: it invents nothing
            h = max(1, round(im.height * w / im.width))
            im.resize((w, h), Image.LANCZOS).save(
                os.path.join(OUT, str(s), name + '.jpg'),
                'JPEG', quality=82, optimize=True, progressive=True)
        return ('new', name)
    except Exception as e:
        return ('fail', f'{name}: {e}')


def main():
    lib = json.load(open(LIB, encoding='utf-8'))
    for s in SIZES:
        os.makedirs(os.path.join(OUT, str(s)), exist_ok=True)

    print(f'المكتبة: {len(lib)} صورة → {OUT}')
    with ThreadPoolExecutor(8) as ex:
        res = list(ex.map(fetch, lib))

    tally = {}
    for k, _ in res:
        tally[k] = tally.get(k, 0) + 1
    print(f"  جديدة: {tally.get('new', 0)} · موجودة: {tally.get('have', 0)} · فشلت: {tally.get('fail', 0)}")

    for k, v in res:
        if k == 'fail':
            print('  ✗', v)

    mb = sum(
        os.path.getsize(os.path.join(OUT, str(s), f))
        for s in SIZES for f in os.listdir(os.path.join(OUT, str(s)))
    ) / 1024 / 1024
    print(f'  الإجمالي على القرص: {mb:.1f} MB')

    if tally.get('fail'):
        print('\n⚠️ فيه صور فشلت — شغّل السكربت تاني، بيتخطّى اللي نزل.')
        sys.exit(1)

    print('\n✅ تمام. دلوقتي:')
    print("   echo 'NEXT_PUBLIC_LOCAL_PHOTOS=1' >> .env.local")
    print('   npm run build && systemctl restart egygroup')


if __name__ == '__main__':
    main()
