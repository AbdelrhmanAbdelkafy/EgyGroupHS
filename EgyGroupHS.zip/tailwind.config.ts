import type { Config } from 'tailwindcss';

const config: Config = {
  content: ['./src/**/*.{ts,tsx}'],
  theme: {
    extend: {
      colors: {
        ink: '#141618',
        'ink-2': '#1c1f22',
        'ink-3': '#262a2e',
        steel: '#44566D',
        'steel-lt': '#7d90a6',
        amber: '#F3A135',
        'amber-hi': '#ffb44e',
        paper: '#eef1f4',
        muted: '#9aa4ad',
        line: '#2c3136',
      },
      fontFamily: {
        display: ['var(--font-archivo)', 'system-ui', 'sans-serif'],
        ar: ['var(--font-plex-ar)', 'system-ui', 'sans-serif'],
        mono: ['var(--font-plex-mono)', 'monospace'],
      },
      maxWidth: {
        content: '1240px',
      },
    },
  },
  plugins: [],
};

export default config;
