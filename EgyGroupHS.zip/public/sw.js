// ============================================================================
// Service worker — offline shell + sensible caching.
//
// Strategy, deliberately conservative for a site whose content is edited:
//   • navigations  → network-first, fall back to cache, then /offline
//   • static assets (_next/static, icons, images) → cache-first (they're hashed
//     or long-lived, so staleness is not a risk)
//   • Cloudinary photos → stale-while-revalidate (big, and rarely change)
//   • /api/*        → never cached. A visit request must reach the CRM.
// ============================================================================

const VERSION = 'v2';
const SHELL = `shell-${VERSION}`;
const STATIC = `static-${VERSION}`;
const PHOTOS = `photos-${VERSION}`;
const OFFLINE_URL = '/offline.html';

const PRECACHE = ['/offline.html', '/icons/icon-192.png', '/manifest.json'];

self.addEventListener('install', (e) => {
  e.waitUntil(
    caches
      .open(SHELL)
      .then((c) => c.addAll(PRECACHE))
      .then(() => self.skipWaiting())
  );
});

self.addEventListener('activate', (e) => {
  e.waitUntil(
    caches
      .keys()
      .then((keys) =>
        Promise.all(keys.filter((k) => !k.endsWith(VERSION)).map((k) => caches.delete(k)))
      )
      .then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', (e) => {
  const { request } = e;
  if (request.method !== 'GET') return;

  const url = new URL(request.url);

  // Never touch the API — a lead must not be served from a cache.
  if (url.pathname.startsWith('/api/')) return;

  // Page navigations: network first so edits show up, cache as a safety net.
  if (request.mode === 'navigate') {
    e.respondWith(
      fetch(request)
        .then((res) => {
          const copy = res.clone();
          caches.open(SHELL).then((c) => c.put(request, copy));
          return res;
        })
        .catch(() => caches.match(request).then((hit) => hit || caches.match(OFFLINE_URL)))
    );
    return;
  }

  // Cloudinary photos: serve fast, refresh quietly.
  if (url.hostname === 'res.cloudinary.com') {
    e.respondWith(
      caches.open(PHOTOS).then((c) =>
        c.match(request).then((hit) => {
          const net = fetch(request)
            .then((res) => {
              if (res.ok) c.put(request, res.clone());
              return res;
            })
            .catch(() => hit);
          return hit || net;
        })
      )
    );
    return;
  }

  // Hashed build output and local assets: cache-first.
  if (
    url.origin === self.location.origin &&
    (url.pathname.startsWith('/_next/static') ||
      url.pathname.startsWith('/icons/') ||
      url.pathname.startsWith('/assets/') ||
      url.pathname.startsWith('/_next/image'))
  ) {
    e.respondWith(
      caches.open(STATIC).then((c) =>
        c.match(request).then(
          (hit) =>
            hit ||
            fetch(request).then((res) => {
              if (res.ok) c.put(request, res.clone());
              return res;
            })
        )
      )
    );
  }
});
