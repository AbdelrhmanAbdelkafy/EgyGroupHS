// ============================================================================
// Service worker.
//
// WHY THIS IS DELIBERATELY BORING
//
// The previous version cached page navigations. On a Next.js site that breaks
// badly: the HTML references JS/CSS chunks by content hash, and every deploy
// produces new hashes. A cached page therefore points at chunk names that no
// longer exist on the server — the browser gets 404s for every asset and paints
// raw, unstyled HTML. The site looks destroyed, and no amount of reloading
// fixes it, because the cache keeps answering first.
//
// It was made worse by a fixed VERSION constant: since the file's bytes never
// changed between deploys, the browser never re-installed the worker, so the
// poisoned cache had no way to expire. It was permanent.
//
// So, the rules now:
//   • navigations → NEVER cached. Always the network. Offline page only when
//     the device is genuinely offline.
//   • /_next/static → cache-first is safe here, and only here: the filenames
//     are content hashes, so a new build simply asks for different files.
//   • images → stale-while-revalidate. Big, and they don't change silently.
//   • /api/* → untouched. A visit request must reach the CRM.
//
// BUILD_ID changes on every deploy, so the worker's bytes change, so the
// browser reinstalls it and drops every old cache. That is the recovery path.
// ============================================================================

const BUILD_ID = '2026-07-15-05';
const STATIC = `static-${BUILD_ID}`;
const PHOTOS = `photos-${BUILD_ID}`;
const OFFLINE = '/offline.html';

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches
      .open(STATIC)
      .then((c) => c.addAll([OFFLINE, '/icons/icon-192.png', '/manifest.json']))
      .catch(() => {
        /* a missing precache file must not block activation */
      })
      .then(() => self.skipWaiting())
  );
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches
      .keys()
      .then((keys) =>
        // anything not from this build is gone — including the poisoned page cache
        Promise.all(keys.filter((k) => !k.endsWith(BUILD_ID)).map((k) => caches.delete(k)))
      )
      .then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', (event) => {
  const { request } = event;
  if (request.method !== 'GET') return;

  let url;
  try {
    url = new URL(request.url);
  } catch {
    return;
  }

  // The API is never cached: a lead has to reach the CRM, not a cache.
  if (url.pathname.startsWith('/api/')) return;

  // Pages: always the network. The offline page appears only when the fetch
  // genuinely fails — not when the server returns an error.
  if (request.mode === 'navigate') {
    event.respondWith(fetch(request).catch(() => caches.match(OFFLINE)));
    return;
  }

  const sameOrigin = url.origin === self.location.origin;

  // Hashed build output: cache-first is correct precisely because the name
  // changes whenever the content does.
  if (sameOrigin && url.pathname.startsWith('/_next/static/')) {
    event.respondWith(
      caches.open(STATIC).then((c) =>
        c.match(request).then(
          (hit) =>
            hit ||
            fetch(request).then((res) => {
              if (res.ok) c.put(request, res.clone());
              return res;
            })
        )
      )
    );
    return;
  }

  // Photos: show the cached copy, refresh in the background.
  const isPhoto =
    url.hostname === 'res.cloudinary.com' ||
    (sameOrigin && (url.pathname.startsWith('/assets/') || url.pathname.startsWith('/icons/')));

  if (isPhoto) {
    event.respondWith(
      caches.open(PHOTOS).then((c) =>
        c.match(request).then((hit) => {
          const net = fetch(request)
            .then((res) => {
              if (res.ok) c.put(request, res.clone());
              return res;
            })
            .catch(() => hit);
          return hit || net;
        })
      )
    );
  }
  // everything else falls through to the network untouched
});

// A page can order a full wipe — the escape hatch if a cache ever misbehaves again.
self.addEventListener('message', (event) => {
  if (event.data === 'clear-caches') {
    event.waitUntil(caches.keys().then((keys) => Promise.all(keys.map((k) => caches.delete(k)))));
  }
});
