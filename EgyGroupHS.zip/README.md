# المجموعة المصرية (Hard Steel) — Next.js Website

Bilingual (AR/EN) marketing site. Next.js 14 App Router + TypeScript + Tailwind.

## Verified
- ✅ `next build` compiles with zero errors
- ✅ 15 static pages generated (AR + EN × home/services/standards/about/contact)
- ✅ RTL (Arabic) + LTR (English) correct
- ✅ sitemap.xml + robots.txt + JSON-LD schema (SEO/GEO)

## Architecture (Middle path: static content + CMS-ready for dynamic parts)
- **All static copy** lives in `src/content/site.ts` (single source of truth, every string `{ar,en}`).
- Dynamic parts (catalogue, projects) will be added as Strapi CMS content-types later — pages fetch those from the Strapi API while keeping static copy in code.

## Run locally
```
npm install
npm run dev      # http://localhost:3000  → redirects to /ar
npm run build    # production build
npm start
```

## Structure
- `src/content/site.ts` — all bilingual content
- `src/lib/i18n.ts` — locales, direction helpers
- `src/components/` — Header, Footer, sections, Icon, JsonLd, Reveal
- `src/app/[locale]/` — home + services + standards + about + contact
- `src/app/sitemap.ts`, `robots.ts` — SEO infra
- `public/assets/` — brand images + logo

## TODO before go-live
- Replace contact placeholders in `site.ts` (phone/email/addresses)
- Remove machine-brand logos from orbital/CNC images (or swap for clean shots)
- Add CNC (CNC machining) image
- Wire contact form to CRM (VTiger) / email
- Deploy on VPS (see docker/apache setup)
